# B1 LFP Audit Output

This directory is the reproducible output of `LFP_preprocessing.py` for condition `B1_Discharge0.5C_Charge0.5C`.

## Files

| File | Purpose |
|---|---|
| `LFP_Audit_Report.md` | Full technical audit, provenance, quality, capacity/SOH, handoff |
| `LFP_file_manifest.csv` | Per-worksheet inventory and inspection status |
| `LFP_column_mapping.csv` | Source-to-canonical mapping with unit evidence |
| `LFP_cleaning_log.csv` | Per-worksheet quality counts, flags, dropped/interpolated rows |
| `LFP_capacity_soh_feasibility.csv` | Per-cycle capacity/SOH feasibility and blockers |
| `LFP_formula_register.csv` | Formula IDs, assumptions, numerical examples |
| `LFP_cycle_summary.csv` | Calculated cycle-level metrics |
| `LFP_staging_cycle_level.csv` | Canonical cycle-level staging table |
| `LFP_staging_sample_raw_rows.csv` | Exactly one raw cycle in canonical row format (staging sample, NOT the full telemetry export) |
| `validation_results.json` | Full-run completion, output existence, schema and row-count validation |
| `run_log.txt` | Complete execution log (preflight + 1/19..19/19 + validation) |
| `B1_Closure_Report.md` | Closure addendum: cycle 264 evidence, trend sensitivity, acceptance status |
| `B1_cycle264_evidence.csv` | Row-level raw evidence for the cycle 264 extremes |
| `B1_trend_sensitivity.csv` | Fade trend with and without cycle 264 |
| `B1_closure_validation.json` | Closure checks and acceptance status |
| `B1_closure_analysis.py` | Reproducible closure analysis (does not rerun the 20 M-row pipeline) |
| `B1_closure_checksums.txt` | SHA-256 hashes of closure and corrected artifacts |

**Acceptance:** `PASS WITH CONDITIONS` — see `B1_Closure_Report.md`.

## Scientific conditions

- The source header is `I(A/cm2)`. Values are interpreted as total current in amperes (`UNDERDETERMINED`), because `Surface Area = 0` and the protocol sets 0.625 A (0.5C of 1.25 Ah); the exported unit is **not instrument-confirmed**. The source label and raw values are preserved unchanged; `current_density_a_cm2` is `NA`. See report §5.
- Cycle/worksheet `current_excursion` flags use the documented screening threshold `1.5 x 0.625 A = 0.9375 A` (F6); values are not clipped or deleted. Only `Cycle_0300` cycle 14 (`-4.507276 A`) is flagged; zero false positives were observed across 1,498 worksheets with current telemetry.
- Capacity is computed with F1 only for complete discharge segments.
- SOH_nominal (F2) and proxy-reference retention (F3) are separate; neither is clipped. The reference is the first OBSERVED valid discharge, not a validated BOL characterisation test.
- Charge capacity and coulombic efficiency (F4) are diagnostic only and **UNSUPPORTED FOR MODELLING**.
- `battery_id` is `UNKNOWN`; no physical-cell replication is assumed.
- No temperature channel exists.
- Missing cycles are documented, not fabricated.
- The full raw telemetry is summarised per cycle; only one cycle is exported in full as `LFP_staging_sample_raw_rows.csv`.

## Reproduce

```bash
python B1_LFP_Audit_Output/LFP_preprocessing.py --input-dir . --output-dir B1_LFP_Audit_Output
```
