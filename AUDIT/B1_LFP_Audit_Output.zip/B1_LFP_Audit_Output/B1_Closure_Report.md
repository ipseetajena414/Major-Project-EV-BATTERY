# B1 LFP Closure Report — cycle 264 and acceptance

**Generated:** 2026-10-27 10:22:24  
**Scope:** B1 (Discharge 0.5C / Charge 0.5C) only  
**Acceptance status:** **PASS_WITH_CONDITIONS**

## 1. What was inspected

- `LFP_Audit_Report.md`, `validation_results.json`, `run_log.txt`.
- `LFP_cycle_summary.csv`, `LFP_cleaning_log.csv`, `LFP_file_manifest.csv`,
  `LFP_formula_register.csv`, `LFP_column_mapping.csv`.
- Raw `Cycle_0300.xlsx` worksheet `Run01_Un1Ch7_Step2_Cycle14` (rows 125–7243)
  and the tail of `Run01_Un1Ch7_Step2_Cycle13`.

No raw workbook was modified and the 20 M-row pipeline was not rerun.

## 2. Cycle 264 — raw evidence

| Field | Value |
|---|---|
| Workbook | Cycle_0300.xlsx / Run01_Un1Ch7_Step2_Cycle14 |
| Estimated global cycle | 264 (local cycle 14; offset VERIFIED) |
| Voltage maximum | 4.161499000 V at `B125` (Excel row 125) |
| Current minimum | -4.507276000 A at `C127` (Excel row 127) |
| Capacity (F1) | 1.234925042 Ah (summary: 1.234925 Ah) |
| Discharge duration | 7117 s over 7118 samples |
| Quality flags | cross_sheet_time_reset;out_of_protocol_voltage;current_excursion;partial_charge;retention_gt_100_no_clip |

The first five data rows show a recorded switching transient:

| Excel row | T (s) | E (V) | I (A) | Phase |
|---|---|---|---|---|
| 125 | 31 | 4.161499 | 0.626288 | charge |
| 126 | 32 | 3.813599 | -4.015350 | discharge |
| 127 | 33 | 3.550598 | -4.507276 | discharge |
| 128 | 34 | 3.606164 | -1.773718 | discharge |
| 129 | 35 | 3.674670 | -0.631738 | discharge |

The preceding sheet ends at T = 173286 s, E = 3.590662 V, I = 0.626437 A. The new sheet restarts at T = 31 s and begins at 4.161499 V, so the cross-sheet time reset and the voltage discontinuity are both evidenced.

**Calculation-path check.** Re-integrating the raw rows with F1 gives 
1.234925042 Ah, matching the stored capacity. Removing the four 
transient rows (125–128) changes capacity by only 
0.002390149 Ah (0.194%): 
median |I| × duration = 0.623706 A × 7117 s / 3600 = 
1.233032 Ah. The excess capacity therefore comes mainly 
from the longer discharge beginning at an over-protocol voltage, not from 
the 1-second current spikes. The physical cause of the discontinuity is 
not documented; no explanation is invented.

## 3. Current-excursion quality flag (F6)

Threshold: **|I| > 1.5 × 0.625 A = 0.9375 A**. The protocol CC setpoint is 0.625 A; a 50% overshoot above that setpoint is not expected during steady CC/CV operation. This is a documented screening heuristic, not an instrument limit. It is derived only from recorded `i_min`/`i_max`; no current value was clipped, replaced, or deleted.

| Excel row | I (A) | |I| / 0.625 A | Flag |
|---|---|---|---|
| 126 | -4.015350 | 6.42x | true |
| 127 | -4.507276 | 7.21x | true |
| 128 | -1.773718 | 2.84x | true |

Cycle 264 is flagged `current_excursion` in both `LFP_cycle_summary.csv` and `LFP_cleaning_log.csv`; its recorded minimum is -4.507276 A (7.21× protocol). Across all 1,498 worksheets with current telemetry, 1 worksheet and 1 cycle exceed the threshold, so **zero false positives** were observed in this dataset. A normal cycle (Cycle_0050 cycle 2) remains unflagged. The flag is also carried into `LFP_staging_cycle_level.csv`; no cycle record was added or renumbered.

## 4. Sensitivity: trend with vs without cycle 264

| Scenario | n | Fade (Ah/100 cycles) | R² | Δ vs published |
|---|---|---|---|---|
| WITH_CYCLE_264_PUBLISHED | 1346 | 0.00720426 | 0.96459224 | +0.0000000000 |
| WITHOUT_CYCLE_264_SENSITIVITY | 1345 | 0.00719332 | 0.96676867 | -0.0000109403 |
| VALID_CYCLES_ONLY_SENSITIVITY | 1343 | 0.00718656 | 0.96695325 | -0.0000177012 |

Excluding cycle 264 changes the fade rate by -0.00001094 Ah/100 cycles (0.152% relative). The point has low leverage because the series spans 1,500 cycles. Exclusion is therefore **not justified** as a data correction; cycle 264 is retained with its flags, and the without-264 result is a sensitivity only.

Final reported metrics are unchanged:

| Metric | Value | Definition |
|---|---|---|
| Proxy reference | 1.220588 Ah | First observed valid discharge (F3 denominator) |
| Last capacity | 1.094775 Ah | Last valid discharge (global cycle 1500) |
| Nominal SOH | 87.582 % | F2: Q / 1.25 Ah × 100 |
| Proxy retention | 89.692 % | F3: Q / proxy reference × 100 |
| Fade rate (published) | 0.007204 Ah/100 cycles | OLS on 1346 VERIFIED-offset cycles |

## 5. Missing cycles and uncertain offsets

40 cycles are absent: 151-170, 1201-1220. 110 cycle rows in Cycle_0200, Cycle_1300 carry `UNDERDETERMINED_TAIL_ALIGNED`; no missing cycle was interpolated or fabricated, and no global ID was silently changed.

## 6. Formula and reference verification

| Formula | Check | Result |
|---|---|---|
| F1 | Raw trapezoidal integration vs stored capacity | 1.234925042 vs 1.234925 Ah — reproduced |
| F2 | Q / 1.25 Ah × 100 | 98.794 % (stored 98.794 %) |
| F3 | Q / first observed valid discharge × 100 | 101.175 % (stored 101.175 %) |
| F3 denominator | Proxy reference row | Cycle_0050 cycle 1 = 1.220588 Ah; observed valid discharge, partial charge, no validated BOL test |
| F4 | Charge capacity / coulombic efficiency | Reported for diagnostics only; UNSUPPORTED_FOR_MODELLING (charge segmentation not independently validated) |
| F6 | abs(I) > 1.5 × 0.625 A = 0.9375 A | Cycle 264 flagged; 1 worksheet(s) flagged in total; raw values preserved |

The first valid **discharge** is used as a proxy baseline; it is not 
a validated beginning-of-life capacity. F2 and F3 are kept separate. 
Charge capacity and CE remain unsupported for modelling.

## 7. Current-unit status

The source header is `I(A/cm2)`. Total amperes is the plausible interpretation because `Surface Area = 0` and the protocol sets 0.625 A (0.5C of 1.25 Ah), but the exported unit is **not instrument-confirmed**. The unit identity is therefore **UNDERDETERMINED**; the source label and raw values are preserved, and all capacity/SOH results remain conditional on the total-ampere interpretation. No claim is made that the source label is wrong.

## 8. Acceptance and recommendation

**Acceptance: PASS_WITH_CONDITIONS.** All closure checks pass, but the following 
documented limitations remain:

- Source header is I(A/cm2); total amperes is plausible from Surface Area=0 and the 0.625 A setpoint, but the exported unit is not instrument-confirmed (UNDERDETERMINED).
- Proxy reference is the first observed valid discharge (1.220588 Ah), not a validated BOL test.
- 40 cycles are absent (151-170 and 1201-1220); Cycle_0200 and Cycle_1300 offsets remain UNDERDETERMINED_TAIL_ALIGNED.
- Physical cell identity and replication are unknown (battery_id = UNKNOWN).
- No measured temperature channel; 25 degC is dataset-level metadata.
- Cycle 264 contains a real over-voltage/current switching transient; cause is not documented.
- Charge capacity and coulombic efficiency are diagnostic only and unsupported for modelling.

**Go/no-go:** **GO** for integration into the master dataset, with conditions:

- carry `quality_flag`, `current_excursion_flag`, `cycle_offset_confidence`, and the proxy-reference label;
- keep cycle 264 in the dataset and treat its exclusion as sensitivity only;
- treat capacity/SOH as conditional on the unit interpretation;
- do not use charge capacity or coulombic efficiency for modelling;
- do not count workbooks/checkpoints as independent cells;
- reconcile missing cycles explicitly when pooling with other chemistries.

This dataset is not perfect, fully clean, or scientific ground truth.

## 9. Tests executed

| Check | Result |
|---|---|
| raw_rows_match_summary | PASS |
| v_max_matches_summary | PASS |
| i_min_matches_summary | PASS |
| f1_capacity_reproduced | PASS |
| voltage_max_cell_is_numeric | PASS |
| current_min_cell_is_numeric | PASS |
| time_reset_evidenced | PASS |
| transient_contribution_small | PASS |
| raw_rows_preserved_no_interpolation | PASS |
| missing_cycle_count_40 | PASS |
| missing_ranges_unchanged | PASS |
| no_duplicate_global_ids | PASS |
| underdetermined_offsets_preserved | PASS |
| no_interpolated_missing_cycles | PASS |
| f2_soh_reproduced | PASS |
| f3_retention_reproduced | PASS |
| proxy_reference_is_first_valid_discharge | PASS |
| last_capacity_unchanged | PASS |
| soh_last_unchanged | PASS |
| retention_last_unchanged | PASS |
| current_unit_not_confirmed | PASS |
| current_excursion_threshold_documented | PASS |
| current_excursion_column_present | PASS |
| cycle_264_current_excursion_flagged | PASS |
| current_excursion_no_false_positives | PASS |
| current_excursion_all_measurement_sheets_checked | PASS |
| current_extremes_preserved | PASS |
| current_excursion_staging_consistent | PASS |
| no_rows_clipped_or_deleted | PASS |
| current_unit_wording_conditional | PASS |
| charge_capacity_ce_unsupported | PASS |
| current_excursion_formula_registered | PASS |
| report_reflects_flag_and_ce_status | PASS |
| sensitivity_with_without_264_retained | PASS |
| validation_overall_pass | PASS |
| all_19_workbooks_processed | PASS |

**36/36 checks passed.** No check is unresolved. The unresolved items listed in §8 are documented data limitations, not failed tests. The original full raw audit was not independently repeated in this closure pass: only `Cycle_0300.xlsx` was re-read for row-level evidence, while the complete 19-workbook execution is recorded in `run_log.txt` and `validation_results.json`.

## 10. Changed files and hashes

| File | SHA-256 |
|---|---|
| LFP_Audit_Report.md | 2e709a608e11def7be9ffd059b716984edb53e33f06c75e2be92788b68df952b |
| LFP_formula_register.csv | ef22f040e67483d63e80b4c6f635d4b85eb4066f7271e6b34692ac6c6089a281 |
| LFP_column_mapping.csv | b81f0eef942d44dd8816565d61c3fe109edce47e3abe1fa2f88fd2af45771479 |
| README.md | aab11ce7a9efa876e9c275a5425e3ed6bd485fd8b699a6a03e3833d32f703622 |
| LFP_preprocessing.py | 520cbbd32d07ccddc07dffa1f7702a1b1936a3d6e5020468a7a37120cb991549 |
| B1_cycle264_evidence.csv | f1b1834daa35dd1cf4dba61145c2190be900f9453a952b99cd0a2ad116d7ef14 |
| B1_trend_sensitivity.csv | c65c626e2107b09fb46d7c61594e8f68c561d9efd0a6a0f16b55d87b2d5046f4 |
| B1_closure_analysis.py | bfff6e9c727025202bf3b376bf90d8fb6482f1f5a7f050a16b970ff2df3ad3d4 |
| LFP_cycle_summary.csv | 1fdee3bcb4714fd74118a651e14a50efb58cefd5c272ba31dce03104b99fcb2b |
| LFP_cleaning_log.csv | 0807077608b359a5c46b6f0f321ca36c27c1778784111d4b5848fc69c9867019 |
| LFP_capacity_soh_feasibility.csv | 2a5f683f04fa03ff6b7217c97af3ff22abe2a1979c3bb3b16424a0c2918ce916 |
| LFP_staging_cycle_level.csv | e6a24fc5911a5322ef2fa137e316b2b151fdc6eb8dab45ccc1739e2858c4daf9 |
| B1_closure_validation.json | e5b780451d0a46d4e27133b5984ff6937187dfc84f1d4238c347299d84bcd2c1 |

`B1_closure_validation.json` records every check and the acceptance status.

## 11. Reproduce

```bash
python B1_LFP_Audit_Output/B1_closure_analysis.py \
  --input-dir . --output-dir B1_LFP_Audit_Output
```
