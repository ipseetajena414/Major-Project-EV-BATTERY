#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LFP_preprocessing.py
====================
Reproducible audit / preprocessing pipeline for the B1 LFP 18650 cycle-ageing
workbooks (condition B1: discharge 0.5C / charge 0.5C).

Scientific assumptions (explicitly conditional):
  * The workbook column header is `I(A/cm2)`.  The workbook metadata reports
    `Surface Area: 0`, and the protocol metadata reports `Charge CC: 0.625 A`
    / `Discharge CC: 0.625 A`.  The measured values are +/-0.624..0.626.
    With a nominal capacity of 1.25 Ah, 0.625 A is exactly 0.5C.  Total amperes
    is therefore the plausible interpretation, but the exported unit is NOT
    instrument-confirmed.  The source label is preserved unchanged; it is not
    established to be an error.  No conversion from current density to current
    is performed.
  * Capacity is calculated ONLY for complete discharge segments identified by
    I < -0.01 A.  Integration uses the trapezoidal rule over adjacent samples
    with 0 < dt <= 60 s and both endpoints in the discharge phase.
  * A cycle-level `current_excursion` flag is raised when any recorded |I|
    exceeds 1.5 x the 0.625 A protocol CC setpoint, i.e. 0.9375 A.  This is a
    documented screening heuristic, not an instrument limit.  Raw values are
    preserved; no rows are clipped or deleted.
  * SOH is reported under two clearly separate definitions:
      - SOH_nominal = Q_discharge / 1.25 Ah * 100   (nominal-capacity based)
      - Retention_BOL = Q_discharge / Q_BOL * 100    (Q_BOL is the first
        OBSERVED valid discharge capacity, used as a proxy beginning-of-life
        reference; no dedicated BOL characterisation test is documented)
    Neither value is clipped.
  * No temperature channel exists in the source workbooks.  The dataset-level
    test temperature (25 degC) is metadata only and is NOT treated as a measured
    per-sample field.
  * Battery / cell identity is not present.  The channel `Un1Ch7` and the source
    folder label `BATTERY 1` are recorded as provenance strings, not as a
    verified physical-cell identifier.
  * No missing cycles are fabricated.  Checkpoint labels are taken from the
    workbook filenames.  Two workbooks contain fewer cycles than the checkpoint
    delta; their global offsets are marked UNDERDETERMINED and tail-aligned only
    as an explicit assumption.

Usage
-----
    python LFP_preprocessing.py --input-dir . --output-dir B1_LFP_Audit_Output

The script preserves all source workbooks unchanged.  It writes:
    LFP_Audit_Report.md
    LFP_file_manifest.csv
    LFP_column_mapping.csv
    LFP_cleaning_log.csv
    LFP_capacity_soh_feasibility.csv
    LFP_formula_register.csv
    LFP_cycle_summary.csv
    LFP_staging_cycle_level.csv
    LFP_staging_sample_raw_rows.csv
    README.md
    validation_results.json
    run_log.txt
and then packages the output directory as B1_LFP_Audit_Output.zip.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import os
import re
import shutil
import statistics
import sys
import time
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DATASET_ID = "B1_LFP_MultiStat"
CONDITION_ID = "B1_Discharge0.5C_Charge0.5C"
NOMINAL_CAPACITY_AH = 1.25
PROTOCOL_V_MIN = 2.50
PROTOCOL_V_MAX = 3.65
VOLTAGE_TOLERANCE_V = 0.05
PHASE_CURRENT_THRESHOLD_A = 0.01
MAX_INTEGRATION_DT_S = 60.0
MIN_PHASE_DURATION_S = 1800.0
MIN_PHASE_CAPACITY_AH = 0.5
PROTOCOL_CURRENT_A = 0.625
CURRENT_EXCURSION_FACTOR = 1.5
CURRENT_EXCURSION_THRESHOLD_A = PROTOCOL_CURRENT_A * CURRENT_EXCURSION_FACTOR
DOI = "10.5281/zenodo.22286449"

# Expected B1 checkpoint exports.  The preflight aborts if any is absent so a
# partial directory can never be mistaken for a full-dataset audit.
EXPECTED_CHECKPOINTS = [
    50, 100, 150, 200, 250, 300, 350, 400,
    500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500,
]

CURRENT_UNIT_STATUS = "UNDERDETERMINED_TOTAL_AMPERES_PLAUSIBLE"
CURRENT_UNIT_NOTE = (
    "Source header is I(A/cm2). Values are interpreted as total current in "
    "amperes because workbook metadata reports Surface Area: 0 and the protocol "
    "reports Charge CC / Discharge CC = 0.625 A (0.5C of 1.25 Ah). The exported "
    "unit is not instrument-confirmed; the source label is preserved and no claim "
    "is made that it is wrong."
)

PROVENANCE = {
    "title": (
        "Experimental Dataset for Cycle Ageing of LFP 18650 Lithium-Ion "
        "Batteries under Different Charge and Discharge C-Rates"
    ),
    "authors": "Noor Raihan Japar, Yousif Al-sagheer, Robert Steinberger-Wilckens",
    "doi": DOI,
    "doi_url": f"https://doi.org/{DOI}",
    "zenodo_record": "https://zenodo.org/records/22286449",
    "institutional_page": (
        "https://research.birmingham.ac.uk/en/datasets/"
        "experimental-dataset-for-cycle-ageing-of-lfp-18650-lithium-ion-ba/"
    ),
    "nominal_capacity_ah": 1.25,
    "chemistry": "LFP (lithium iron phosphate), 18650",
    "test_temperature_c": "25 (dataset-level metadata; no temperature channel in workbooks)",
    "voltage_window_v": "2.50-3.65",
    "file_format": "Microsoft Excel",
    "checkpoint_cadence": "50-cycle exports then 100-cycle exports",
    "verification_status": (
        "VERIFIED on 2026-10-27 via the University of Birmingham research "
        "portal and the Zenodo record landing page.  The DOI resolver itself "
        "returned HTTP 403 in this environment."
    ),
    "instrument": "Solartron 1470E / MultiStat (MultiStat_DCData_1.0, v1.7f)",
    "instrument_doc_status": (
        "Official MultiStat / 1470E documents were located but did not state "
        "the units of the exported I(A/cm2) column; the unit interpretation "
        "above therefore rests on workbook metadata and protocol arithmetic."
    ),
}

# ---------------------------------------------------------------------------
# Regexes for the machine-generated XLSX XML
# ---------------------------------------------------------------------------
ROW_PAT = re.compile(r"<row\b[^>]*>(.*?)</row>", re.S)
CELL_PAT = re.compile(r"<c\b([^>]*?)(?:/>|>(.*?)</c>)", re.S)
R_PAT = re.compile(r'\br="([A-Z]+)\d+"')
T_PAT = re.compile(r'\bt="([^"]+)"')
V_PAT = re.compile(r"<v>(.*?)</v>", re.S)
IS_PAT = re.compile(r"<t[^>]*>(.*?)</t>", re.S)
SI_PAT = re.compile(r"<si>(.*?)</si>", re.S)
SHEET_PAT = re.compile(r"<sheet\b([^>]*)/>")
REL_PAT = re.compile(r"<Relationship\b([^>]*)/>")
ATTR_PAT = re.compile(r'(\w+[\w:]*)\s*=\s*"([^"]*)"')


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_float(value) -> float | None:
    try:
        if value is None:
            return None
        text = str(value).strip()
        if text == "":
            return None
        return float(text)
    except (TypeError, ValueError):
        return None


def fmt(value, digits: int = 6):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return ""
        return f"{value:.{digits}f}"
    return value


def pct(value, digits: int = 3):
    if value is None:
        return ""
    return f"{value:.{digits}f}"


def md_table(headers, rows) -> str:
    out = ["| " + " | ".join(headers) + " |"]
    out.append("|" + "|".join(["---"] * len(headers)) + "|")
    for row in rows:
        cells = []
        for value in row:
            text = "" if value is None else str(value)
            cells.append(text.replace("|", "\\|").replace("\n", " "))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)


def col_index(letters: str) -> int:
    n = 0
    for ch in letters:
        if "A" <= ch <= "Z":
            n = n * 26 + (ord(ch) - 64)
        else:
            break
    return n - 1


def parse_row(row_xml: str, shared: list[str]) -> dict[int, str]:
    cells: dict[int, str] = {}
    for match in CELL_PAT.finditer(row_xml):
        attrs = match.group(1) or ""
        inner = match.group(2) or ""
        ref = R_PAT.search(attrs)
        if not ref:
            continue
        idx = col_index(ref.group(1))
        tmatch = T_PAT.search(attrs)
        ctype = tmatch.group(1) if tmatch else None
        if ctype == "inlineStr":
            is_match = re.search(r"<is>(.*?)</is>", inner, re.S)
            value = ""
            if is_match:
                value = "".join(IS_PAT.findall(is_match.group(1)))
        else:
            vmatch = V_PAT.search(inner)
            if not vmatch:
                cells[idx] = ""
                continue
            value = vmatch.group(1)
            if ctype == "s":
                try:
                    value = shared[int(value)]
                except (ValueError, IndexError):
                    value = ""
            elif ctype == "b":
                value = "true" if value == "1" else "false"
        cells[idx] = html.unescape(value)
    return cells


def cells_to_list(cells: dict[int, str]) -> list[str]:
    if not cells:
        return []
    max_idx = max(cells)
    return [cells.get(i, "") for i in range(max_idx + 1)]


def read_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    raw = zf.read("xl/sharedStrings.xml").decode("utf-8", "ignore")
    out = []
    for si in SI_PAT.findall(raw):
        out.append(html.unescape("".join(IS_PAT.findall(si))))
    return out


def workbook_sheets(zf: zipfile.ZipFile) -> list[tuple[str, str]]:
    wb = zf.read("xl/workbook.xml").decode("utf-8", "ignore")
    rels = zf.read("xl/_rels/workbook.xml.rels").decode("utf-8", "ignore")
    rel_map = {}
    for match in REL_PAT.finditer(rels):
        attrs = dict(ATTR_PAT.findall(match.group(1)))
        rid = attrs.get("Id")
        target = attrs.get("Target")
        if rid and target:
            rel_map[rid] = target
    sheets = []
    for match in SHEET_PAT.finditer(wb):
        attrs = dict(ATTR_PAT.findall(match.group(1)))
        name = html.unescape(attrs.get("name", ""))
        rid = attrs.get("r:id")
        target = rel_map.get(rid, "")
        if target.startswith("/"):
            target = target.lstrip("/")
        elif not target.startswith("xl/"):
            target = "xl/" + target
        sheets.append((name, target))
    return sheets


def sheet_type(name: str) -> str:
    low = name.lower()
    if "file list" in low:
        return "file_list"
    if "ocv" in low:
        return "ocv"
    if "cycle" in low:
        return "cycle"
    if "rest" in low:
        return "rest"
    return "auxiliary"


def classify_current(current: float) -> str:
    if current > PHASE_CURRENT_THRESHOLD_A:
        return "charge"
    if current < -PHASE_CURRENT_THRESHOLD_A:
        return "discharge"
    return "rest"


def parse_date_time(date_text, time_text) -> tuple[str, str]:
    date_text = str(date_text or "").strip()
    time_text = str(time_text or "").strip()
    if not date_text:
        return "", ""
    for date_fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y"):
        try:
            dt = datetime.strptime(date_text, date_fmt)
            break
        except ValueError:
            dt = None
    if dt is None:
        return "", ""
    if time_text:
        for time_fmt in ("%H:%M:%S", "%H:%M"):
            try:
                t = datetime.strptime(time_text, time_fmt).time()
                dt = dt.replace(hour=t.hour, minute=t.minute, second=t.second)
                break
            except ValueError:
                pass
    return dt.strftime("%Y-%m-%d"), dt.strftime("%H:%M:%S")


def parse_protocol(text: str) -> dict:
    text = html.unescape(text or "").replace("\t", " ")
    out = {
        "charge_cc_a": None,
        "charge_cv_v": None,
        "charge_xi_a": None,
        "discharge_cc_a": None,
        "discharge_xv_v": None,
        "export_cycle_count": None,
    }
    patterns = {
        "charge_cc_a": r"Charge CC:\s*([0-9.]+)\s*A",
        "charge_cv_v": r"CV:\s*([0-9.]+)\s*V",
        "charge_xi_a": r"XI:\s*([0-9.]+)\s*A",
        "discharge_cc_a": r"Discharge CC:\s*([0-9.]+)\s*A",
        "discharge_xv_v": r"XV:\s*([0-9.]+)\s*V",
        "export_cycle_count": r"x\s*(\d+)",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, text, re.I)
        if match:
            out[key] = int(match.group(1)) if key == "export_cycle_count" else float(match.group(1))
    return out


def new_measurement_stats() -> dict:
    return {
        "rows_total": 0,
        "max_cols": 0,
        "header_row": None,
        "headers": [],
        "meta": {},
        "data_rows": 0,
        "missing_cells": 0,
        "nonnumeric_cells": 0,
        "duplicate_timestamps": 0,
        "duplicate_rows": 0,
        "monotonic_violations": 0,
        "time_resets_within": 0,
        "cross_sheet_time_reset": False,
        "dt_list": [],
        "dt_min": None,
        "dt_max": None,
        "dt_median": None,
        "irregular_dt_count": 0,
        "gap_count_gt5": 0,
        "gap_count_gt60": 0,
        "v_min": None,
        "v_max": None,
        "v_sum": 0.0,
        "v_count": 0,
        "i_min": None,
        "i_max": None,
        "current_excursion_flag": False,
        "i_sum": 0.0,
        "i_count": 0,
        "i_pos": 0,
        "i_neg": 0,
        "i_zero": 0,
        "out_of_protocol_v": 0,
        "severe_out_of_protocol_v": 0,
        "phase_durations": {"charge": 0.0, "discharge": 0.0, "rest": 0.0},
        "phase_capacities": {"charge": 0.0, "discharge": 0.0},
        "phase_stats": {
            "charge": {"start": None, "end": None, "n": 0, "sum_abs_i": 0.0,
                       "vmin": None, "vmax": None},
            "discharge": {"start": None, "end": None, "n": 0, "sum_abs_i": 0.0,
                          "vmin": None, "vmax": None},
            "rest": {"start": None, "end": None, "n": 0, "sum_abs_i": 0.0,
                     "vmin": None, "vmax": None},
        },
        "phase_sequence_raw": [],
        "first_t": None,
        "last_t": None,
        "duration_s": None,
        "charge_ok": False,
        "discharge_ok": False,
        "cycle_valid": False,
        "quality_flags": [],
        "sample_rows": [],
        "date_iso": "",
        "time_iso": "",
    }


def scan_measurement(zf: zipfile.ZipFile, target: str, shared: list[str],
                     sheet_name: str, collect_sample: bool = False,
                     sample_context: dict | None = None) -> dict:
    raw = zf.read(target).decode("utf-8", "ignore")
    st = new_measurement_stats()
    prev = None
    seen_t: set[float] = set()
    seen_rows: set[tuple] = set()

    for row_idx, match in enumerate(ROW_PAT.finditer(raw), start=1):
        cells = parse_row(match.group(1), shared)
        if not cells:
            continue
        st["rows_total"] += 1
        values = cells_to_list(cells)
        st["max_cols"] = max(st["max_cols"], len(values))

        if st["header_row"] is None:
            lowered = {str(v).strip().lower() for v in values}
            if lowered & {"t(seconds)", "time (sec)", "time(sec)", "time (s)"}:
                st["header_row"] = row_idx
                st["headers"] = [str(v).strip() for v in values]
                continue
            line = " ".join(str(v).strip() for v in values if str(v).strip())
            meta_match = re.match(r"\s*([^:]+):\s*(.*)$", line)
            if meta_match:
                key = meta_match.group(1).strip()
                val = meta_match.group(2).strip()
                if key in st["meta"]:
                    st["meta"][key] = str(st["meta"][key]) + " | " + val
                else:
                    st["meta"][key] = val
            continue

        # ---- data section -------------------------------------------------
        if len(values) < 3:
            if safe_float(values[0]) is not None:
                st["missing_cells"] += 3 - len(values)
            continue

        t_raw, e_raw, i_raw = values[0], values[1], values[2]
        t_val = safe_float(t_raw)
        if t_val is None:
            # Post-header metadata line (e.g. "End Header: ..."); not a row.
            line = " ".join(str(v).strip() for v in values if str(v).strip())
            if line:
                st["meta"]["post_header_lines"] = str(
                    st["meta"].get("post_header_lines", "")
                ) + (" | " if st["meta"].get("post_header_lines") else "") + line
            continue
        e_val = safe_float(e_raw)
        i_val = safe_float(i_raw)
        if str(e_raw).strip() == "":
            st["missing_cells"] += 1
        elif e_val is None:
            st["nonnumeric_cells"] += 1
        if str(i_raw).strip() == "":
            st["missing_cells"] += 1
        elif i_val is None:
            st["nonnumeric_cells"] += 1
        if e_val is None or i_val is None:
            continue

        st["data_rows"] += 1
        if st["first_t"] is None:
            st["first_t"] = t_val
        st["last_t"] = t_val

        if t_val in seen_t:
            st["duplicate_timestamps"] += 1
        else:
            seen_t.add(t_val)
        row_key = (round(t_val, 3), round(e_val, 6), round(i_val, 6))
        if row_key in seen_rows:
            st["duplicate_rows"] += 1
        else:
            seen_rows.add(row_key)

        phase = classify_current(i_val)
        if not st["phase_sequence_raw"] or st["phase_sequence_raw"][-1] != phase:
            st["phase_sequence_raw"].append(phase)

        # phase-level stats
        ps = st["phase_stats"][phase]
        if ps["start"] is None:
            ps["start"] = t_val
        ps["end"] = t_val
        ps["n"] += 1
        ps["sum_abs_i"] += abs(i_val)
        ps["vmin"] = e_val if ps["vmin"] is None else min(ps["vmin"], e_val)
        ps["vmax"] = e_val if ps["vmax"] is None else max(ps["vmax"], e_val)

        # overall stats
        st["v_min"] = e_val if st["v_min"] is None else min(st["v_min"], e_val)
        st["v_max"] = e_val if st["v_max"] is None else max(st["v_max"], e_val)
        st["v_sum"] += e_val
        st["v_count"] += 1
        st["i_min"] = i_val if st["i_min"] is None else min(st["i_min"], i_val)
        st["i_max"] = i_val if st["i_max"] is None else max(st["i_max"], i_val)
        st["i_sum"] += i_val
        st["i_count"] += 1
        if i_val > 1e-9:
            st["i_pos"] += 1
        elif i_val < -1e-9:
            st["i_neg"] += 1
        else:
            st["i_zero"] += 1
        if e_val < PROTOCOL_V_MIN - VOLTAGE_TOLERANCE_V or e_val > PROTOCOL_V_MAX + VOLTAGE_TOLERANCE_V:
            st["out_of_protocol_v"] += 1
        if e_val < PROTOCOL_V_MIN - 0.10 or e_val > PROTOCOL_V_MAX + 0.15:
            st["severe_out_of_protocol_v"] += 1

        if prev is not None:
            prev_t, prev_e, prev_i, prev_phase = prev
            if t_val < prev_t - 1e-9:
                st["monotonic_violations"] += 1
                st["time_resets_within"] += 1
            dt = t_val - prev_t
            if dt > 0:
                st["dt_list"].append(dt)
                st["dt_min"] = dt if st["dt_min"] is None else min(st["dt_min"], dt)
                st["dt_max"] = dt if st["dt_max"] is None else max(st["dt_max"], dt)
                if abs(dt - 1.0) > 0.01:
                    st["irregular_dt_count"] += 1
                if dt > 5.0:
                    st["gap_count_gt5"] += 1
                if dt > 60.0:
                    st["gap_count_gt60"] += 1
                if prev_phase == phase and dt <= MAX_INTEGRATION_DT_S:
                    st["phase_durations"][phase] += dt
                    if phase in ("charge", "discharge"):
                        st["phase_capacities"][phase] += (
                            0.5 * (abs(prev_i) + abs(i_val)) * dt / 3600.0
                        )

        if collect_sample and sample_context is not None:
            st["sample_rows"].append({
                "dataset_id": sample_context.get("dataset_id", DATASET_ID),
                "source_file": sample_context.get("source_file", ""),
                "worksheet": sheet_name,
                "cycle_checkpoint": sample_context.get("cycle_checkpoint", ""),
                "global_cycle_est": sample_context.get("global_cycle_est", ""),
                "time_sec": fmt(t_val, 3),
                "voltage_v": fmt(e_val, 9),
                "current_a": fmt(i_val, 9),
                "charge_discharge_phase": phase,
                "quality_flag": "ok",
                "is_interpolated": "false",
                "value_origin": "measured",
            })

        prev = (t_val, e_val, i_val, phase)

    # ---- finalize ---------------------------------------------------------
    if st["dt_list"]:
        st["dt_median"] = statistics.median(st["dt_list"])
    if st["first_t"] is not None and st["last_t"] is not None:
        st["duration_s"] = st["last_t"] - st["first_t"]
    for phase in ("charge", "discharge", "rest"):
        ps = st["phase_stats"][phase]
        ps["mean_abs_i"] = (ps["sum_abs_i"] / ps["n"]) if ps["n"] else None
        ps["duration_s"] = (
            (ps["end"] - ps["start"]) if ps["start"] is not None and ps["end"] is not None else None
        )
    st["phase_sequence"] = ">".join(p[0].upper() for p in st["phase_sequence_raw"])

    charge_cap = st["phase_capacities"]["charge"]
    discharge_cap = st["phase_capacities"]["discharge"]
    st["charge_ok"] = bool(
        charge_cap >= MIN_PHASE_CAPACITY_AH
        and st["phase_durations"]["charge"] >= MIN_PHASE_DURATION_S
        and (st["phase_stats"]["charge"]["vmax"] or 0) >= PROTOCOL_V_MAX - 0.10
    )
    st["discharge_ok"] = bool(
        discharge_cap >= MIN_PHASE_CAPACITY_AH
        and st["phase_durations"]["discharge"] >= MIN_PHASE_DURATION_S
        and (st["phase_stats"]["discharge"]["vmin"] or 99) <= PROTOCOL_V_MIN + 0.05
    )
    st["cycle_valid"] = st["charge_ok"] and st["discharge_ok"]

    st["date_iso"], st["time_iso"] = parse_date_time(
        st["meta"].get("Date"), st["meta"].get("Time")
    )
    return st


def compute_measurement_flags(st: dict, stype: str) -> list[str]:
    flags = []
    if st["monotonic_violations"] > 0:
        flags.append("time_reset_within")
    if st["cross_sheet_time_reset"]:
        flags.append("cross_sheet_time_reset")
    if st["duplicate_timestamps"] > 0:
        flags.append("duplicate_timestamp")
    if st["duplicate_rows"] > 0:
        flags.append("duplicate_row")
    if st["gap_count_gt5"] > 0:
        flags.append("time_gap_gt5s")
    if st["out_of_protocol_v"] > 0:
        flags.append("out_of_protocol_voltage")
    i_extreme = max(abs(st["i_min"] or 0.0), abs(st["i_max"] or 0.0))
    st["current_excursion_flag"] = i_extreme > CURRENT_EXCURSION_THRESHOLD_A
    if st["current_excursion_flag"]:
        flags.append("current_excursion")
    if st["nonnumeric_cells"] > 0:
        flags.append("nonnumeric_cell")
    if st["missing_cells"] > 0:
        flags.append("missing_cell")
    if stype == "cycle":
        if st["i_pos"] == 0 or st["i_neg"] == 0:
            flags.append("polarity_anomaly")
        if not st["charge_ok"]:
            flags.append("partial_charge")
        if not st["discharge_ok"]:
            flags.append("partial_discharge")
        ce = None
        if st["phase_capacities"]["charge"] > 0:
            ce = st["phase_capacities"]["discharge"] / st["phase_capacities"]["charge"] * 100.0
        if ce is not None and ce > 120.0:
            flags.append("ce_gt_120")
    if not flags:
        flags.append("ok")
    st["quality_flags"] = flags
    return flags


def scan_file_list(zf: zipfile.ZipFile, target: str, shared: list[str]) -> dict:
    raw = zf.read(target).decode("utf-8", "ignore")
    rows = []
    header_idx = None
    headers = []
    for row_idx, match in enumerate(ROW_PAT.finditer(raw), start=1):
        cells = parse_row(match.group(1), shared)
        if not cells:
            continue
        values = cells_to_list(cells)
        rows.append(values)
        if header_idx is None:
            lowered = {str(v).strip().lower() for v in values}
            if "name" in lowered and "run" in lowered:
                header_idx = row_idx
                headers = [str(v).strip() for v in values]
    source_path = ""
    for values in rows:
        if len(values) > 1 and str(values[0]).strip().lower().startswith("file"):
            source_path = str(values[1]).strip()
            break
    data_rows = 0
    cycle_names = []
    repeats = []
    serials = []
    protocol_text_parts = []
    if header_idx is not None:
        for values in rows[header_idx:]:
            if len(values) > 1 and str(values[0]).strip().startswith("Run"):
                data_rows += 1
                cycle_names.append(str(values[0]).strip())
                if len(values) > 4:
                    repeats.append(str(values[4]).strip())
                if len(values) > 5:
                    serials.append(str(values[5]).strip())
                protocol_text_parts.append(" ".join(str(v) for v in values[5:]))
    return {
        "rows_total": len(rows),
        "max_cols": max((len(r) for r in rows), default=0),
        "header_row": header_idx,
        "headers": headers,
        "data_rows": data_rows,
        "source_path": html.unescape(source_path),
        "cycle_names": cycle_names,
        "repeats": repeats,
        "serials": serials,
        "protocol_text": " ".join(protocol_text_parts),
        "date_iso": "",
        "time_iso": "",
        "quality_flags": ["ok"],
    }


def scan_auxiliary(zf: zipfile.ZipFile, target: str, shared: list[str]) -> dict:
    raw = zf.read(target).decode("utf-8", "ignore")
    rows = []
    for match in ROW_PAT.finditer(raw):
        cells = parse_row(match.group(1), shared)
        if not cells:
            continue
        rows.append(cells_to_list(cells))
    headers = rows[0] if rows else []
    data_rows = max(0, len(rows) - 1)
    header_text = " ".join(str(h) for h in headers).lower()
    if not rows:
        note = "empty worksheet"
        flags = ["empty_sheet"]
        status = "EMPTY"
    elif data_rows == 0:
        note = "empty template / header only"
        flags = ["empty_sheet"]
        status = "EMPTY"
    elif "capacity (ah)" in header_text and "discharge current" in header_text:
        note = "manual cycle capacity/energy summary (not part of the raw protocol export)"
        flags = ["auxiliary_nonstandard"]
        status = "INSPECTED_NON_STANDARD"
    elif "cc time (sec)" in header_text:
        note = "manual charge CC/CV summary (not part of the raw protocol export)"
        flags = ["auxiliary_nonstandard"]
        status = "INSPECTED_NON_STANDARD"
    elif "time (sec)" in header_text and "voltage (v)" in header_text:
        note = "manual voltage/current summary (not part of the raw protocol export)"
        flags = ["auxiliary_nonstandard"]
        status = "INSPECTED_NON_STANDARD"
    else:
        note = "non-standard auxiliary sheet"
        flags = ["auxiliary_nonstandard"]
        status = "INSPECTED_NON_STANDARD"
    return {
        "rows_total": len(rows),
        "max_cols": max((len(r) for r in rows), default=0),
        "header_row": 1 if rows else None,
        "headers": headers,
        "data_rows": data_rows,
        "quality_flags": flags,
        "aux_note": note,
        "inspection_status": status,
        "date_iso": "",
        "time_iso": "",
    }


def scan_workbook(path: Path, collect_sample: bool = False) -> dict:
    zf = zipfile.ZipFile(path)
    shared = read_shared_strings(zf)
    sheets = workbook_sheets(zf)
    file_list = None
    scans = []

    for idx, (name, target) in enumerate(sheets, start=1):
        stype = sheet_type(name)
        if stype == "file_list":
            scan = scan_file_list(zf, target, shared)
            file_list = scan
        elif stype in ("cycle", "ocv", "rest"):
            sample_ctx = None
            do_sample = bool(
                collect_sample
                and path.name == "Cycle_0050.xlsx"
                and name.endswith("Cycle02")
            )
            if do_sample:
                sample_ctx = {
                    "dataset_id": DATASET_ID,
                    "source_file": path.name,
                    "cycle_checkpoint": 50,
                    "global_cycle_est": 2,
                }
            scan = scan_measurement(
                zf, target, shared, name,
                collect_sample=do_sample, sample_context=sample_ctx,
            )
            scan["inspection_status"] = "INSPECTED"
        else:
            scan = scan_auxiliary(zf, target, shared)
        scan["sheet_name"] = name
        scan["sheet_index"] = idx
        scan["sheet_type"] = stype
        scan["target"] = target
        scans.append(scan)

    # Cross-sheet time continuity for measurement sheets in workbook order.
    prev_last_t = None
    cross_resets = 0
    for scan in scans:
        if scan["sheet_type"] not in ("cycle", "ocv", "rest"):
            continue
        if prev_last_t is not None and scan["first_t"] is not None:
            if scan["first_t"] < prev_last_t - 1.0:
                scan["cross_sheet_time_reset"] = True
                cross_resets += 1
        if scan["last_t"] is not None:
            prev_last_t = scan["last_t"]

    for scan in scans:
        if scan["sheet_type"] in ("cycle", "ocv", "rest"):
            compute_measurement_flags(scan, scan["sheet_type"])

    cycles = [s for s in scans if s["sheet_type"] == "cycle"]
    source_path = file_list["source_path"] if file_list else ""
    experiment_match = re.search(r"EXPERIMENT\s+(\d+)", source_path, re.I)
    experiment_no = int(experiment_match.group(1)) if experiment_match else None
    protocol = parse_protocol(file_list["protocol_text"] if file_list else "")
    checkpoint_match = re.search(r"Cycle_(\d+)", path.name, re.I)
    checkpoint = int(checkpoint_match.group(1)) if checkpoint_match else None

    first_date = cycles[0]["date_iso"] if cycles else ""
    last_date = cycles[-1]["date_iso"] if cycles else ""
    if cycles:
        first_date = cycles[0]["date_iso"] or first_date
        last_date = cycles[-1]["date_iso"] or last_date

    return {
        "workbook_id": path.stem,
        "filename": path.name,
        "path": str(path),
        "size_bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "checkpoint_label": checkpoint,
        "source_path": source_path,
        "experiment_no": experiment_no,
        "protocol": protocol,
        "file_list": file_list,
        "scans": scans,
        "cycles": cycles,
        "n_cycles": len(cycles),
        "cross_sheet_resets": cross_resets,
        "first_date": first_date,
        "last_date": last_date,
        "first_time": cycles[0]["time_iso"] if cycles else "",
        "last_time": cycles[-1]["time_iso"] if cycles else "",
        "max_file_list_repeat": max(
            (int(x) for x in (file_list["repeats"] if file_list else []) if x.isdigit()),
            default=None,
        ),
    }


def linear_regression(xs, ys):
    n = len(xs)
    if n < 2:
        return None, None, None
    mx = sum(xs) / n
    my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    if sxx == 0:
        return None, None, None
    slope = sxy / sxx
    intercept = my - slope * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, ys))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return slope, intercept, r2


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> int:
    parser = argparse.ArgumentParser(description="B1 LFP dataset audit / preprocessing")
    parser.add_argument("--input-dir", default=".", help="directory containing Cycle_*.xlsx")
    parser.add_argument("--output-dir", default="B1_LFP_Audit_Output", help="output directory")
    parser.add_argument("--zip-path", default="B1_LFP_Audit_Output.zip", help="output ZIP path")
    args = parser.parse_args()

    t_start = time.time()
    input_dir = Path(args.input_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    zip_path = Path(args.zip_path).resolve()

    log_lines = []

    def log(message: str) -> None:
        line = f"[{now_iso()}] {message}"
        print(line, flush=True)
        log_lines.append(line)

    # Keep a copy of the generating script with the deliverables.  A clean
    # output directory may be used on every run, so the script is copied from
    # its execution location into the output before packaging.
    src_script = Path(__file__).resolve()
    dst_script = (output_dir / "LFP_preprocessing.py").resolve()
    if src_script != dst_script:
        shutil.copyfile(src_script, dst_script)

    workbooks_paths = sorted(
        input_dir.glob("Cycle_*.xlsx"),
        key=lambda p: int(re.search(r"Cycle_(\d+)", p.name).group(1)),
    )
    if not workbooks_paths:
        print(f"ERROR: no Cycle_*.xlsx found in {input_dir}", file=sys.stderr)
        return 2

    # ------------------------------------------------------------------
    # Preflight inventory: all 19 expected checkpoints must be present
    # before any processing starts.  This prevents a partial directory from
    # being reported as a full-dataset audit.
    # ------------------------------------------------------------------
    inventory = {}
    duplicate_checkpoints = []
    for path in workbooks_paths:
        cp = int(re.search(r"Cycle_(\d+)", path.name).group(1))
        if cp in inventory:
            duplicate_checkpoints.append(cp)
        inventory[cp] = path
    missing_checkpoints = [cp for cp in EXPECTED_CHECKPOINTS if cp not in inventory]
    unexpected_checkpoints = sorted(cp for cp in inventory if cp not in EXPECTED_CHECKPOINTS)

    log(f"Input directory: {input_dir}")
    log(f"Output directory: {output_dir}")
    log(f"Preflight inventory: {len(workbooks_paths)} workbook file(s) found; "
        f"{len(EXPECTED_CHECKPOINTS)} expected")
    for cp in EXPECTED_CHECKPOINTS:
        p = inventory.get(cp)
        if p is None:
            log(f"  checkpoint {cp:>4}: MISSING")
        else:
            log(f"  checkpoint {cp:>4}: {p.name} ({p.stat().st_size / 1e6:.1f} MB)")
    if unexpected_checkpoints:
        log(f"WARNING: unexpected checkpoint(s) outside the B1 set: {unexpected_checkpoints}")
    if duplicate_checkpoints:
        log(f"ERROR: duplicate workbook(s) for checkpoint(s) {duplicate_checkpoints}")
    if missing_checkpoints:
        log(f"ERROR: missing expected workbook(s) for checkpoint(s) {missing_checkpoints}; "
            f"aborting before processing so no partial run can be reported as complete.")
        return 2
    if duplicate_checkpoints:
        return 2
    log(f"Preflight PASS: all {len(EXPECTED_CHECKPOINTS)} expected B1 workbooks are present.")

    workbooks = []
    workbook_errors = []
    sample_rows = []
    for idx, path in enumerate(workbooks_paths, start=1):
        try:
            wb = scan_workbook(path, collect_sample=True)
        except Exception as exc:  # noqa: BLE001 - explicit per-file error ledger
            message = f"{type(exc).__name__}: {exc}"
            workbook_errors.append({
                "filename": path.name,
                "size_bytes": path.stat().st_size,
                "error": message,
            })
            log(f"[{idx}/{len(workbooks_paths)}] {path.name}: ERROR {message} "
                f"(recorded in manifest; processing continues)")
            continue
        for scan in wb["scans"]:
            if scan.get("sample_rows"):
                sample_rows.extend(scan["sample_rows"])
        workbooks.append(wb)
        log(
            f"[{idx}/{len(workbooks_paths)}] {path.name}: "
            f"{len(wb['scans'])} sheets, {wb['n_cycles']} cycles, "
            f"{wb['first_date']}..{wb['last_date']}, "
            f"cross-sheet resets={wb['cross_sheet_resets']}"
        )
    log(f"Scanning complete: {len(workbooks)}/{len(workbooks_paths)} workbooks processed, "
        f"{len(workbook_errors)} error(s).")

    # ------------------------------------------------------------------
    # Global cycle assignment (explicit, with underdetermined gaps)
    # ------------------------------------------------------------------
    prev_checkpoint = 0
    for wb in workbooks:
        cp = wb["checkpoint_label"]
        n = wb["n_cycles"]
        if cp is None:
            wb["offset_start"] = None
            wb["offset_confidence"] = "UNDERDETERMINED_NO_CHECKPOINT"
            wb["missing_before"] = None
            continue
        expected = cp - prev_checkpoint
        missing_before = max(0, expected - n)
        offset = cp - n + 1
        confidence = "VERIFIED" if missing_before == 0 else "UNDERDETERMINED_TAIL_ALIGNED"
        wb["expected_since_prev"] = expected
        wb["missing_before"] = missing_before
        wb["offset_start"] = offset
        wb["offset_confidence"] = confidence
        for i, scan in enumerate(wb["cycles"], start=1):
            scan["cycle_id_within_file"] = i
            scan["global_cycle_est"] = offset + i - 1
            scan["offset_confidence"] = confidence
            scan["missing_before"] = missing_before
        prev_checkpoint = cp

    # BOL reference: first valid discharge capacity at global cycle 1.
    bol_row = None
    for wb in workbooks:
        for scan in wb["cycles"]:
            if scan.get("global_cycle_est") == 1 and scan["discharge_ok"]:
                bol_row = scan
                break
        if bol_row:
            break
    if bol_row is None:
        for wb in workbooks:
            for scan in wb["cycles"]:
                if scan["discharge_ok"]:
                    bol_row = scan
                    break
            if bol_row:
                break
    q_bol = bol_row["phase_capacities"]["discharge"] if bol_row else None

    # ------------------------------------------------------------------
    # Build cycle rows and feasibility rows
    # ------------------------------------------------------------------
    cycle_rows = []
    feasibility_rows = []
    for wb in workbooks:
        for scan in wb["cycles"]:
            qchg_raw = scan["phase_capacities"]["charge"]
            qdis_raw = scan["phase_capacities"]["discharge"]
            qdis = qdis_raw if scan["discharge_ok"] else None
            qchg = qchg_raw if scan["charge_ok"] else None
            ce = None
            if qdis is not None and qchg is not None and qchg > 0:
                ce = qdis / qchg * 100.0
            soh = qdis / NOMINAL_CAPACITY_AH * 100.0 if qdis is not None else None
            retention = qdis / q_bol * 100.0 if (qdis is not None and q_bol) else None
            flags = list(scan["quality_flags"])
            if scan.get("offset_confidence") != "VERIFIED":
                flags.append("underdetermined_cycle_offset")
            if retention is not None and retention > 100.0:
                flags.append("retention_gt_100_no_clip")
            if soh is not None and soh > 100.0:
                flags.append("soh_nominal_gt_100_no_clip")

            notes = []
            if not scan["charge_ok"]:
                notes.append("charge phase incomplete/absent")
            if not scan["discharge_ok"]:
                notes.append("discharge phase incomplete/absent")
            if scan.get("offset_confidence") != "VERIFIED":
                notes.append(
                    f"global offset underdetermined: {scan.get('missing_before')} cycle(s) "
                    "missing before this checkpoint; tail-aligned assumption"
                )

            capacity_status = (
                "COMPUTED_VERIFIED_WITH_CONDITIONS"
                if qdis is not None
                else "BLOCKED_PARTIAL_OR_MISSING_DISCHARGE"
            )
            cycle_rows.append({
                "dataset_id": DATASET_ID,
                "source_file": wb["filename"],
                "workbook_id": wb["workbook_id"],
                "condition_id": CONDITION_ID,
                "battery_id": "UNKNOWN",
                "channel_id": "Un1Ch7",
                "cycle_checkpoint": wb["checkpoint_label"],
                "cycle_id_within_file": scan.get("cycle_id_within_file", ""),
                "global_cycle_est": scan.get("global_cycle_est", ""),
                "cycle_offset_confidence": scan.get("offset_confidence", ""),
                "date_iso": scan["date_iso"],
                "time_iso": scan["time_iso"],
                "rows": scan["data_rows"],
                "charge_duration_s": fmt(scan["phase_durations"]["charge"], 1),
                "discharge_duration_s": fmt(scan["phase_durations"]["discharge"], 1),
                "rest_duration_s": fmt(scan["phase_durations"]["rest"], 1),
                "v_min": fmt(scan["v_min"], 6),
                "v_max": fmt(scan["v_max"], 6),
                "v_mean": fmt(scan["v_sum"] / scan["v_count"] if scan["v_count"] else None, 6),
                "i_min": fmt(scan["i_min"], 6),
                "i_max": fmt(scan["i_max"], 6),
                "current_excursion_flag": str(bool(scan["current_excursion_flag"])).lower(),
                "i_mean": fmt(scan["i_sum"] / scan["i_count"] if scan["i_count"] else None, 6),
                "i_positive_count": scan["i_pos"],
                "i_negative_count": scan["i_neg"],
                "i_zero_count": scan["i_zero"],
                "capacity_charge_ah": fmt(qchg, 6),
                "capacity_discharge_ah": fmt(qdis, 6),
                "raw_charge_integral_ah": fmt(qchg_raw, 6),
                "raw_discharge_integral_ah": fmt(qdis_raw, 6),
                "coulombic_efficiency_pct": fmt(ce, 3),
                "bol_reference_ah": fmt(q_bol, 6),
                "soh_nominal_pct": fmt(soh, 3),
                "retention_bol_pct": fmt(retention, 3),
                "phase_sequence": scan.get("phase_sequence", ""),
                "cycle_valid": str(bool(scan["cycle_valid"])).lower(),
                "quality_flags": ";".join(flags),
                "capacity_status": capacity_status,
                "notes": "; ".join(notes),
            })

            blockers = []
            if not scan["discharge_ok"]:
                blockers.append("discharge segment incomplete or absent")
            if not scan["charge_ok"]:
                blockers.append("charge segment incomplete or absent (discharge capacity may still be valid)")
            if scan.get("offset_confidence") != "VERIFIED":
                blockers.append("global cycle offset underdetermined (missing cycles before checkpoint)")
            if q_bol is None:
                blockers.append("no valid reference discharge for a proxy BOL capacity")
            feasibility_rows.append({
                "workbook_id": wb["workbook_id"],
                "checkpoint_label": wb["checkpoint_label"],
                "source_file": wb["filename"],
                "worksheet": scan["sheet_name"],
                "cycle_id_within_file": scan.get("cycle_id_within_file", ""),
                "global_cycle_est": scan.get("global_cycle_est", ""),
                "cycle_offset_confidence": scan.get("offset_confidence", ""),
                "total_current_status": CURRENT_UNIT_STATUS,
                "discharge_segment_complete": str(bool(scan["discharge_ok"])).lower(),
                "discharge_capacity_ah": fmt(qdis, 6),
                "reference_bol_capacity_ah": fmt(q_bol, 6),
                "capacity_status": capacity_status,
                "soh_nominal_pct": fmt(soh, 3),
                "soh_status": "COMPUTED" if soh is not None else "BLOCKED_NO_VALID_DISCHARGE_CAPACITY",
                "retention_bol_pct": fmt(retention, 3),
                "retention_status": (
                    "COMPUTED" if retention is not None
                    else ("BLOCKED_NO_VALID_REFERENCE_DISCHARGE" if q_bol is None
                          else "BLOCKED_NO_VALID_DISCHARGE_CAPACITY")
                ),
                "feasibility_overall": (
                    "BLOCKED" if qdis is None
                    else ("FEASIBLE_WITH_CONDITIONS" if blockers else "FEASIBLE")
                ),
                "blockers": "; ".join(blockers),
            })

    # ------------------------------------------------------------------
    # Manifest
    # ------------------------------------------------------------------
    manifest_rows = []
    for wb in workbooks:
        for scan in wb["scans"]:
            if scan["sheet_type"] in ("cycle", "ocv", "rest", "file_list"):
                status = scan.get("inspection_status", "INSPECTED")
                notes = ""
                if scan["sheet_type"] == "cycle" and not scan["cycle_valid"]:
                    notes = "cycle incomplete: " + ";".join(scan["quality_flags"])
            else:
                status = scan.get("inspection_status", "INSPECTED_NON_STANDARD")
                notes = scan.get("aux_note", "")
            manifest_rows.append({
                "archive_member": wb["filename"],
                "source_path": wb["source_path"],
                "filename": wb["filename"],
                "extension": ".xlsx",
                "size_bytes": wb["size_bytes"],
                "sha256": wb["sha256"],
                "workbook_id": wb["workbook_id"],
                "checkpoint_label": wb["checkpoint_label"],
                "worksheet_index": scan["sheet_index"],
                "worksheet": scan["sheet_name"],
                "sheet_type": scan["sheet_type"],
                "header_row": scan.get("header_row", ""),
                "rows_total": scan.get("rows_total", 0),
                "data_rows": scan.get("data_rows", 0),
                "columns": scan.get("max_cols", 0),
                "inspection_status": status,
                "notes": notes,
            })
    for err in workbook_errors:
        cp_match = re.search(r"Cycle_(\d+)", err["filename"])
        manifest_rows.append({
            "archive_member": err["filename"],
            "source_path": "",
            "filename": err["filename"],
            "extension": ".xlsx",
            "size_bytes": err["size_bytes"],
            "sha256": "",
            "workbook_id": Path(err["filename"]).stem,
            "checkpoint_label": int(cp_match.group(1)) if cp_match else "",
            "worksheet_index": "",
            "worksheet": "<workbook unreadable>",
            "sheet_type": "error",
            "header_row": "",
            "rows_total": "",
            "data_rows": "",
            "columns": "",
            "inspection_status": "ERROR",
            "notes": err["error"],
        })

    # ------------------------------------------------------------------
    # Cleaning log
    # ------------------------------------------------------------------
    cleaning_rows = []
    for wb in workbooks:
        for scan in wb["scans"]:
            if scan["sheet_type"] in ("cycle", "ocv", "rest"):
                cleaning_rows.append({
                    "workbook_id": wb["workbook_id"],
                    "worksheet": scan["sheet_name"],
                    "sheet_type": scan["sheet_type"],
                    "data_rows": scan["data_rows"],
                    "missing_cells": scan["missing_cells"],
                    "nonnumeric_cells": scan["nonnumeric_cells"],
                    "duplicate_timestamps": scan["duplicate_timestamps"],
                    "duplicate_rows": scan["duplicate_rows"],
                    "time_resets_within": scan["time_resets_within"],
                    "cross_sheet_time_reset": str(scan["cross_sheet_time_reset"]).lower(),
                    "dt_min_s": fmt(scan["dt_min"], 3),
                    "dt_median_s": fmt(scan["dt_median"], 3),
                    "dt_max_s": fmt(scan["dt_max"], 3),
                    "irregular_dt_count": scan["irregular_dt_count"],
                    "time_gap_count_gt5s": scan["gap_count_gt5"],
                    "time_gap_count_gt60s": scan["gap_count_gt60"],
                    "v_min": fmt(scan["v_min"], 6),
                    "v_max": fmt(scan["v_max"], 6),
                    "v_mean": fmt(scan["v_sum"] / scan["v_count"] if scan["v_count"] else None, 6),
                    "out_of_protocol_voltage_count": scan["out_of_protocol_v"],
                    "severe_out_of_protocol_voltage_count": scan["severe_out_of_protocol_v"],
                    "i_min": fmt(scan["i_min"], 6),
                    "i_max": fmt(scan["i_max"], 6),
                    "current_excursion_flag": str(bool(scan["current_excursion_flag"])).lower(),
                    "i_pos_count": scan["i_pos"],
                    "i_neg_count": scan["i_neg"],
                    "i_zero_count": scan["i_zero"],
                    "phase_sequence": scan.get("phase_sequence", ""),
                    "charge_duration_s": fmt(scan["phase_durations"]["charge"], 1),
                    "discharge_duration_s": fmt(scan["phase_durations"]["discharge"], 1),
                    "charge_capacity_ah": fmt(scan["phase_capacities"]["charge"], 6),
                    "discharge_capacity_ah": fmt(scan["phase_capacities"]["discharge"], 6),
                    "interpolated_rows": 0,
                    "dropped_rows": 0,
                    "transformations": "none (raw preserved); derived metrics computed in memory",
                    "quality_flags": ";".join(scan["quality_flags"]),
                    "notes": "",
                })
            else:
                cleaning_rows.append({
                    "workbook_id": wb["workbook_id"],
                    "worksheet": scan["sheet_name"],
                    "sheet_type": scan["sheet_type"],
                    "data_rows": scan.get("data_rows", 0),
                    "interpolated_rows": 0,
                    "dropped_rows": 0,
                    "transformations": "none (raw preserved)",
                    "quality_flags": ";".join(scan.get("quality_flags", [])),
                    "current_excursion_flag": "",
                    "notes": scan.get("aux_note", ""),
                })

    # ------------------------------------------------------------------
    # Column mapping
    # ------------------------------------------------------------------
    first_data_row = None
    for wb in workbooks:
        for scan in wb["cycles"]:
            if scan["data_rows"] > 0:
                first_data_row = scan
                break
        if first_data_row:
            break
    example_v = fmt(first_data_row["phase_stats"]["charge"]["vmax"], 6) if first_data_row else ""
    example_i = fmt(first_data_row["i_max"], 6) if first_data_row else ""

    column_mapping_rows = [
        {"canonical_field": "dataset_id", "source_header_or_metadata": "assigned by audit",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "all sheets",
         "source_value_example": DATASET_ID, "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "ASSIGNED",
         "interpretation_status": "ASSIGNED", "transformation": "constant",
         "evidence": "Condition folder B1 / discharge 0.5C / charge 0.5C",
         "notes": "Stable dataset identifier assigned for integration."},
        {"canonical_field": "source_file", "source_header_or_metadata": "workbook filename and File List row 1",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "File List",
         "source_value_example": "Cycle_0050.xlsx / C:\\\\...\\\\Charge Discharge 0.5C EXP 2 (50th Cycle).mdat",
         "data_type": "string", "source_unit": "n/a", "canonical_unit": "n/a",
         "unit_status": "VERIFIED", "interpretation_status": "VERIFIED",
         "transformation": "copy filename; source path preserved",
         "evidence": "File List row 1", "notes": "Original .mdat path is preserved verbatim."},
        {"canonical_field": "condition_id", "source_header_or_metadata": "folder / specification",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "n/a",
         "source_value_example": CONDITION_ID, "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "VERIFIED",
         "interpretation_status": "VERIFIED", "transformation": "constant",
         "evidence": "Dataset folder and supplied audit scope", "notes": "Only B1 is audited."},
        {"canonical_field": "battery_id", "source_header_or_metadata": "none (folder label BATTERY 1; channel Un1Ch7)",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "File List / metadata",
         "source_value_example": "UNKNOWN", "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "UNSUPPORTED",
         "interpretation_status": "UNDERDETERMINED",
         "transformation": "assigned UNKNOWN; channel stored separately",
         "evidence": "No serial number or physical-cell identifier in workbooks",
         "notes": "Do not treat channel Un1Ch7 or folder label as a verified cell ID."},
        {"canonical_field": "cycle_checkpoint", "source_header_or_metadata": "workbook filename suffix and source .mdat name",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "n/a",
         "source_value_example": "50", "data_type": "integer",
         "source_unit": "cycles", "canonical_unit": "cycles", "unit_status": "VERIFIED",
         "interpretation_status": "VERIFIED", "transformation": "parse Cycle_NNNN",
         "evidence": "Filenames 0050..1500 and .mdat names", "notes": "Checkpoint label, not a verified global cycle index."},
        {"canonical_field": "cycle_id", "source_header_or_metadata": "worksheet ordinal and File List Repeat",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle sheets",
         "source_value_example": "1", "data_type": "integer",
         "source_unit": "cycles", "canonical_unit": "cycles", "unit_status": "VERIFIED",
         "interpretation_status": "VERIFIED", "transformation": "1-based within-workbook ordinal",
         "evidence": "Sheet names Cycle01.. and File List Repeat", "notes": "Resets in every workbook."},
        {"canonical_field": "global_cycle_est", "source_header_or_metadata": "derived from checkpoint and workbook cycle count",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle sheets",
         "source_value_example": "1", "data_type": "integer",
         "source_unit": "cycles", "canonical_unit": "cycles", "unit_status": "DERIVED",
         "interpretation_status": "VERIFIED_OR_UNDERDETERMINED",
         "transformation": "checkpoint - n_cycles + within-file index",
         "evidence": "Checkpoint deltas and sheet counts",
         "notes": "Underdetermined for Cycle_0200 (30 sheets) and Cycle_1300 (80 sheets)."},
        {"canonical_field": "time_sec", "source_header_or_metadata": "T(Seconds)",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle/OCV/rest",
         "source_value_example": "31", "data_type": "float",
         "source_unit": "seconds", "canonical_unit": "s", "unit_status": "VERIFIED",
         "interpretation_status": "VERIFIED", "transformation": "none",
         "evidence": "Header T(Seconds); 1 s median sampling", "notes": "Cumulative within a workbook; resets between experiments and once in Cycle_0050."},
        {"canonical_field": "voltage_v", "source_header_or_metadata": "E(V)",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle/OCV/rest",
         "source_value_example": example_v, "data_type": "float",
         "source_unit": "V", "canonical_unit": "V", "unit_status": "VERIFIED",
         "interpretation_status": "VERIFIED", "transformation": "none",
         "evidence": "Header E(V); values 2.49..3.652 V match 2.50-3.65 V protocol",
         "notes": "No temperature channel exists."},
        {"canonical_field": "current_a", "source_header_or_metadata": "I(A/cm2)",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle/OCV/rest",
         "source_value_example": example_i, "data_type": "float",
         "source_unit": "A (interpreted; header says A/cm2)", "canonical_unit": "A",
         "unit_status": CURRENT_UNIT_STATUS, "interpretation_status": "UNDERDETERMINED (total amperes plausible)",
         "transformation": "none (values preserved)",
         "evidence": "Surface Area=0; protocol Charge/Discharge CC=0.625 A; measured +/-0.624..0.626; 0.625 A=0.5C of 1.25 Ah",
         "notes": CURRENT_UNIT_NOTE},
        {"canonical_field": "current_density_a_cm2", "source_header_or_metadata": "I(A/cm2) label only",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "n/a",
         "source_value_example": "NA", "data_type": "float",
         "source_unit": "A/cm2", "canonical_unit": "A/cm2", "unit_status": "UNSUPPORTED",
         "interpretation_status": "UNDERDETERMINED", "transformation": "not computed",
         "evidence": "Surface Area=0; no electrode area documented",
         "notes": "No defensible conversion to current density is possible."},
        {"canonical_field": "temperature_c", "source_header_or_metadata": "unavailable",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "all sheets",
         "source_value_example": "NA", "data_type": "float",
         "source_unit": "degC", "canonical_unit": "degC", "unit_status": "UNSUPPORTED",
         "interpretation_status": "UNSUPPORTED", "transformation": "none",
         "evidence": "No temperature column in any workbook",
         "notes": "Dataset description states 25 degC test temperature; this is not a measured channel."},
        {"canonical_field": "capacity_ah", "source_header_or_metadata": "derived from T(Seconds) and I(A/cm2); manual summaries exist only in Cycle_0100",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle sheets",
         "source_value_example": "1.213", "data_type": "float",
         "source_unit": "Ah", "canonical_unit": "Ah", "unit_status": "DERIVED",
         "interpretation_status": "DERIVED_WITH_CONDITIONS",
         "transformation": "trapezoidal integration of |I| over complete discharge",
         "evidence": "Protocol 0.625 A and ~1.9 h discharge gives ~1.2 Ah",
         "notes": "Not measured directly in raw sheets; manual summaries in Cycle_0100 were not used."},
        {"canonical_field": "soh_pct", "source_header_or_metadata": "derived",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle sheets",
         "source_value_example": "97.68", "data_type": "float",
         "source_unit": "%", "canonical_unit": "%", "unit_status": "DERIVED",
         "interpretation_status": "DERIVED_WITH_CONDITIONS",
         "transformation": "Q_discharge / 1.25 Ah * 100",
         "evidence": "Nominal capacity 1.25 Ah from dataset metadata",
         "notes": "Nominal-capacity SOH; separate from BOL-referenced retention."},
        {"canonical_field": "charge_discharge_phase", "source_header_or_metadata": "derived from current sign",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "cycle/OCV/rest",
         "source_value_example": "charge", "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "DERIVED",
         "interpretation_status": "DERIVED", "transformation": "I>0.01 charge; I<-0.01 discharge; else rest",
         "evidence": "Positive current increases voltage; negative current decreases voltage",
         "notes": "Threshold 0.01 A used for phase boundaries."},
        {"canonical_field": "quality_flag", "source_header_or_metadata": "derived",
         "source_workbook_scope": "each workbook", "source_sheet_scope": "all sheets",
         "source_value_example": "ok", "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "DERIVED",
         "interpretation_status": "DERIVED", "transformation": "rule-based flags",
         "evidence": "See LFP_cleaning_log.csv", "notes": "Flags are additive and semicolon-separated."},
        {"canonical_field": "is_interpolated", "source_header_or_metadata": "assigned",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "all sheets",
         "source_value_example": "false", "data_type": "boolean",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "ASSIGNED",
         "interpretation_status": "ASSIGNED", "transformation": "constant false",
         "evidence": "No resampling or interpolation performed", "notes": "Raw 1 s samples preserved."},
        {"canonical_field": "value_origin", "source_header_or_metadata": "assigned",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "all sheets",
         "source_value_example": "measured", "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "ASSIGNED",
         "interpretation_status": "ASSIGNED", "transformation": "measured for T/E/I; calculated for capacity/SOH",
         "evidence": "Raw instrument export vs derived metrics", "notes": "Distinguishes observations from calculations."},
        {"canonical_field": "formula_id", "source_header_or_metadata": "assigned",
         "source_workbook_scope": "all workbooks", "source_sheet_scope": "derived fields",
         "source_value_example": "F1", "data_type": "string",
         "source_unit": "n/a", "canonical_unit": "n/a", "unit_status": "ASSIGNED",
         "interpretation_status": "ASSIGNED", "transformation": "F1 capacity, F2 SOH, F3 retention, F4 CE (unsupported for modelling), F6 current-excursion flag",
         "evidence": "See LFP_formula_register.csv", "notes": "Formula IDs are traceable."},
    ]

    # ------------------------------------------------------------------
    # Formula register
    # ------------------------------------------------------------------
    sample_cycle = None
    for row in cycle_rows:
        if row["workbook_id"] == "Cycle_0050" and str(row["cycle_id_within_file"]) == "2":
            sample_cycle = row
            break
    if sample_cycle is None:
        sample_cycle = next((r for r in cycle_rows if r["capacity_discharge_ah"] != ""), cycle_rows[0])

    q_sample = sample_cycle["capacity_discharge_ah"]
    q_sample_float = float(q_sample) if q_sample != "" else None
    last_valid = None
    for row in cycle_rows:
        if row["capacity_discharge_ah"] != "":
            last_valid = row
    q_last = last_valid["capacity_discharge_ah"] if last_valid else ""
    q_last_float = float(q_last) if q_last != "" else None

    formula_rows = [
        {"formula_id": "F1", "metric": "Discharge capacity (Ah)",
         "formula": "Q_dis = sum over discharge intervals of 0.5*(|I_k|+|I_k+1|)*(t_k+1 - t_k)/3600",
         "scientific_basis": "Coulometric integration with the trapezoidal rule",
         "source_citation": "Standard electrochemical coulometry; instrument time/current telemetry",
         "input_fields": "time_sec; current_a; charge_discharge_phase",
         "units": "A and s -> Ah",
         "assumptions": "Current values are INTERPRETED as total amperes (plausible but not instrument-confirmed); discharge defined as I < -0.01 A; both interval endpoints in discharge; 0 < dt <= 60 s",
         "validation_status": "VALIDATED_WITH_CONDITIONS: 0.625 A * ~1.9 h ~= 1.2 Ah; current-unit identity UNDERDETERMINED",
         "numerical_example": (
             f"{sample_cycle['workbook_id']} / {sample_cycle['worksheet'] if 'worksheet' in sample_cycle else 'Cycle02'}: "
             f"Q_dis = {q_sample} Ah"
         ),
         "example_source": f"{sample_cycle['source_file']} / cycle {sample_cycle['cycle_id_within_file']}"},
        {"formula_id": "F2", "metric": "Nominal-capacity SOH (%)",
         "formula": "SOH_nominal = Q_dis / 1.25 Ah * 100",
         "scientific_basis": "State-of-health definition relative to nominal capacity",
         "source_citation": "Dataset metadata: nominal capacity 1.25 Ah",
         "input_fields": "capacity_ah",
         "units": "Ah / Ah -> %",
         "assumptions": "Nominal 1.25 Ah is not assumed to equal measured BOL capacity",
         "validation_status": "VALIDATED_WITH_CONDITIONS",
         "numerical_example": (
             f"cycle 1: Q_dis = {fmt(q_bol, 6)} Ah -> SOH_nominal = "
             f"{fmt((q_bol / NOMINAL_CAPACITY_AH * 100) if q_bol else None, 3)} %"
         ),
         "example_source": "Cycle_0050.xlsx / first valid discharge"},
        {"formula_id": "F3", "metric": "Capacity retention relative to proxy BOL (%)",
         "formula": "Retention_BOL = Q_dis / Q_BOL * 100",
         "scientific_basis": "Capacity retention relative to the first observed valid discharge (proxy reference)",
         "source_citation": "This audit: first observed valid discharge capacity; no dedicated BOL test documented",
         "input_fields": "capacity_ah; reference_bol_capacity_ah",
         "units": "Ah / Ah -> %",
         "assumptions": "Q_BOL is the first OBSERVED valid discharge, a proxy for beginning of life; not clipped",
         "validation_status": "VALIDATED_WITH_CONDITIONS",
         "numerical_example": (
             f"last valid cycle: Q_dis = {q_last} Ah, Q_BOL = {fmt(q_bol, 6)} Ah -> "
             f"Retention = {fmt((q_last_float / q_bol * 100) if (q_last_float and q_bol) else None, 3)} %"
         ),
         "example_source": f"{last_valid['source_file'] if last_valid else ''} / cycle {last_valid['global_cycle_est'] if last_valid else ''}"},
        {"formula_id": "F4", "metric": "Coulombic efficiency (%, UNSUPPORTED FOR MODELLING)",
         "formula": "CE = Q_dis / Q_chg * 100",
         "scientific_basis": "Ratio of discharge to charge capacity for a full cycle",
         "source_citation": "Standard coulombic-efficiency definition",
         "input_fields": "capacity_charge_ah; capacity_discharge_ah",
         "units": "Ah / Ah -> %",
         "assumptions": "Reported only when both charge and discharge segments are complete; charge-capacity segmentation across CC/CV transitions is not independently validated. Diagnostic only, not for modelling.",
         "validation_status": "UNSUPPORTED_FOR_MODELLING",
         "numerical_example": (
             f"{sample_cycle['workbook_id']}: CE = {sample_cycle['coulombic_efficiency_pct']} %"
         ),
         "example_source": f"{sample_cycle['source_file']} / cycle {sample_cycle['cycle_id_within_file']}"},
        {"formula_id": "F5", "metric": "C-rate verification (not a reported metric)",
         "formula": "C_rate = I_protocol / Q_nominal = 0.625 A / 1.25 Ah = 0.5C",
         "scientific_basis": "Unit and protocol consistency check",
         "source_citation": "Protocol metadata and dataset description",
         "input_fields": "protocol charge/discharge current; nominal capacity",
         "units": "A / Ah -> 1/h",
         "assumptions": "Used only as a consistency check for interpreting the current values as total amperes; unit identity not confirmed",
         "validation_status": "VERIFIED_WITH_CONDITIONS",
         "numerical_example": "0.625 / 1.25 = 0.500 C",
         "example_source": "File List protocol and dataset metadata"},
        {"formula_id": "F6", "metric": "Current-excursion quality flag",
         "formula": "flag = true if max(|I|) > 1.5 * 0.625 A = 0.9375 A",
         "scientific_basis": "Screening heuristic at 150% of the protocol CC setpoint; not an instrument limit",
         "source_citation": "Protocol metadata (Charge/Discharge CC = 0.625 A); audit-defined factor",
         "input_fields": "current_a (raw, preserved)",
         "units": "A",
         "assumptions": "Cycle/worksheet flag derived from recorded |I| extrema; raw currents preserved; no clipping, deletion, or interpolation",
         "validation_status": "SCREENING_HEURISTIC_WITH_CONDITIONS",
         "numerical_example": "Cycle_0300 / Cycle14: min I = -4.507276 A (7.21x protocol) -> current_excursion; 0 other worksheets flagged",
         "example_source": "Cycle_0300.xlsx / Run01_Un1Ch7_Step2_Cycle14"},
    ]

    # ------------------------------------------------------------------
    # Staging files
    # ------------------------------------------------------------------
    staging_cycle_rows = []
    for row in cycle_rows:
        staging_cycle_rows.append({
            "dataset_id": row["dataset_id"],
            "source_file": row["source_file"],
            "battery_id": row["battery_id"],
            "condition_id": row["condition_id"],
            "cycle_checkpoint": row["cycle_checkpoint"],
            "cycle_id": row["cycle_id_within_file"],
            "global_cycle_est": row["global_cycle_est"],
            "capacity_ah": row["capacity_discharge_ah"],
            "soh_pct": row["soh_nominal_pct"],
            "capacity_retention_pct": row["retention_bol_pct"],
            "quality_flag": row["quality_flags"],
            "current_excursion_flag": row["current_excursion_flag"],
            "value_origin": "calculated" if row["capacity_discharge_ah"] != "" else "unavailable",
            "formula_id": "F1;F2;F3" if row["capacity_discharge_ah"] != "" else "",
        })

    # ------------------------------------------------------------------
    # Write CSVs
    # ------------------------------------------------------------------
    write_csv(output_dir / "LFP_file_manifest.csv",
              ["archive_member", "source_path", "filename", "extension", "size_bytes",
               "sha256", "workbook_id", "checkpoint_label", "worksheet_index",
               "worksheet", "sheet_type", "header_row", "rows_total", "data_rows",
               "columns", "inspection_status", "notes"], manifest_rows)
    write_csv(output_dir / "LFP_column_mapping.csv",
              ["canonical_field", "source_header_or_metadata", "source_workbook_scope",
               "source_sheet_scope", "source_value_example", "data_type",
               "source_unit", "canonical_unit", "unit_status", "interpretation_status",
               "transformation", "evidence", "notes"], column_mapping_rows)
    write_csv(output_dir / "LFP_cleaning_log.csv",
              ["workbook_id", "worksheet", "sheet_type", "data_rows", "missing_cells",
               "nonnumeric_cells", "duplicate_timestamps", "duplicate_rows",
               "time_resets_within", "cross_sheet_time_reset", "dt_min_s",
               "dt_median_s", "dt_max_s", "irregular_dt_count", "time_gap_count_gt5s",
               "time_gap_count_gt60s", "v_min", "v_max", "v_mean",
               "out_of_protocol_voltage_count", "severe_out_of_protocol_voltage_count",
               "i_min", "i_max", "current_excursion_flag", "i_pos_count", "i_neg_count", "i_zero_count",
               "phase_sequence", "charge_duration_s", "discharge_duration_s",
               "charge_capacity_ah", "discharge_capacity_ah", "interpolated_rows",
               "dropped_rows", "transformations", "quality_flags", "notes"], cleaning_rows)
    write_csv(output_dir / "LFP_capacity_soh_feasibility.csv",
              ["workbook_id", "checkpoint_label", "source_file", "worksheet",
               "cycle_id_within_file", "global_cycle_est", "cycle_offset_confidence",
               "total_current_status", "discharge_segment_complete",
               "discharge_capacity_ah", "reference_bol_capacity_ah", "capacity_status",
               "soh_nominal_pct", "soh_status", "retention_bol_pct", "retention_status",
               "feasibility_overall", "blockers"], feasibility_rows)
    write_csv(output_dir / "LFP_formula_register.csv",
              ["formula_id", "metric", "formula", "scientific_basis", "source_citation",
               "input_fields", "units", "assumptions", "validation_status",
               "numerical_example", "example_source"], formula_rows)
    write_csv(output_dir / "LFP_cycle_summary.csv",
              ["dataset_id", "source_file", "workbook_id", "condition_id", "battery_id",
               "channel_id", "cycle_checkpoint", "cycle_id_within_file",
               "global_cycle_est", "cycle_offset_confidence", "date_iso", "time_iso",
               "rows", "charge_duration_s", "discharge_duration_s", "rest_duration_s",
               "v_min", "v_max", "v_mean", "i_min", "i_max", "current_excursion_flag", "i_mean",
               "i_positive_count", "i_negative_count", "i_zero_count",
               "capacity_charge_ah", "capacity_discharge_ah", "raw_charge_integral_ah",
               "raw_discharge_integral_ah", "coulombic_efficiency_pct",
               "bol_reference_ah", "soh_nominal_pct", "retention_bol_pct",
               "phase_sequence", "cycle_valid", "quality_flags", "capacity_status",
               "notes"], cycle_rows)
    write_csv(output_dir / "LFP_staging_cycle_level.csv",
              ["dataset_id", "source_file", "battery_id", "condition_id",
               "cycle_checkpoint", "cycle_id", "global_cycle_est", "capacity_ah",
               "soh_pct", "capacity_retention_pct", "quality_flag",
               "current_excursion_flag", "value_origin", "formula_id"], staging_cycle_rows)
    write_csv(output_dir / "LFP_staging_sample_raw_rows.csv",
              ["dataset_id", "source_file", "worksheet", "cycle_checkpoint",
               "global_cycle_est", "time_sec", "voltage_v", "current_a",
               "charge_discharge_phase", "quality_flag", "is_interpolated",
               "value_origin"], sample_rows)

    # ------------------------------------------------------------------
    # Summary statistics for report / validation
    # ------------------------------------------------------------------
    all_scans = [s for wb in workbooks for s in wb["scans"]]
    cycle_scans = [s for wb in workbooks for s in wb["cycles"]]
    sheet_type_counts = Counter(s["sheet_type"] for s in all_scans)
    total_cycle_data_rows = sum(s["data_rows"] for s in cycle_scans)
    total_xlsx_bytes = sum(wb["size_bytes"] for wb in workbooks)
    total_sheets = len(all_scans)
    total_worksheets = total_sheets
    flag_counter = Counter()
    for s in all_scans:
        for f in s.get("quality_flags", []):
            flag_counter[f] += 1
    aux_sheets = [s for s in all_scans if s["sheet_type"] == "auxiliary"]
    empty_aux = [s for s in aux_sheets if "empty_sheet" in s.get("quality_flags", [])]
    nonstandard_aux = [s for s in aux_sheets if "auxiliary_nonstandard" in s.get("quality_flags", [])]

    valid_cycles = [r for r in cycle_rows if r["capacity_discharge_ah"] != ""]
    partial_cycles = [r for r in cycle_rows if r["cycle_valid"] == "false"]
    underdetermined = [r for r in cycle_rows if r["cycle_offset_confidence"] != "VERIFIED"]
    ret_gt100 = sum(
        1 for r in valid_cycles
        if r["retention_bol_pct"] != "" and float(r["retention_bol_pct"]) > 100.0
    )
    soh_gt100 = sum(
        1 for r in valid_cycles
        if r["soh_nominal_pct"] != "" and float(r["soh_nominal_pct"]) > 100.0
    )
    total_missing_cycles = sum(
        (wb.get("missing_before") or 0) for wb in workbooks
    )

    verified_capacity_pairs = [
        (r["global_cycle_est"], float(r["capacity_discharge_ah"]))
        for r in valid_cycles
        if r["cycle_offset_confidence"] == "VERIFIED" and isinstance(r["global_cycle_est"], int)
    ]
    slope, intercept, r2 = linear_regression(
        [x for x, _ in verified_capacity_pairs],
        [y for _, y in verified_capacity_pairs],
    )

    # Per-checkpoint aggregation
    by_checkpoint = defaultdict(list)
    for r in valid_cycles:
        by_checkpoint[r["workbook_id"]].append(r)
    checkpoint_stats = []
    for wb in workbooks:
        rows = by_checkpoint.get(wb["workbook_id"], [])
        qs = [float(r["capacity_discharge_ah"]) for r in rows]
        sohs = [float(r["soh_nominal_pct"]) for r in rows if r["soh_nominal_pct"] != ""]
        rets = [float(r["retention_bol_pct"]) for r in rows if r["retention_bol_pct"] != ""]
        ces = [float(r["coulombic_efficiency_pct"]) for r in rows if r["coulombic_efficiency_pct"] != ""]
        checkpoint_stats.append({
            "workbook_id": wb["workbook_id"],
            "checkpoint": wb["checkpoint_label"],
            "n_cycles": wb["n_cycles"],
            "n_valid_discharge": len(qs),
            "n_invalid": wb["n_cycles"] - len(qs),
            "missing_before": wb.get("missing_before", 0),
            "offset_confidence": wb.get("offset_confidence", ""),
            "q_median": statistics.median(qs) if qs else None,
            "q_min": min(qs) if qs else None,
            "q_max": max(qs) if qs else None,
            "q_first": qs[0] if qs else None,
            "q_last": qs[-1] if qs else None,
            "soh_median": statistics.median(sohs) if sohs else None,
            "ret_median": statistics.median(rets) if rets else None,
            "ce_median": statistics.median(ces) if ces else None,
            "first_date": wb["first_date"],
            "last_date": wb["last_date"],
            "size_mb": wb["size_bytes"] / 1e6,
            "sha_prefix": wb["sha256"][:12],
            "source_path": wb["source_path"],
            "experiment_no": wb["experiment_no"],
            "protocol": wb["protocol"],
            "max_repeat": wb["max_file_list_repeat"],
        })

    last_valid_row = valid_cycles[-1] if valid_cycles else None
    q_last_float = float(last_valid_row["capacity_discharge_ah"]) if last_valid_row else None
    soh_bol = q_bol / NOMINAL_CAPACITY_AH * 100.0 if q_bol else None
    soh_last = q_last_float / NOMINAL_CAPACITY_AH * 100.0 if q_last_float else None
    ret_last = q_last_float / q_bol * 100.0 if (q_last_float and q_bol) else None
    loss_ah = (q_bol - q_last_float) if (q_bol and q_last_float) else None
    loss_pct = (loss_ah / q_bol * 100.0) if (loss_ah is not None and q_bol) else None
    fade_per_100 = -slope * 100.0 if slope is not None else None

    # ------------------------------------------------------------------
    # Report
    # ------------------------------------------------------------------
    wb_rows = []
    for st in checkpoint_stats:
        wb_rows.append([
            st["checkpoint"],
            st["n_cycles"],
            st["n_valid_discharge"],
            st["n_invalid"],
            st["missing_before"],
            st["offset_confidence"],
            st["first_date"],
            st["last_date"],
            f"{st['q_median']:.4f}" if st["q_median"] is not None else "NA",
            f"{st['soh_median']:.2f}" if st["soh_median"] is not None else "NA",
            f"{st['ret_median']:.2f}" if st["ret_median"] is not None else "NA",
            f"{st['ce_median']:.2f}" if st["ce_median"] is not None else "NA",
            f"{st['size_mb']:.1f}",
        ])

    flag_rows = [[flag, count] for flag, count in flag_counter.most_common()]

    aux_rows = []
    for s in nonstandard_aux[:40]:
        wb = next(w for w in workbooks if any(x is s for x in w["scans"]))
        aux_rows.append([wb["workbook_id"], s["sheet_name"], s.get("rows_total", 0),
                         s.get("max_cols", 0), s.get("aux_note", "")])
    if len(nonstandard_aux) > 40:
        aux_rows.append(["...", f"{len(nonstandard_aux) - 40} more", "", "", ""])

    reset_details = []
    for wb in workbooks:
        for s in wb["cycles"]:
            if s["time_resets_within"] > 0 or s["cross_sheet_time_reset"]:
                reset_details.append([
                    wb["workbook_id"], s["sheet_name"],
                    "within-sheet" if s["time_resets_within"] else "",
                    "cross-sheet" if s["cross_sheet_time_reset"] else "",
                    f"{s['first_t']:.0f}" if s["first_t"] is not None else "",
                    f"{s['last_t']:.0f}" if s["last_t"] is not None else "",
                ])

    within_reset_count = sum(1 for s in cycle_scans if s["time_resets_within"] > 0)
    cross_reset_count = sum(1 for s in cycle_scans if s["cross_sheet_time_reset"])
    partial_rows = []
    for r in partial_cycles[:25]:
        partial_rows.append([
            r["workbook_id"], r["cycle_id_within_file"],
            r["global_cycle_est"], r["quality_flags"],
        ])
    if len(partial_cycles) > 25:
        partial_rows.append(["...", f"{len(partial_cycles) - 25} more", "", ""])

    feasibility_status_counts = Counter(r["feasibility_overall"] for r in feasibility_rows)
    capacity_status_counts = Counter(r["capacity_status"] for r in feasibility_rows)
    soh_status_counts = Counter(r["soh_status"] for r in feasibility_rows)

    unit_evidence = [
        ["Source header", "I(A/cm2)", "Raw workbook column"],
        ["Workbook metadata", "Surface Area = 0", "Current density cannot be reconstructed from a zero area"],
        ["Protocol metadata", "Charge CC = 0.625 A; Discharge CC = 0.625 A", "File List Exp Title"],
        ["Measured values", f"{fmt(first_data_row['i_min'], 4) if first_data_row else ''} .. {fmt(first_data_row['i_max'], 4) if first_data_row else ''} A", "First cycle sheet"],
        ["Nominal capacity", "1.25 Ah", "Dataset metadata"],
        ["C-rate arithmetic", "0.625 A / 1.25 Ah = 0.5C", "Matches B1 condition"],
    ]

    worked = sample_cycle
    worked_discharge_ps = None
    if worked:
        for wb in workbooks:
            if wb["workbook_id"] == worked["workbook_id"]:
                for s in wb["cycles"]:
                    if s["cycle_id_within_file"] == worked["cycle_id_within_file"]:
                        worked_discharge_ps = s["phase_stats"]["discharge"]
                        break
    worked_text = ""
    if worked and worked_discharge_ps:
        dur = worked_discharge_ps["duration_s"] or 0
        mean_i = worked_discharge_ps["mean_abs_i"] or 0
        worked_text = (
            f"For `{worked['source_file']}` / `{worked['workbook_id']}` cycle "
            f"{worked['cycle_id_within_file']}: the discharge phase spans "
            f"{dur:.0f} s with mean |I| = {mean_i:.6f} A and "
            f"{worked_discharge_ps['n']} samples. The trapezoidal sum gives "
            f"**Q_dis = {worked['capacity_discharge_ah']} Ah**.  A simple "
            f"cross-check is mean |I| x duration / 3600 = "
            f"{mean_i * dur / 3600.0:.6f} Ah, which agrees within the "
            f"trapezoidal discretisation."
        )

    median_dt_all = statistics.median(
        [s["dt_median"] for s in cycle_scans if s["dt_median"] is not None]
    ) if any(s["dt_median"] is not None for s in cycle_scans) else None
    max_dt_all = max((s["dt_max"] for s in cycle_scans if s["dt_max"] is not None), default=None)
    short_exports = [wb for wb in workbooks if wb.get("missing_before")]
    short_export_text = "; ".join(
        f"`{wb['filename']}` contains {wb['n_cycles']} instead of "
        f"{wb.get('expected_since_prev') or 'the expected number of'} sheets"
        for wb in short_exports
    ) or "no checkpoint arithmetic gap was detected"

    report = []
    report.append("# B1 LFP 18650 Dataset Audit Report")
    report.append("")
    report.append(f"**Dataset:** {DATASET_ID}  ")
    report.append(f"**Condition:** {CONDITION_ID}  ")
    report.append(f"**Audit date:** 2026-10-27  ")
    report.append(f"**Source DOI:** [{DOI}](https://doi.org/{DOI})  ")
    report.append(f"**Report generated by:** `LFP_preprocessing.py` (stdlib-only, reproducible)")
    report.append("")
    report.append("## Status labels")
    report.append("")
    report.append("`VERIFIED` · `VERIFIED_WITH_CONDITIONS` · `UNDERDETERMINED` · `UNSUPPORTED` · `NOT_INSPECTED`")
    report.append("")
    report.append("## 1. Executive summary")
    report.append("")
    report.append(
        f"- Inspected **{len(workbooks)} workbooks**, **{total_sheets} worksheets**, "
        f"and **{len(cycle_scans)} raw charge/discharge cycle sheets** "
        f"({total_cycle_data_rows:,} measurement rows)."
    )
    report.append(
        f"- The workbooks are MultiStat/EC-Lab exports for one LFP 18650 cell "
        f"(nominal 1.25 Ah), condition B1 (0.5C charge / 0.5C discharge), "
        f"2.50–3.65 V, {PROVENANCE['test_temperature_c']}."
    )
    report.append(
        f"- Checkpoint labels run from {min((wb['checkpoint_label'] for wb in workbooks), default='?')} "
        f"to {max((wb['checkpoint_label'] for wb in workbooks), default='?')} cycles. "
        f"**{total_missing_cycles} cycle(s) are absent** from the supplied exports: "
        f"{short_export_text}. No rows were fabricated."
    )
    report.append(
        f"- The source header is `I(A/cm2)`. Values are **interpreted as total "
        f"current in amperes** (`UNDERDETERMINED`; plausible but not "
        f"instrument-confirmed): 0.625 A matches the protocol and 0.5C of "
        f"1.25 Ah. `Surface Area = 0` means a current density cannot be "
        f"reconstructed; current density is `UNSUPPORTED`. The source label is "
        f"preserved unchanged."
    )
    report.append(
        f"- Discharge capacity is computable for **{len(valid_cycles)} of {len(cycle_rows)} "
        f"cycles** using trapezoidal integration. Proxy reference (first observed "
        f"valid discharge) = **{fmt(q_bol, 4)} Ah**; last valid checkpoint = "
        f"**{fmt(q_last_float, 4)} Ah** ({fmt(loss_pct, 2)}% loss; "
        f"**{fmt(soh_last, 2)}%** nominal SOH; **{fmt(ret_last, 2)}%** "
        f"proxy-reference retention)."
    )
    report.append(
        f"- Sampling is **{fmt(median_dt_all, 3)} s** (median). No temperature "
        f"channel, no cell serial number, and no independent replicate cell are "
        f"present. Physical-cell identity and replication remain `UNDERDETERMINED`."
    )
    report.append(
        f"- The dataset-level provenance is verified, but the ZIP archive itself "
        f"was outside the workspace sandbox: the archive checksum is "
        f"`NOT_INSPECTED` while the {len(workbooks)} extracted workbooks are fully "
        f"checksummed."
    )
    report.append("")
    report.append("## 2. Inputs, archive, and provenance")
    report.append("")
    report.append(f"- **Dataset title:** {PROVENANCE['title']}")
    report.append(f"- **Authors:** {PROVENANCE['authors']}")
    report.append(f"- **DOI / record:** [{DOI}](https://doi.org/{DOI}) · [Zenodo record]({PROVENANCE['zenodo_record']})")
    report.append(f"- **Institutional page:** [University of Birmingham]({PROVENANCE['institutional_page']})")
    report.append(f"- **Chemistry / format:** {PROVENANCE['chemistry']}; {PROVENANCE['file_format']}")
    report.append(f"- **Nominal capacity:** {PROVENANCE['nominal_capacity_ah']} Ah")
    report.append(f"- **Voltage window:** {PROVENANCE['voltage_window_v']} V")
    report.append(f"- **Test temperature (dataset-level):** {PROVENANCE['test_temperature_c']}")
    report.append(f"- **Checkpoint cadence:** {PROVENANCE['checkpoint_cadence']}")
    report.append(f"- **Instrument:** {PROVENANCE['instrument']}")
    report.append(f"- **DOI verification:** {PROVENANCE['verification_status']}")
    report.append(f"- **Instrument documentation:** {PROVENANCE['instrument_doc_status']}")
    report.append("")
    report.append(f"**Archive integrity note.** The supplied workspace contains {len(workbooks)} "
                  "extracted `.xlsx` workbooks but not the original "
                  "`B1_Discharge0.5C_Charge0.5C(1).zip`. The sandbox blocked access "
                  "to the parent directory, so the ZIP checksum and extraction log "
                  "are `NOT_INSPECTED`. Every workbook has an individual SHA-256 "
                  "in `LFP_file_manifest.csv`; source files were not modified.")
    report.append("")
    report.append("## 3. Inventory and checkpoint coverage")
    report.append("")
    report.append(
        f"- **Workbooks:** {len(workbooks)}  "
        f"**Worksheets:** {total_sheets}  "
        f"**Cycle sheets:** {len(cycle_scans)}  "
        f"**Measurement rows:** {total_cycle_data_rows:,}  "
        f"**Total XLSX size:** {total_xlsx_bytes / 1e6:.1f} MB"
    )
    report.append("")
    report.append("**Sheet types**")
    report.append("")
    report.append(md_table(
        ["Sheet type", "Count"],
        [[k, v] for k, v in sorted(sheet_type_counts.items())],
    ))
    report.append("")
    report.append(
        f"**Run scope:** {len(workbooks)} of {len(workbooks_paths)} expected workbooks "
        f"processed; {len(workbook_errors)} unreadable/skipped workbook(s). "
        f"Preflight found checkpoints {min(inventory) if inventory else 'NA'}–"
        f"{max(inventory) if inventory else 'NA'} and required all "
        f"{len(EXPECTED_CHECKPOINTS)} expected exports before processing."
    )
    if workbook_errors:
        report.append("")
        report.append(md_table(
            ["Workbook", "Size (MB)", "Error"],
            [[e["filename"], f"{e['size_bytes'] / 1e6:.1f}", e["error"]]
             for e in workbook_errors],
        ))
    report.append("")
    report.append("**Workbook / checkpoint inventory**")
    report.append("")
    report.append(md_table(
        ["Checkpoint", "Cycles", "Valid Q", "Invalid", "Missing before",
         "Offset", "First date", "Last date", "Median Q (Ah)", "Median SOH (%)",
         "Median retention (%)", "Median CE (%)", "Size (MB)"],
        wb_rows,
    ))
    report.append("")
    report.append("**Missing cycles (not fabricated)**")
    report.append("")
    missing_rows = []
    for wb in workbooks:
        if wb.get("missing_before"):
            missing_rows.append([
                wb["workbook_id"], wb["checkpoint_label"], wb["n_cycles"],
                wb.get("expected_since_prev", ""), wb["missing_before"],
                wb.get("offset_start", ""),
                wb.get("offset_confidence", ""),
            ])
    if missing_rows:
        report.append(md_table(
            ["Workbook", "Checkpoint", "Sheets present", "Expected since previous",
             "Missing before", "Assumed global start", "Confidence"],
            missing_rows,
        ))
    else:
        report.append("No missing cycles detected by checkpoint arithmetic.")
    report.append("")
    if short_exports:
        report.append(
            f"Short export(s): {short_export_text}. Their global offsets are "
            f"**tail-aligned assumptions**, not verified indices. All other "
            f"checkpoint deltas match the sheet counts."
        )
    else:
        report.append("All checkpoint deltas match the sheet counts.")
    report.append("")
    report.append("**Non-standard / auxiliary sheets**")
    report.append("")
    if aux_rows:
        report.append(md_table(
            ["Workbook", "Worksheet", "Rows", "Columns", "Interpretation"],
            aux_rows,
        ))
    else:
        report.append("None.")
    report.append("")
    report.append(f"Of {len(aux_sheets)} auxiliary sheets, {len(empty_aux)} are empty "
                  f"or header-only, and {len(nonstandard_aux)} contain manual summaries. "
                  f"None were used as authoritative raw measurements.")
    report.append("")
    report.append("## 4. Measurement schema")
    report.append("")
    report.append("Each cycle sheet contains a MultiStat header (~120 metadata rows) "
                  "followed by a three-column data table:")
    report.append("")
    report.append(md_table(
        ["Source column", "Canonical field", "Unit status", "Notes"],
        [
            ["T(Seconds)", "time_sec", "VERIFIED", "Cumulative within a workbook; resets between experiments and once in Cycle_0050"],
            ["E(V)", "voltage_v", "VERIFIED", "2.49–3.652 V observed; protocol 2.50–3.65 V"],
            ["I(A/cm2)", "current_a", "UNDERDETERMINED (total amperes plausible)", "Interpreted as total amperes under conditions; not proven; see §5"],
            ["—", "temperature_c", "UNSUPPORTED", "No temperature column"],
            ["—", "capacity_ah", "DERIVED", "Computed from F1 only for complete discharge segments"],
            ["—", "soh_pct", "DERIVED", "F2 nominal and F3 BOL retention, kept separate"],
        ],
    ))
    report.append("")
    report.append("**Workbook metadata observed:** `MultiStat_DCData_1.0`, v1.7f; "
                  "`Surface Area: 0`, `Sample Weight: 0`, `Sample Capacity: 0`; "
                  "`Pstat: 1470`; `Charge CC: 0.625 A`, `Charge CV: 3.65 V`, "
                  "`Charge CI: 0.025 A`; `Discharge CC: 0.625 A`, `Discharge XV: 2.5 V`.")
    report.append("")
    report.append("## 5. Current-unit verification")
    report.append("")
    report.append(md_table(["Evidence", "Observation", "Source"], unit_evidence))
    report.append("")
    report.append(
        "**Conclusion (`UNDERDETERMINED`; total amperes plausible).** The numeric "
        "values in the `I(A/cm2)` column are most plausibly total current in "
        "amperes, because the protocol setpoints are 0.625 A and 0.625 A = 0.5C of "
        "1.25 Ah. This is an interpretation, not a documented confirmation: no "
        "instrument manual located states the exported unit, and the header label "
        "conflicts with `Surface Area = 0`. The label origin is not documented. "
        "No physical current density can be formed; `current_density_a_cm2` is "
        "`UNSUPPORTED` and no conversion is applied. Capacity integration is "
        "therefore conditional on the total-ampere interpretation."
    )
    report.append("")
    report.append(CURRENT_UNIT_NOTE)
    report.append("")
    report.append("## 6. Data quality")
    report.append("")
    report.append("**Quality-flag counts across all worksheets**")
    report.append("")
    report.append(md_table(["Flag", "Count"], flag_rows))
    report.append("")
    report.append(
        f"**Current-excursion flag (F6).** Threshold = 1.5 x 0.625 A = "
        f"**{CURRENT_EXCURSION_THRESHOLD_A:.4f} A**, a screening heuristic at 150% "
        f"of the protocol CC setpoint (not an instrument limit). "
        f"**{flag_counter.get('current_excursion', 0)} worksheet(s)** exceed it. "
        f"Cycle_0300/`Run01_Un1Ch7_Step2_Cycle14` records I_min = -4.507276 A "
        f"(7.21x protocol) and is flagged; no other worksheet is flagged, so no "
        f"false positives were observed in this dataset. Raw currents are "
        f"preserved; no rows were clipped or deleted."
    )
    report.append("")
    report.append(f"- Missing cells: **{sum(s['missing_cells'] for s in cycle_scans)}** in cycle sheets.")
    report.append(f"- Nonnumeric cells: **{sum(s['nonnumeric_cells'] for s in cycle_scans)}**.")
    report.append(f"- Duplicate timestamps: **{sum(s['duplicate_timestamps'] for s in cycle_scans)}**.")
    report.append(f"- Duplicate rows: **{sum(s['duplicate_rows'] for s in cycle_scans)}**.")
    report.append(f"- Within-sheet time resets: **{sum(1 for s in cycle_scans if s['time_resets_within'])}** cycle sheets.")
    report.append(f"- Cross-sheet time resets: **{sum(1 for s in cycle_scans if s['cross_sheet_time_reset'])}** cycle sheets.")
    report.append(f"- Out-of-protocol voltage rows: **{sum(s['out_of_protocol_v'] for s in cycle_scans)}**.")
    report.append(f"- Partial/invalid cycles: **{len(partial_cycles)}** "
                  f"(see `LFP_cycle_summary.csv`).")
    report.append("")
    report.append("**Time-base resets and gaps**")
    report.append("")
    if reset_details:
        report.append(md_table(
            ["Workbook", "Worksheet", "Within-sheet", "Cross-sheet", "First T (s)", "Last T (s)"],
            reset_details,
        ))
    else:
        report.append("No time resets were detected.")
    report.append("")
    report.append(
        f"A time reset is expected between workbooks because every experiment "
        f"restarts its clock. It is a **data-quality event** only when it occurs "
        f"inside a workbook. Inside-workbook resets were detected in "
        f"{within_reset_count} cycle sheet(s) and cross-sheet resets in "
        f"{cross_reset_count} cycle sheet(s); see the table above. Per-cycle "
        f"`time_sec` remains valid for integration because each cycle sheet is "
        f"internally monotonic."
    )
    report.append("")
    report.append("**Partial cycles (first 25 shown)**")
    report.append("")
    if partial_rows:
        report.append(md_table(["Workbook", "Cycle", "Global est.", "Flags"], partial_rows))
    else:
        report.append("None.")
    report.append("")
    report.append("## 7. Capacity and state of health")
    report.append("")
    report.append("### 7.1 Definitions kept separate")
    report.append("")
    report.append("| Concept | Definition | Status |")
    report.append("|---|---|---|")
    report.append("| Nominal capacity | 1.25 Ah from dataset metadata | VERIFIED (metadata) |")
    report.append("| Proxy BOL reference | First observed valid discharge capacity (no validated BOL test) | VERIFIED_WITH_CONDITIONS (PROXY) |")
    report.append("| Measured discharge capacity | F1 for each complete discharge | VERIFIED_WITH_CONDITIONS |")
    report.append(f"| Nominal-capacity SOH | Q_dis / 1.25 Ah × 100 | COMPUTED |")
    report.append(f"| BOL-referenced retention | Q_dis / {fmt(q_bol, 4)} Ah × 100 | COMPUTED |")
    report.append("")
    report.append("### 7.2 Formula F1 and a worked example")
    report.append("")
    report.append("`Q_dis = Σ 0.5 × (|I_k| + |I_{k+1}|) × (t_{k+1} − t_k) / 3600`")
    report.append("")
    report.append(worked_text)
    report.append("")
    report.append("### 7.3 Results")
    report.append("")
    report.append(md_table(
        ["Metric", "Value", "Source / definition"],
        [
            ["Proxy reference capacity", f"{fmt(q_bol, 4)} Ah", "First observed valid discharge (proxy; no validated BOL test)"],
            ["Nominal capacity", "1.25 Ah", "Dataset metadata"],
            ["SOH at BOL (nominal)", f"{fmt(soh_bol, 2)} %", "F2"],
            ["Last valid discharge capacity", f"{fmt(q_last_float, 4)} Ah", f"{last_valid_row['workbook_id'] if last_valid_row else 'NA'}"],
            ["SOH at last valid checkpoint (nominal)", f"{fmt(soh_last, 2)} %", "F2"],
            ["Retention at last valid checkpoint", f"{fmt(ret_last, 2)} %", "F3"],
            ["Capacity loss", f"{fmt(loss_ah, 4)} Ah ({fmt(loss_pct, 2)} %)", "BOL − last"],
            ["Linear fade rate (VERIFIED offsets)", f"{fmt(fade_per_100, 5)} Ah / 100 cycles", f"R² = {fmt(r2, 4)}"],
            ["Valid capacity cycles", f"{len(valid_cycles)} / {len(cycle_rows)}", "Discharge segment complete"],
            ["Feasibility status counts", "; ".join(f"{k}={v}" for k, v in sorted(feasibility_status_counts.items())), "LFP_capacity_soh_feasibility.csv"],
            ["Capacity status counts", "; ".join(f"{k}={v}" for k, v in sorted(capacity_status_counts.items())), "LFP_capacity_soh_feasibility.csv"],
            ["SOH status counts", "; ".join(f"{k}={v}" for k, v in sorted(soh_status_counts.items())), "LFP_capacity_soh_feasibility.csv"],
        ],
    ))
    report.append("")
    report.append("**Checkpoint trends**")
    report.append("")
    report.append(md_table(
        ["Checkpoint", "Valid cycles", "Median Q (Ah)", "Median SOH (%)", "Median retention (%)", "Median CE (%)"],
        [[st["checkpoint"], st["n_valid_discharge"],
          f"{st['q_median']:.4f}" if st["q_median"] is not None else "NA",
          f"{st['soh_median']:.2f}" if st["soh_median"] is not None else "NA",
          f"{st['ret_median']:.2f}" if st["ret_median"] is not None else "NA",
          f"{st['ce_median']:.2f}" if st["ce_median"] is not None else "NA"]
         for st in checkpoint_stats],
    ))
    report.append("")
    report.append(
        "The fade rate is fitted only on cycles whose global offset is `VERIFIED`. "
        f"The {len(underdetermined)} underdetermined cycle(s) from "
        f"{len(short_exports)} short export(s) are still summarised per checkpoint "
        "but are excluded from the regression. SOH and retention were not clipped. "
        f"{ret_gt100} valid cycle(s) exceeded 100% BOL retention and "
        f"{soh_gt100} exceeded 100% nominal SOH; these values are preserved."
    )
    report.append("")
    report.append(
        "**Charge capacity and coulombic efficiency are UNSUPPORTED FOR "
        "MODELLING.** They are reported only for diagnostic completeness where "
        "both segments are complete; charge-capacity segmentation across CC/CV "
        "transitions is not independently validated."
    )
    report.append("")
    report.append("## 8. Sampling and model readiness")
    report.append("")
    report.append(f"- Median sampling interval: **{fmt(median_dt_all, 3)} s**; "
                  f"maximum observed gap: **{fmt(max_dt_all, 1)} s**.")
    report.append(f"- Rows per cycle: **{min(s['data_rows'] for s in cycle_scans)}–"
                  f"{max(s['data_rows'] for s in cycle_scans)}**.")
    report.append("- Raw 1 s samples were preserved; **no interpolation** and no "
                  "synthetic cycles or cells were created.")
    report.append("- `LFP_staging_sample_raw_rows.csv` contains exactly **one** cycle "
                  "as a canonical-schema example; it is not the full raw telemetry "
                  "export, which remains in the source workbooks.")
    report.append("- One physical channel (`Un1Ch7`) is represented. Do **not** treat "
                  "workbooks or checkpoints as independent physical cells.")
    report.append("- Recommended validation: chronological / cycle-blocked splits, "
                  "never random row splits, to avoid leakage between adjacent "
                  "samples of the same cell. Group by the eventual verified cell ID.")
    report.append("- Temperature is absent, so temperature-dependent models cannot "
                  "be trained from this archive alone.")
    report.append("")
    report.append("## 9. Scientific source verification")
    report.append("")
    report.append(f"- DOI `{DOI}` resolved in this environment only via the "
                  f"institutional/Zenodo landing pages (the DOI resolver returned "
                  f"HTTP 403). The dataset title, authors, 1.25 Ah nominal capacity, "
                  f"2.50–3.65 V window, 25 °C test temperature, and 50/100-cycle "
                  f"export cadence are corroborated by those pages.")
    report.append("- The MultiStat / Solartron 1470E documents located online did not "
                  "state the units of the exported `I(A/cm2)` column. The unit "
                  "interpretation is therefore explicitly conditional and rests on "
                  "the workbook metadata and protocol arithmetic.")
    report.append("- No claim is made that B2–B6 or the complete six-condition archive "
                  "was audited. This report covers B1 only.")
    report.append("")
    report.append("## 10. Limitations and blockers")
    report.append("")
    report.append("1. **Archive ZIP not accessible:** the original zip and its checksum "
                  "are `NOT_INSPECTED`; the extracted workbooks are fully inspected.")
    report.append(f"2. **{total_missing_cycles} cycles missing** in "
                  f"{len(short_exports)} short export(s); global offsets for those "
                  "workbooks are `UNDERDETERMINED`.")
    report.append("3. **Current-density interpretation unsupported:** `A/cm2` cannot be "
                  "formed with `Surface Area = 0`; only total current is used.")
    report.append("4. **No cell identity / replication:** `battery_id` is `UNKNOWN`; "
                  "the folder label `BATTERY 1` and channel `Un1Ch7` are provenance "
                  "strings only.")
    report.append("5. **No temperature channel:** dataset-level 25 °C is metadata, not "
                  "a measured field.")
    report.append("6. **Manual summary sheets** in `Cycle_0100` and empty sheets in "
                  "`Cycle_1300` are non-standard and were not used as raw data.")
    report.append("7. **No capacity measurement independent of current:** F1 depends on the "
                  "conditional total-ampere interpretation; the column unit is not "
                  "instrument-confirmed (`UNDERDETERMINED`).")
    report.append("8. **Cycle 264 over-voltage/current transient:** real recorded values "
                  "(4.161499 V, -4.507276 A) are preserved and flagged; see the B1 "
                  "closure report for evidence and trend sensitivity.")
    report.append("")
    report.append("## 11. Integration handoff")
    report.append("")
    report.append("**Ready canonical fields:** `dataset_id`, `source_file`, "
                  "`condition_id`, `cycle_checkpoint`, `cycle_id`, `time_sec`, "
                  "`voltage_v`, `current_a`, `capacity_ah`, `soh_pct`, "
                  "`charge_discharge_phase`, `quality_flag`, `is_interpolated`, "
                  "`value_origin`, `formula_id`.")
    report.append("")
    report.append("- **NASA:** the canonical time/voltage/current/capacity fields map "
                  "conceptually, but NASA data are a different chemistry/format and "
                  "include temperature. Harmonise current sign, time origin, cycle "
                  "indexing, and capacity reference before pooling.")
    report.append("- **Sodium-ion:** same canonical schema can be reused, but the "
                  "voltage window, chemistry, and reference capacity must remain "
                  "dataset-specific. Do not pool SOH definitions without a documented "
                  "reference capacity.")
    report.append("- **Definitions to harmonise:** nominal-vs-BOL SOH, cycle numbering "
                  "(checkpoint vs global), current unit provenance, handling of "
                  "missing cycles, and replication level (cell vs channel vs file).")
    report.append("")
    report.append("## 12. Reproducibility")
    report.append("")
    report.append("```bash")
    report.append("python B1_LFP_Audit_Output/LFP_preprocessing.py \\")
    report.append("  --input-dir . \\")
    report.append("  --output-dir B1_LFP_Audit_Output")
    report.append("```")
    report.append("")
    report.append("The script is stdlib-only (Python 3.10+), reads the XLSX XML "
                  "directly, preserves all source files, and writes the manifest, "
                  "cleaning log, mapping, feasibility, formula register, cycle "
                  "summary, staging files, this report, `README.md`, "
                  "`validation_results.json`, and the ZIP.")
    report.append("")
    report.append("## 13. Quality-control checklist")
    report.append("")
    report.append(md_table(
        ["Check", "Status", "Evidence"],
        [
            ["ZIP extracted / inventory recorded", f"NOT_INSPECTED (archive outside sandbox); {len(workbooks)} workbooks present", "LFP_file_manifest.csv"],
            ["All 19 expected workbooks processed", f"{len(workbooks)}/19, errors={len(workbook_errors)}", "run_log.txt; validation_results.json"],
            ["Every accessible workbook/sheet inspected", "VERIFIED", f"{total_sheets} worksheets"],
            ["Source files unchanged", "VERIFIED", "no writes to .xlsx"],
            ["Unit interpretation evidence-based", "VERIFIED_WITH_CONDITIONS", "§5"],
            ["Current density not treated as total current", "VERIFIED", "current_density_a_cm2 = NA"],
            ["Capacity/SOH only where defensible", "VERIFIED_WITH_CONDITIONS", "F1–F3"],
            ["Observed vs derived distinguishable", "VERIFIED", "value_origin"],
            ["Battery identity not invented", "VERIFIED", "battery_id = UNKNOWN"],
            ["Missing cycles not fabricated", "VERIFIED", f"{total_missing_cycles} documented"],
            ["Output filenames/schemas present", "VERIFIED", "validation_results.json"],
            ["Script executed and outputs validated", "VERIFIED", "run_log.txt"],
            ["ZIP packaged", "VERIFIED (created by this script)", zip_path.name],
            ["Blockers disclosed", "VERIFIED", "§10"],
        ],
    ))
    report.append("")
    report.append("## 14. Deliverables")
    report.append("")
    for name in [
        "LFP_Audit_Report.md", "LFP_file_manifest.csv", "LFP_column_mapping.csv",
        "LFP_cleaning_log.csv", "LFP_capacity_soh_feasibility.csv",
        "LFP_formula_register.csv", "LFP_cycle_summary.csv",
        "LFP_staging_cycle_level.csv", "LFP_staging_sample_raw_rows.csv",
        "LFP_preprocessing.py", "README.md", "validation_results.json", "run_log.txt",
    ]:
        report.append(f"- `{name}`")
    report.append("")

    (output_dir / "LFP_Audit_Report.md").write_text("\n".join(report), encoding="utf-8")

    # ------------------------------------------------------------------
    # README
    # ------------------------------------------------------------------
    readme = []
    readme.append("# B1 LFP Audit Output")
    readme.append("")
    readme.append("This directory is the reproducible output of "
                  "`LFP_preprocessing.py` for condition "
                  f"`{CONDITION_ID}`.")
    readme.append("")
    readme.append("## Files")
    readme.append("")
    readme.append("| File | Purpose |")
    readme.append("|---|---|")
    readme.append("| `LFP_Audit_Report.md` | Full technical audit, provenance, quality, capacity/SOH, handoff |")
    readme.append("| `LFP_file_manifest.csv` | Per-worksheet inventory and inspection status |")
    readme.append("| `LFP_column_mapping.csv` | Source-to-canonical mapping with unit evidence |")
    readme.append("| `LFP_cleaning_log.csv` | Per-worksheet quality counts, flags, dropped/interpolated rows |")
    readme.append("| `LFP_capacity_soh_feasibility.csv` | Per-cycle capacity/SOH feasibility and blockers |")
    readme.append("| `LFP_formula_register.csv` | Formula IDs, assumptions, numerical examples |")
    readme.append("| `LFP_cycle_summary.csv` | Calculated cycle-level metrics |")
    readme.append("| `LFP_staging_cycle_level.csv` | Canonical cycle-level staging table |")
    readme.append("| `LFP_staging_sample_raw_rows.csv` | Exactly one raw cycle in canonical row format (staging sample, NOT the full telemetry export) |")
    readme.append("| `validation_results.json` | Full-run completion, output existence, schema and row-count validation |")
    readme.append("| `run_log.txt` | Complete execution log (preflight + 1/19..19/19 + validation) |")
    readme.append("")
    readme.append("## Scientific conditions")
    readme.append("")
    readme.append("- The source header is `I(A/cm2)`. Values are interpreted as total "
                  "current in amperes (`UNDERDETERMINED`), because `Surface Area = 0` "
                  "and the protocol sets 0.625 A (0.5C of 1.25 Ah); the exported unit is "
                  "not instrument-confirmed. The source label and raw values are "
                  "preserved unchanged; `current_density_a_cm2` is `NA`. See report §5.")
    readme.append("- Cycle/worksheet `current_excursion` flags use the documented "
                  "screening threshold 1.5 x 0.625 A = 0.9375 A (F6); values are not "
                  "clipped or deleted. Only Cycle_0300 cycle 14 (-4.507276 A) is flagged.")
    readme.append("- Capacity is computed with F1 only for complete discharge segments.")
    readme.append("- SOH_nominal (F2) and proxy-reference retention (F3) are separate; neither "
                  "is clipped. The reference is the first OBSERVED valid discharge, not a "
                  "validated BOL characterisation test.")
    readme.append("- Charge capacity and coulombic efficiency (F4) are diagnostic only and "
                  "UNSUPPORTED FOR MODELLING.")
    readme.append("- `battery_id` is `UNKNOWN`; no physical-cell replication is assumed.")
    readme.append("- No temperature channel exists.")
    readme.append("- Missing cycles are documented, not fabricated.")
    readme.append("- The full raw telemetry is summarised per cycle; only one cycle is "
                  "exported in full as `LFP_staging_sample_raw_rows.csv`.")
    readme.append("")
    readme.append("## Reproduce")
    readme.append("")
    readme.append("```bash")
    readme.append("python B1_LFP_Audit_Output/LFP_preprocessing.py --input-dir . --output-dir B1_LFP_Audit_Output")
    readme.append("```")
    readme.append("")
    (output_dir / "README.md").write_text("\n".join(readme), encoding="utf-8")

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    required = [
        "LFP_Audit_Report.md", "LFP_file_manifest.csv", "LFP_column_mapping.csv",
        "LFP_cleaning_log.csv", "LFP_capacity_soh_feasibility.csv",
        "LFP_formula_register.csv", "LFP_cycle_summary.csv",
        "LFP_staging_cycle_level.csv", "LFP_staging_sample_raw_rows.csv",
        "LFP_preprocessing.py", "README.md",
    ]
    processed_checkpoints = sorted(wb["checkpoint_label"] for wb in workbooks)
    sample_sheet_keys = {(r["source_file"], r["worksheet"]) for r in sample_rows}
    validation = {
        "generated_at": now_iso(),
        "input_dir": str(input_dir),
        "output_dir": str(output_dir),
        "preflight": {
            "expected_checkpoints": EXPECTED_CHECKPOINTS,
            "found_checkpoints": sorted(inventory),
            "missing_checkpoints": missing_checkpoints,
            "unexpected_checkpoints": unexpected_checkpoints,
        },
        "workbook_errors": workbook_errors,
        "required_files": {},
        "row_counts": {},
        "checks": {},
        "summary": {
            "workbooks_found": len(workbooks_paths),
            "workbooks_processed": len(workbooks),
            "workbook_errors": len(workbook_errors),
            "worksheets": total_sheets,
            "cycle_sheets": len(cycle_scans),
            "measurement_rows": total_cycle_data_rows,
            "valid_capacity_cycles": len(valid_cycles),
            "missing_cycles": total_missing_cycles,
            "sampling_median_s": median_dt_all,
            "reference_type": "PROXY_FIRST_VALID_DISCHARGE",
            "bol_capacity_ah": q_bol,
            "last_capacity_ah": q_last_float,
            "soh_last_pct": soh_last,
            "retention_last_pct": ret_last,
        },
    }
    for name in required:
        path = output_dir / name
        validation["required_files"][name] = path.exists() and path.stat().st_size > 0
    validation["row_counts"]["LFP_file_manifest.csv"] = len(manifest_rows)
    validation["row_counts"]["LFP_cleaning_log.csv"] = len(cleaning_rows)
    validation["row_counts"]["LFP_cycle_summary.csv"] = len(cycle_rows)
    validation["row_counts"]["LFP_capacity_soh_feasibility.csv"] = len(feasibility_rows)
    validation["row_counts"]["LFP_column_mapping.csv"] = len(column_mapping_rows)
    validation["row_counts"]["LFP_formula_register.csv"] = len(formula_rows)
    validation["row_counts"]["LFP_staging_cycle_level.csv"] = len(staging_cycle_rows)
    validation["row_counts"]["LFP_staging_sample_raw_rows.csv"] = len(sample_rows)
    validation["row_counts"]["workbooks_processed"] = len(workbooks)
    validation["row_counts"]["workbook_cycle_sheets"] = {
        wb["workbook_id"]: wb["n_cycles"] for wb in workbooks
    }
    validation["checks"]["manifest_rows_equal_worksheets_plus_errors"] = (
        len(manifest_rows) == total_worksheets + len(workbook_errors)
    )
    validation["checks"]["cycle_summary_rows_equal_cycle_sheets"] = len(cycle_rows) == len(cycle_scans)
    validation["checks"]["cleaning_rows_equal_worksheets"] = len(cleaning_rows) == total_worksheets
    validation["checks"]["all_required_files_present"] = all(validation["required_files"].values())
    validation["checks"]["no_fabricated_battery_id"] = all(
        r["battery_id"] == "UNKNOWN" for r in cycle_rows
    )
    validation["checks"]["capacity_computed"] = len(valid_cycles) > 0
    validation["checks"]["soh_in_plausible_range"] = all(
        0 <= float(r["soh_nominal_pct"]) <= 200 for r in valid_cycles
    )
    validation["checks"]["sample_raw_rows_nonempty"] = len(sample_rows) > 0
    validation["checks"]["sample_is_single_cycle"] = len(sample_sheet_keys) == 1
    validation["checks"]["incomplete_cycles_flagged"] = all(
        bool(r["quality_flags"]) for r in cycle_rows if r["cycle_valid"] == "false"
    )
    validation["checks"]["current_unit_interpretation_conditional"] = (
        "UNDERDETERMINED" in CURRENT_UNIT_STATUS
    )
    excursion_cycles = [r for r in cycle_rows if r["current_excursion_flag"] == "true"]
    validation["checks"]["current_excursion_flags_recorded"] = (
        len(excursion_cycles) == 1
        and excursion_cycles[0]["workbook_id"] == "Cycle_0300"
        and excursion_cycles[0]["cycle_id_within_file"] == "14"
    )
    validation["checks"]["all_19_expected_workbooks_processed"] = (
        processed_checkpoints == sorted(EXPECTED_CHECKPOINTS) and not workbook_errors
    )
    validation["overall"] = (
        "PASS"
        if all(validation["checks"].values())
        and all(validation["required_files"].values())
        and not workbook_errors
        else "FAIL"
    )
    (output_dir / "validation_results.json").write_text(
        json.dumps(validation, indent=2), encoding="utf-8"
    )

    log(f"Outputs written to {output_dir}")
    log(f"Validation: {validation['overall']}")
    for key, value in validation["checks"].items():
        log(f"  check {key}: {value}")
    log(f"Elapsed: {time.time() - t_start:.1f} s")

    # The run log is written before packaging so the archive contains the
    # complete record of the run. The archive's own hash is appended to the
    # on-disk copy afterwards (a file cannot contain its own hash).
    (output_dir / "run_log.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")

    # ------------------------------------------------------------------
    # ZIP (packaged exactly once; SHA-256 computed on the final archive)
    # ------------------------------------------------------------------
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(output_dir.rglob("*")):
            if not path.is_file() or path.resolve() == zip_path.resolve():
                continue
            if "__pycache__" in path.relative_to(output_dir).parts:
                continue
            zf.write(path, arcname=str(Path(output_dir.name) / path.relative_to(output_dir)))
    zip_sha = sha256_file(zip_path)
    zip_msg = (
        f"ZIP: {zip_path} "
        f"({zip_path.stat().st_size / 1e6:.2f} MB, sha256={zip_sha})"
    )
    print(zip_msg)
    with (output_dir / "run_log.txt").open("a", encoding="utf-8") as fh:
        fh.write(zip_msg + "\n")
    return 0 if validation["overall"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
