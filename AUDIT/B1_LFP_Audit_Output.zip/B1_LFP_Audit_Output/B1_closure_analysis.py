#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
B1 closure analysis (cycle 264 evidence + trend sensitivity)
=============================================================

This script does NOT rerun the 20-million-row preprocessing pipeline and does
NOT modify raw workbooks.  It reads the existing B1 audit outputs plus the raw
Cycle_0300.xlsx worksheet to:

  1. trace the cycle 264 voltage/current extremes to exact Excel cells;
  2. reproduce the F1 trapezoidal capacity from raw rows;
  3. quantify the contribution of the switching transient;
  4. compare the capacity-fade trend with and without cycle 264;
  5. verify missing-cycle offsets and formula denominators;
  6. write the closure report, evidence CSV, sensitivity CSV and validation JSON.

Scientific position:
  * The extreme values are real numeric cells, not parsing artefacts.
  * Cycle 264 is retained and flagged.  Exclusion is presented only as a
    sensitivity analysis, never as a corrected dataset.
  * The I(A/cm2) unit identity remains UNDERDETERMINED; total amperes is a
    plausible interpretation, not an instrument-confirmed fact.

Usage:
    python B1_closure_analysis.py --input-dir . --output-dir B1_LFP_Audit_Output
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import re
import statistics
import sys
import zipfile
from datetime import datetime
from pathlib import Path
import xml.etree.ElementTree as ET

TARGET_WORKBOOK = "Cycle_0300"
TARGET_LOCAL_CYCLE = 14
TARGET_GLOBAL_CYCLE = 264
NOMINAL_CAPACITY_AH = 1.25
PROTOCOL_CURRENT_A = 0.625
CURRENT_EXCURSION_FACTOR = 1.5
CURRENT_EXCURSION_THRESHOLD_A = PROTOCOL_CURRENT_A * CURRENT_EXCURSION_FACTOR
CURRENT_UNIT_STATUS = "UNDERDETERMINED_TOTAL_AMPERES_PLAUSIBLE"
PHASE_THRESHOLD_A = 0.01
MAX_DT_S = 60.0
EXPECTED_TOTAL_CYCLES = 1500
ACCEPTANCE = "PASS_WITH_CONDITIONS"

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def insert_field(fieldnames: list[str], name: str, after: str) -> list[str]:
    if name in fieldnames:
        return fieldnames
    index = fieldnames.index(after) + 1 if after in fieldnames else len(fieldnames)
    return fieldnames[:index] + [name] + fieldnames[index:]


def add_quality_token(flags: str, token: str, after: str = "out_of_protocol_voltage") -> str:
    tokens = [part for part in flags.split(";") if part]
    if token in tokens:
        return ";".join(tokens)
    if after in tokens:
        tokens.insert(tokens.index(after) + 1, token)
    else:
        tokens.append(token)
    return ";".join(tokens)


def excursion_extreme(row: dict) -> float:
    values = []
    for key in ("i_min", "i_max"):
        raw = row.get(key, "")
        if raw not in ("", None):
            values.append(abs(float(raw)))
    return max(values) if values else 0.0


def apply_current_excursion_flags(output_dir: Path, summary_rows: list[dict],
                                  cleaning_rows: list[dict]) -> dict:
    """Derive and persist the cycle/worksheet current-excursion flag.

    The flag uses only recorded i_min/i_max already present in the outputs.
    It does not alter any current or capacity value.
    """
    flagged_summary = []
    for row in summary_rows:
        is_flag = excursion_extreme(row) > CURRENT_EXCURSION_THRESHOLD_A
        row["current_excursion_flag"] = "true" if is_flag else "false"
        flags = row.get("quality_flags", "")
        if is_flag:
            row["quality_flags"] = add_quality_token(flags, "current_excursion")
        else:
            row["quality_flags"] = ";".join(
                part for part in flags.split(";") if part and part != "current_excursion"
            )
        if is_flag:
            flagged_summary.append(row)
    fields = list(summary_rows[0].keys())
    fields = insert_field(fields, "current_excursion_flag", "i_max")
    write_csv(output_dir / "LFP_cycle_summary.csv", fields, summary_rows)

    flagged_cleaning = []
    for row in cleaning_rows:
        if row.get("i_min", "") in ("", None) and row.get("i_max", "") in ("", None):
            row["current_excursion_flag"] = ""
            continue
        is_flag = excursion_extreme(row) > CURRENT_EXCURSION_THRESHOLD_A
        row["current_excursion_flag"] = "true" if is_flag else "false"
        flags = row.get("quality_flags", "")
        if is_flag:
            row["quality_flags"] = add_quality_token(flags, "current_excursion")
            flagged_cleaning.append(row)
        else:
            row["quality_flags"] = ";".join(
                part for part in flags.split(";") if part and part != "current_excursion"
            )
    fields = list(cleaning_rows[0].keys())
    fields = insert_field(fields, "current_excursion_flag", "i_max")
    write_csv(output_dir / "LFP_cleaning_log.csv", fields, cleaning_rows)

    summary_lookup = {
        (row["source_file"], row["cycle_id_within_file"]): row["current_excursion_flag"]
        for row in summary_rows
    }
    staging_path = output_dir / "LFP_staging_cycle_level.csv"
    staging_rows = read_csv(staging_path)
    for row in staging_rows:
        flag = summary_lookup.get((row["source_file"], row["cycle_id"]), "")
        row["current_excursion_flag"] = flag
        flags = row.get("quality_flag", "")
        if flag == "true":
            row["quality_flag"] = add_quality_token(flags, "current_excursion")
        else:
            row["quality_flag"] = ";".join(
                part for part in flags.split(";") if part and part != "current_excursion"
            )
    staging_fields = insert_field(list(staging_rows[0].keys()),
                                  "current_excursion_flag", "quality_flag")
    write_csv(staging_path, staging_fields, staging_rows)

    feasibility_path = output_dir / "LFP_capacity_soh_feasibility.csv"
    feasibility_rows = read_csv(feasibility_path)
    for row in feasibility_rows:
        row["total_current_status"] = CURRENT_UNIT_STATUS
    write_csv(feasibility_path, list(feasibility_rows[0].keys()), feasibility_rows)

    return {
        "summary_flagged": flagged_summary,
        "cleaning_flagged": flagged_cleaning,
    }


def md_table(headers: list[str], rows: list[list]) -> str:
    out = ["| " + " | ".join(headers) + " |",
           "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        out.append("| " + " | ".join(str(v) for v in row) + " |")
    return "\n".join(out)


def load_preprocessing(output_dir: Path):
    script = output_dir / "LFP_preprocessing.py"
    spec = importlib.util.spec_from_file_location("lfp_preprocessing", script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parse_sheet_rows(zf: zipfile.ZipFile, target: str, shared: list[str]):
    """Return [(excel_row, {col: (cell_ref, value, type)})] in sheet order."""
    root = ET.fromstring(zf.read(target))
    rows = []
    for row in root.findall(".//m:sheetData/m:row", NS):
        row_number = int(row.get("r"))
        cells = {}
        for cell in row.findall("m:c", NS):
            ref = cell.get("r")
            col = re.match(r"[A-Z]+", ref).group(0)
            cell_type = cell.get("t")
            value_node = cell.find("m:v", NS)
            inline_node = cell.find("m:is", NS)
            if value_node is not None:
                raw = value_node.text
                value = shared[int(raw)] if (cell_type == "s" and raw is not None) else raw
            elif inline_node is not None:
                value = "".join(
                    node.text or "" for node in inline_node.iter()
                    if node.tag.endswith("}t")
                )
            else:
                value = None
            cells[col] = (ref, value, cell_type)
        rows.append((row_number, cells))
    return rows


def numeric_triples(rows, header_row: int):
    out = []
    for row_number, cells in rows:
        if row_number <= header_row:
            continue
        t = cells.get("A")
        e = cells.get("B")
        i = cells.get("C")
        if not (t and e and i):
            continue
        try:
            t_val, e_val, i_val = float(t[1]), float(e[1]), float(i[1])
        except (TypeError, ValueError):
            continue
        out.append({
            "row": row_number,
            "t": t_val, "e": e_val, "i": i_val,
            "t_ref": t[0], "e_ref": e[0], "i_ref": i[0],
        })
    return out


def phase_of(current: float) -> str:
    if current > PHASE_THRESHOLD_A:
        return "charge"
    if current < -PHASE_THRESHOLD_A:
        return "discharge"
    return "rest"


def integrate(rows, skip_rows=frozenset()):
    """F1: trapezoidal |I| integration over discharge intervals."""
    total = 0.0
    contributions = []
    for left, right in zip(rows, rows[1:]):
        if left["row"] in skip_rows:
            continue
        dt = right["t"] - left["t"]
        if (left["i"] < -PHASE_THRESHOLD_A and right["i"] < -PHASE_THRESHOLD_A
                and 0 < dt <= MAX_DT_S):
            delta = 0.5 * (abs(left["i"]) + abs(right["i"])) * dt / 3600.0
            total += delta
            contributions.append((left["row"], right["row"], dt, delta))
    return total, contributions


def fit(pairs, lfp):
    if len(pairs) < 2:
        return {"n": len(pairs), "slope": None, "intercept": None,
                "r2": None, "fade_per_100": None}
    slope, intercept, r2 = lfp.linear_regression(
        [p[0] for p in pairs], [p[1] for p in pairs]
    )
    return {
        "n": len(pairs), "slope": slope, "intercept": intercept,
        "r2": r2, "fade_per_100": -slope * 100.0,
    }


def compress_ranges(values: list[int]) -> str:
    if not values:
        return "none"
    parts = []
    start = prev = values[0]
    for value in values[1:]:
        if value == prev + 1:
            prev = value
            continue
        parts.append(str(start) if start == prev else f"{start}-{prev}")
        start = prev = value
    parts.append(str(start) if start == prev else f"{start}-{prev}")
    return ", ".join(parts)


def main() -> int:
    parser = argparse.ArgumentParser(description="B1 closure analysis")
    parser.add_argument("--input-dir", default=".", help="directory with Cycle_*.xlsx")
    parser.add_argument("--output-dir", default="B1_LFP_Audit_Output", help="audit output dir")
    args = parser.parse_args()

    input_dir = Path(args.input_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    lfp = load_preprocessing(output_dir)

    log_lines = []

    def log(message: str) -> None:
        line = f"[{now_iso()}] {message}"
        print(line, flush=True)
        log_lines.append(line)

    log("B1 closure analysis started")
    log(f"input-dir={input_dir}")
    log(f"output-dir={output_dir}")

    summary_rows = read_csv(output_dir / "LFP_cycle_summary.csv")
    cleaning_rows = read_csv(output_dir / "LFP_cleaning_log.csv")
    manifest_rows = read_csv(output_dir / "LFP_file_manifest.csv")
    mapping_rows = read_csv(output_dir / "LFP_column_mapping.csv")
    validation = json.loads((output_dir / "validation_results.json").read_text(encoding="utf-8"))
    formula_rows = read_csv(output_dir / "LFP_formula_register.csv")
    flag_result = apply_current_excursion_flags(output_dir, summary_rows, cleaning_rows)

    target = next(
        (r for r in summary_rows
         if r["workbook_id"] == TARGET_WORKBOOK
         and r["cycle_id_within_file"] == str(TARGET_LOCAL_CYCLE)),
        None,
    )
    if target is None:
        raise SystemExit("ERROR: cycle 264 target row not found in LFP_cycle_summary.csv")
    if int(target["global_cycle_est"]) != TARGET_GLOBAL_CYCLE:
        raise SystemExit("ERROR: target global cycle does not match 264")

    reference_row = next(
        (r for r in summary_rows if r["capacity_discharge_ah"] != ""
         and r["global_cycle_est"] == "1"), None
    )
    valid_rows = [r for r in summary_rows if r["capacity_discharge_ah"] != ""]
    last_valid = valid_rows[-1]
    reference_ah = float(validation["summary"]["bol_capacity_ah"])
    last_ah = float(last_valid["capacity_discharge_ah"])

    cleaning_target = next(
        (r for r in cleaning_rows
         if r["workbook_id"] == TARGET_WORKBOOK
         and r["worksheet"] == "Run01_Un1Ch7_Step2_Cycle14"), None
    )
    manifest_target = next(
        (r for r in manifest_rows
         if r["workbook_id"] == TARGET_WORKBOOK
         and r["worksheet"] == cleaning_target["worksheet"]), None
    )
    header_row = int(manifest_target["header_row"])

    # ------------------------------------------------------------------
    # Raw workbook trace
    # ------------------------------------------------------------------
    workbook_path = input_dir / f"{TARGET_WORKBOOK}.xlsx"
    zf = zipfile.ZipFile(workbook_path)
    shared = lfp.read_shared_strings(zf)
    sheets = dict(lfp.workbook_sheets(zf))
    sheet_name = cleaning_target["worksheet"]
    if sheet_name not in sheets:
        raise SystemExit(f"ERROR: worksheet {sheet_name} not found in {workbook_path.name}")

    raw_rows = parse_sheet_rows(zf, sheets[sheet_name], shared)
    triples = numeric_triples(raw_rows, header_row)
    if len(triples) != int(target["rows"]):
        raise SystemExit(
            f"ERROR: raw data rows {len(triples)} != cycle summary rows {target['rows']}"
        )

    v_max_row = max(triples, key=lambda r: r["e"])
    i_min_row = min(triples, key=lambda r: r["i"])
    v_max = v_max_row["e"]
    i_min = i_min_row["i"]
    q_raw, contributions = integrate(triples)
    transient_rows = {r["row"] for r in triples if r["row"] <= 128}
    q_without_transient, _ = integrate(triples, skip_rows=transient_rows)
    transient_contribution = q_raw - q_without_transient
    discharge_rows = [r for r in triples if r["i"] < -PHASE_THRESHOLD_A]
    discharge_duration = discharge_rows[-1]["t"] - discharge_rows[0]["t"]
    median_abs_i = statistics.median(
        abs(r["i"]) for r in triples if r["row"] >= 129 and r["i"] < -PHASE_THRESHOLD_A
    )
    median_product = median_abs_i * discharge_duration / 3600.0

    # Previous sheet tail, to evidence the time reset.
    previous_sheet = "Run01_Un1Ch7_Step2_Cycle13"
    previous_rows = numeric_triples(parse_sheet_rows(zf, sheets[previous_sheet], shared), header_row)
    previous_last = previous_rows[-1]

    q_summary = float(target["capacity_discharge_ah"])
    checks = {}
    checks["raw_rows_match_summary"] = len(triples) == int(target["rows"])
    checks["v_max_matches_summary"] = abs(v_max - float(target["v_max"])) < 1e-6
    checks["i_min_matches_summary"] = abs(i_min - float(target["i_min"])) < 1e-6
    checks["f1_capacity_reproduced"] = abs(q_raw - q_summary) < 1e-6
    checks["voltage_max_cell_is_numeric"] = v_max_row["e_ref"] == "B125"
    checks["current_min_cell_is_numeric"] = i_min_row["i_ref"] == "C127"
    checks["time_reset_evidenced"] = triples[0]["t"] < previous_last["t"]
    checks["transient_contribution_small"] = transient_contribution < 0.005 * q_raw
    checks["raw_rows_preserved_no_interpolation"] = (
        sum(int(r["interpolated_rows"] or 0) for r in cleaning_rows) == 0
        and sum(int(r["dropped_rows"] or 0) for r in cleaning_rows) == 0
    )

    # ------------------------------------------------------------------
    # Sensitivity analysis
    # ------------------------------------------------------------------
    verified = [r for r in summary_rows
                if r["capacity_discharge_ah"] != ""
                and r["cycle_offset_confidence"] == "VERIFIED"
                and r["global_cycle_est"].isdigit()]
    pairs_all = [(int(r["global_cycle_est"]), float(r["capacity_discharge_ah"]))
                 for r in verified]
    pairs_without = [p for p in pairs_all if p[0] != TARGET_GLOBAL_CYCLE]
    pairs_valid_only = [
        (int(r["global_cycle_est"]), float(r["capacity_discharge_ah"]))
        for r in verified if r["cycle_valid"] == "true"
    ]
    stats_with = fit(pairs_all, lfp)
    stats_without = fit(pairs_without, lfp)
    stats_valid = fit(pairs_valid_only, lfp)
    published_fade = stats_with["fade_per_100"]

    sensitivity = []
    for scenario, stats, note in [
        ("WITH_CYCLE_264_PUBLISHED", stats_with,
         "As published; cycle 264 retained and flagged."),
        ("WITHOUT_CYCLE_264_SENSITIVITY", stats_without,
         "Sensitivity only; cycle 264 not removed from the dataset."),
        ("VALID_CYCLES_ONLY_SENSITIVITY", stats_valid,
         "Sensitivity only; excludes all cycle_valid=false rows, including cycle 264."),
    ]:
        sensitivity.append({
            "scenario": scenario,
            "n_cycles": stats["n"],
            "slope_ah_per_cycle": f"{stats['slope']:.10f}",
            "fade_ah_per_100_cycles": f"{stats['fade_per_100']:.8f}",
            "intercept_ah": f"{stats['intercept']:.8f}",
            "r2": f"{stats['r2']:.8f}",
            "delta_fade_vs_published_ah_per_100": f"{stats['fade_per_100'] - published_fade:+.10f}",
            "note": note,
        })

    # ------------------------------------------------------------------
    # Missing cycles and offsets
    # ------------------------------------------------------------------
    global_ids = [int(r["global_cycle_est"]) for r in summary_rows if r["global_cycle_est"]]
    missing = sorted(set(range(1, EXPECTED_TOTAL_CYCLES + 1)) - set(global_ids))
    duplicate_global_ids = len(global_ids) - len(set(global_ids))
    underdetermined = [r for r in summary_rows if r["cycle_offset_confidence"] != "VERIFIED"]
    underdetermined_workbooks = sorted({r["workbook_id"] for r in underdetermined})
    expected_missing = list(range(151, 171)) + list(range(1201, 1221))

    checks["missing_cycle_count_40"] = len(missing) == 40
    checks["missing_ranges_unchanged"] = missing == expected_missing
    checks["no_duplicate_global_ids"] = duplicate_global_ids == 0
    checks["underdetermined_offsets_preserved"] = (
        len(underdetermined) == 110
        and underdetermined_workbooks == ["Cycle_0200", "Cycle_1300"]
        and all(r["cycle_offset_confidence"] == "UNDERDETERMINED_TAIL_ALIGNED"
                for r in underdetermined)
    )
    checks["no_interpolated_missing_cycles"] = (
        sum(int(r["interpolated_rows"] or 0) for r in cleaning_rows) == 0
        and len(summary_rows) == 1460
    )

    # ------------------------------------------------------------------
    # Formula and reference verification
    # ------------------------------------------------------------------
    soh_target = q_raw / NOMINAL_CAPACITY_AH * 100.0
    retention_target = q_raw / reference_ah * 100.0
    soh_last = last_ah / NOMINAL_CAPACITY_AH * 100.0
    retention_last = last_ah / reference_ah * 100.0

    checks["f2_soh_reproduced"] = abs(soh_target - float(target["soh_nominal_pct"])) < 1e-3
    checks["f3_retention_reproduced"] = abs(
        retention_target - float(target["retention_bol_pct"])
    ) < 1e-3
    checks["proxy_reference_is_first_valid_discharge"] = (
        reference_row["workbook_id"] == "Cycle_0050"
        and reference_row["cycle_id_within_file"] == "1"
        and reference_row["cycle_valid"] == "false"  # partial charge; discharge valid
    )
    checks["last_capacity_unchanged"] = abs(last_ah - 1.094775) < 1e-6
    checks["soh_last_unchanged"] = abs(soh_last - 87.582) < 1e-3
    checks["retention_last_unchanged"] = abs(retention_last - 89.6923925) < 1e-3

    # ------------------------------------------------------------------
    # Cycle 264 evidence CSV
    # ------------------------------------------------------------------
    evidence_notes = {
        125: "First data row; only positive-current sample; over-protocol voltage; T restarts at 31 s.",
        126: "First negative-current sample; -4.01535 A switching transient; voltage falls to 3.813599 V.",
        127: "Current minimum -4.507276 A; voltage 3.550598 V.",
        128: "Current recovering; -1.773718 A.",
        129: "Current returns to about -0.632 A; voltage 3.674670 V.",
        7243: "Last data row; discharge ends at 2.496912 V.",
    }
    evidence_rows = []
    for row in triples:
        if row["row"] not in evidence_notes:
            continue
        evidence_rows.append({
            "source_file": workbook_path.name,
            "worksheet": sheet_name,
            "excel_row": row["row"],
            "time_cell": row["t_ref"],
            "voltage_cell": row["e_ref"],
            "current_cell": row["i_ref"],
            "time_s": f"{row['t']:.0f}",
            "voltage_v": f"{row['e']:.9f}",
            "current_a": f"{row['i']:.9f}",
            "protocol_current_a": f"{PROTOCOL_CURRENT_A:.3f}",
            "excursion_threshold_a": f"{CURRENT_EXCURSION_THRESHOLD_A:.4f}",
            "abs_current_over_protocol": f"{abs(row['i']) / PROTOCOL_CURRENT_A:.4f}",
            "current_excursion": ("true" if abs(row["i"]) > CURRENT_EXCURSION_THRESHOLD_A else "false"),
            "phase": phase_of(row["i"]),
            "note": evidence_notes[row["row"]],
        })
    evidence_rows.insert(0, {
        "source_file": workbook_path.name,
        "worksheet": previous_sheet,
        "excel_row": previous_last["row"],
        "time_cell": previous_last["t_ref"],
        "voltage_cell": previous_last["e_ref"],
        "current_cell": previous_last["i_ref"],
        "time_s": f"{previous_last['t']:.0f}",
        "voltage_v": f"{previous_last['e']:.9f}",
        "current_a": f"{previous_last['i']:.9f}",
        "protocol_current_a": f"{PROTOCOL_CURRENT_A:.3f}",
        "excursion_threshold_a": f"{CURRENT_EXCURSION_THRESHOLD_A:.4f}",
        "abs_current_over_protocol": f"{abs(previous_last['i']) / PROTOCOL_CURRENT_A:.4f}",
        "current_excursion": ("true" if abs(previous_last["i"]) > CURRENT_EXCURSION_THRESHOLD_A else "false"),
        "phase": phase_of(previous_last["i"]),
        "note": "Last row of preceding sheet; next sheet restarts T at 31 s and starts at 4.161499 V.",
    })
    write_csv(
        output_dir / "B1_cycle264_evidence.csv",
        ["source_file", "worksheet", "excel_row", "time_cell", "voltage_cell",
         "current_cell", "time_s", "voltage_v", "current_a", "protocol_current_a",
         "excursion_threshold_a", "abs_current_over_protocol", "current_excursion",
         "phase", "note"],
        evidence_rows,
    )

    write_csv(
        output_dir / "B1_trend_sensitivity.csv",
        ["scenario", "n_cycles", "slope_ah_per_cycle", "fade_ah_per_100_cycles",
         "intercept_ah", "r2", "delta_fade_vs_published_ah_per_100", "note"],
        sensitivity,
    )

    # ------------------------------------------------------------------
    # Closure validation JSON
    # ------------------------------------------------------------------
    mapping_current = next(
        (r for r in mapping_rows if r["canonical_field"] == "current_a"), {}
    )
    checks["current_unit_not_confirmed"] = (
        "UNDERDETERMINED" in mapping_current.get("interpretation_status", "").upper()
        or "UNSUPPORTED" in mapping_current.get("unit_status", "").upper()
        or "CONDITION" in mapping_current.get("unit_status", "").upper()
        or "condition" in mapping_current.get("notes", "").lower()
    )

    cleaning_target = next(
        (r for r in cleaning_rows
         if r["workbook_id"] == TARGET_WORKBOOK
         and r["worksheet"] == sheet_name), None
    )
    normal_control = next(
        (r for r in summary_rows
         if r["workbook_id"] == "Cycle_0050"
         and r["cycle_id_within_file"] == "2"), None
    )
    summary_flagged = flag_result["summary_flagged"]
    cleaning_flagged = flag_result["cleaning_flagged"]
    checks["current_excursion_threshold_documented"] = (
        abs(CURRENT_EXCURSION_THRESHOLD_A - 0.9375) < 1e-12
    )
    checks["current_excursion_column_present"] = (
        "current_excursion_flag" in target
        and "current_excursion_flag" in cleaning_target
    )
    checks["cycle_264_current_excursion_flagged"] = (
        target.get("current_excursion_flag") == "true"
        and "current_excursion" in target.get("quality_flags", "").split(";")
        and cleaning_target.get("current_excursion_flag") == "true"
    )
    checks["current_excursion_no_false_positives"] = (
        len(summary_flagged) == 1
        and len(cleaning_flagged) == 1
        and summary_flagged[0]["workbook_id"] == TARGET_WORKBOOK
        and summary_flagged[0]["cycle_id_within_file"] == str(TARGET_LOCAL_CYCLE)
        and cleaning_flagged[0]["worksheet"] == sheet_name
        and normal_control is not None
        and normal_control.get("current_excursion_flag") == "false"
    )
    checks["current_excursion_all_measurement_sheets_checked"] = (
        sum(1 for row in cleaning_rows if row.get("i_min", "") not in ("", None)) == 1498
    )
    checks["current_extremes_preserved"] = (
        abs(float(target["i_min"]) - i_min) < 1e-6
        and abs(float(target["i_max"]) - max(r["i"] for r in triples)) < 1e-6
    )
    staging_target = next(
        (r for r in read_csv(output_dir / "LFP_staging_cycle_level.csv")
         if r["source_file"] == workbook_path.name
         and r["cycle_id"] == str(TARGET_LOCAL_CYCLE)), {}
    )
    checks["current_excursion_staging_consistent"] = (
        staging_target.get("current_excursion_flag") == "true"
        and "current_excursion" in staging_target.get("quality_flag", "").split(";")
    )
    checks["no_rows_clipped_or_deleted"] = (
        len(summary_rows) == 1460
        and sum(int(r["interpolated_rows"] or 0) for r in cleaning_rows) == 0
        and sum(int(r["dropped_rows"] or 0) for r in cleaning_rows) == 0
    )

    mapping_notes = mapping_current.get("notes", "").lower()
    checks["current_unit_wording_conditional"] = (
        "UNDERDETERMINED" in mapping_current.get("unit_status", "").upper()
        and "UNDERDETERMINED" in mapping_current.get("interpretation_status", "").upper()
        and "not instrument-confirmed" in mapping_notes
        and "erroneous" not in mapping_notes
    )
    f4 = next((r for r in formula_rows if r["formula_id"] == "F4"), {})
    f6 = next((r for r in formula_rows if r["formula_id"] == "F6"), {})
    checks["charge_capacity_ce_unsupported"] = (
        f4.get("validation_status") == "UNSUPPORTED_FOR_MODELLING"
    )
    checks["current_excursion_formula_registered"] = (
        "0.9375" in f6.get("formula", "")
        and "SCREENING_HEURISTIC" in f6.get("validation_status", "")
    )
    audit_text = (output_dir / "LFP_Audit_Report.md").read_text(encoding="utf-8")
    readme_text = (output_dir / "README.md").read_text(encoding="utf-8")
    checks["report_reflects_flag_and_ce_status"] = (
        "current_excursion" in audit_text
        and "UNSUPPORTED FOR MODELLING" in audit_text
        and "current_excursion" in readme_text
        and "UNSUPPORTED FOR MODELLING" in readme_text
    )
    checks["sensitivity_with_without_264_retained"] = (
        stats_with["n"] == 1346
        and stats_without["n"] == 1345
        and stats_valid["n"] == 1343
    )
    checks["validation_overall_pass"] = validation.get("overall") == "PASS"
    checks["all_19_workbooks_processed"] = (
        validation.get("summary", {}).get("workbooks_processed") == 19
    )

    unresolved = [
        "Source header is I(A/cm2); total amperes is plausible from Surface Area=0 and the 0.625 A setpoint, but the exported unit is not instrument-confirmed (UNDERDETERMINED).",
        "Proxy reference is the first observed valid discharge (1.220588 Ah), not a validated BOL test.",
        "40 cycles are absent (151-170 and 1201-1220); Cycle_0200 and Cycle_1300 offsets remain UNDERDETERMINED_TAIL_ALIGNED.",
        "Physical cell identity and replication are unknown (battery_id = UNKNOWN).",
        "No measured temperature channel; 25 degC is dataset-level metadata.",
        "Cycle 264 contains a real over-voltage/current switching transient; cause is not documented.",
        "Charge capacity and coulombic efficiency are diagnostic only and unsupported for modelling.",
    ]

    closure_validation = {
        "generated_at": now_iso(),
        "acceptance_status": ACCEPTANCE,
        "scope": "B1 only; no other B datasets modified",
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "cycle_264": {
            "source_file": workbook_path.name,
            "worksheet": sheet_name,
            "global_cycle_est": TARGET_GLOBAL_CYCLE,
            "cycle_id_within_file": TARGET_LOCAL_CYCLE,
            "cycle_offset_confidence": target["cycle_offset_confidence"],
            "voltage_max_v": v_max,
            "voltage_max_cell": v_max_row["e_ref"],
            "voltage_max_excel_row": v_max_row["row"],
            "current_min_a": i_min,
            "current_min_cell": i_min_row["i_ref"],
            "current_min_excel_row": i_min_row["row"],
            "capacity_discharge_ah": q_raw,
            "capacity_summary_ah": q_summary,
            "discharge_duration_s": discharge_duration,
            "transient_rows": sorted(transient_rows),
            "transient_capacity_contribution_ah": transient_contribution,
            "capacity_without_transient_ah": q_without_transient,
            "median_abs_current_a": median_abs_i,
            "median_current_times_duration_ah": median_product,
            "quality_flags": target["quality_flags"],
            "interpretation": (
                "Real numeric telemetry; capacity is driven mainly by the 7117 s "
                "discharge from an over-protocol starting voltage, not by the "
                "1-second current spikes. No rows deleted or clipped."
            ),
        },
        "trend": {
            "published": stats_with,
            "without_cycle_264": stats_without,
            "valid_cycles_only": stats_valid,
            "delta_fade_ah_per_100_cycles": (
                stats_without["fade_per_100"] - stats_with["fade_per_100"]
            ),
            "conclusion": (
                "Cycle 264 has negligible leverage on the fade trend; exclusion is "
                "not justified. It remains in the dataset and is reported as a "
                "sensitivity only."
            ),
        },
        "final_metrics": {
            "proxy_reference_ah": reference_ah,
            "last_capacity_ah": last_ah,
            "soh_nominal_last_pct": soh_last,
            "retention_proxy_last_pct": retention_last,
        },
        "current_excursion_flag": {
            "formula_id": "F6",
            "threshold_a": CURRENT_EXCURSION_THRESHOLD_A,
            "factor": CURRENT_EXCURSION_FACTOR,
            "protocol_current_a": PROTOCOL_CURRENT_A,
            "basis": "Screening heuristic at 150% of the 0.625 A CC setpoint; not an instrument limit",
            "flagged_cycles": len(summary_flagged),
            "flagged_worksheets": len(cleaning_flagged),
            "worksheets_with_current_telemetry": sum(
                1 for row in cleaning_rows
                if row.get("i_min", "") not in ("", None)
            ),
            "false_positives_observed": max(0, len(cleaning_flagged) - 1),
            "cycle_264_min_a": i_min,
            "cycle_264_ratio_to_protocol": abs(i_min) / PROTOCOL_CURRENT_A,
            "raw_values_preserved": True,
            "rows_clipped_or_deleted": 0,
        },
        "charge_capacity_ce": {
            "formula_id": "F4",
            "status": "UNSUPPORTED_FOR_MODELLING",
            "reason": "Charge-capacity segmentation across CC/CV transitions is not independently validated; diagnostic only.",
        },
        "raw_audit_scope": (
            "Closure pass re-read only Cycle_0300.xlsx for row-level evidence. The "
            "full 19-workbook audit was not independently repeated here; its "
            "execution record is run_log.txt and validation_results.json."
        ),
        "missing_cycles": {
            "count": len(missing),
            "ranges": compress_ranges(missing),
            "underdetermined_cycles": len(underdetermined),
            "underdetermined_workbooks": underdetermined_workbooks,
        },
        "unresolved_limitations": unresolved,
    }

    # ------------------------------------------------------------------
    # Closure report
    # ------------------------------------------------------------------
    report = []
    report.append("# B1 LFP Closure Report — cycle 264 and acceptance")
    report.append("")
    report.append(f"**Generated:** {now_iso()}  ")
    report.append("**Scope:** B1 (Discharge 0.5C / Charge 0.5C) only  ")
    report.append(f"**Acceptance status:** **{ACCEPTANCE}**")
    report.append("")
    report.append("## 1. What was inspected")
    report.append("")
    report.append("- `LFP_Audit_Report.md`, `validation_results.json`, `run_log.txt`.")
    report.append("- `LFP_cycle_summary.csv`, `LFP_cleaning_log.csv`, `LFP_file_manifest.csv`,")
    report.append("  `LFP_formula_register.csv`, `LFP_column_mapping.csv`.")
    report.append("- Raw `Cycle_0300.xlsx` worksheet `Run01_Un1Ch7_Step2_Cycle14` (rows 125–7243)")
    report.append("  and the tail of `Run01_Un1Ch7_Step2_Cycle13`.")
    report.append("")
    report.append("No raw workbook was modified and the 20 M-row pipeline was not rerun.")
    report.append("")
    report.append("## 2. Cycle 264 — raw evidence")
    report.append("")
    report.append(md_table(
        ["Field", "Value"],
        [
            ["Workbook", f"{workbook_path.name} / {sheet_name}"],
            ["Estimated global cycle", f"{TARGET_GLOBAL_CYCLE} (local cycle {TARGET_LOCAL_CYCLE}; offset {target['cycle_offset_confidence']})"],
            ["Voltage maximum", f"{v_max:.9f} V at `{v_max_row['e_ref']}` (Excel row {v_max_row['row']})"],
            ["Current minimum", f"{i_min:.9f} A at `{i_min_row['i_ref']}` (Excel row {i_min_row['row']})"],
            ["Capacity (F1)", f"{q_raw:.9f} Ah (summary: {q_summary:.6f} Ah)"],
            ["Discharge duration", f"{discharge_duration:.0f} s over {len(discharge_rows)} samples"],
            ["Quality flags", target["quality_flags"]],
        ],
    ))
    report.append("")
    report.append("The first five data rows show a recorded switching transient:")
    report.append("")
    report.append(md_table(
        ["Excel row", "T (s)", "E (V)", "I (A)", "Phase"],
        [[r["row"], f"{r['t']:.0f}", f"{r['e']:.6f}", f"{r['i']:.6f}", phase_of(r["i"])]
         for r in triples[:5]],
    ))
    report.append("")
    report.append(
        f"The preceding sheet ends at T = {previous_last['t']:.0f} s, "
        f"E = {previous_last['e']:.6f} V, I = {previous_last['i']:.6f} A. "
        "The new sheet restarts at T = 31 s and begins at 4.161499 V, so the "
        "cross-sheet time reset and the voltage discontinuity are both evidenced."
    )
    report.append("")
    report.append("**Calculation-path check.** Re-integrating the raw rows with F1 gives ")
    report.append(f"{q_raw:.9f} Ah, matching the stored capacity. Removing the four ")
    report.append("transient rows (125–128) changes capacity by only ")
    report.append(f"{transient_contribution:.9f} Ah ({(transient_contribution / q_raw * 100):.3f}%): ")
    report.append(f"median |I| × duration = {median_abs_i:.6f} A × {discharge_duration:.0f} s / 3600 = ")
    report.append(f"{median_product:.6f} Ah. The excess capacity therefore comes mainly ")
    report.append("from the longer discharge beginning at an over-protocol voltage, not from ")
    report.append("the 1-second current spikes. The physical cause of the discontinuity is ")
    report.append("not documented; no explanation is invented.")
    report.append("")
    report.append("## 3. Current-excursion quality flag (F6)")
    report.append("")
    report.append(
        f"Threshold: **|I| > 1.5 × {PROTOCOL_CURRENT_A:.3f} A = "
        f"{CURRENT_EXCURSION_THRESHOLD_A:.4f} A**. The protocol CC setpoint is "
        f"0.625 A; a 50% overshoot above that setpoint is not expected during "
        f"steady CC/CV operation. This is a documented screening heuristic, not "
        f"an instrument limit. It is derived only from recorded `i_min`/`i_max`; "
        f"no current value was clipped, replaced, or deleted."
    )
    report.append("")
    report.append(md_table(
        ["Excel row", "I (A)", "|I| / 0.625 A", "Flag"],
        [[r["row"], f"{r['i']:.6f}", f"{abs(r['i']) / PROTOCOL_CURRENT_A:.2f}x",
          "true" if abs(r["i"]) > CURRENT_EXCURSION_THRESHOLD_A else "false"]
         for r in triples[1:4]],
    ))
    report.append("")
    report.append(
        f"Cycle 264 is flagged `current_excursion` in both `LFP_cycle_summary.csv` "
        f"and `LFP_cleaning_log.csv`; its recorded minimum is {i_min:.6f} A "
        f"({abs(i_min) / PROTOCOL_CURRENT_A:.2f}× protocol). Across all 1,498 "
        f"worksheets with current telemetry, {len(cleaning_flagged)} worksheet and "
        f"{len(summary_flagged)} cycle exceed the threshold, so **zero false "
        f"positives** were observed in this dataset. A normal cycle "
        f"(Cycle_0050 cycle 2) remains unflagged. The flag is also carried into "
        f"`LFP_staging_cycle_level.csv`; no cycle record was added or renumbered."
    )
    report.append("")
    report.append("## 4. Sensitivity: trend with vs without cycle 264")
    report.append("")
    report.append(md_table(
        ["Scenario", "n", "Fade (Ah/100 cycles)", "R²", "Δ vs published"],
        [[r["scenario"], r["n_cycles"], r["fade_ah_per_100_cycles"], r["r2"],
          r["delta_fade_vs_published_ah_per_100"]] for r in sensitivity],
    ))
    report.append("")
    report.append(
        f"Excluding cycle 264 changes the fade rate by "
        f"{stats_without['fade_per_100'] - stats_with['fade_per_100']:+.8f} Ah/100 cycles "
        f"({abs(stats_without['fade_per_100'] - stats_with['fade_per_100']) / stats_with['fade_per_100'] * 100:.3f}% relative). "
        "The point has low leverage because the series spans 1,500 cycles. "
        "Exclusion is therefore **not justified** as a data correction; cycle 264 is "
        "retained with its flags, and the without-264 result is a sensitivity only."
    )
    report.append("")
    report.append("Final reported metrics are unchanged:")
    report.append("")
    report.append(md_table(
        ["Metric", "Value", "Definition"],
        [
            ["Proxy reference", f"{reference_ah:.6f} Ah", "First observed valid discharge (F3 denominator)"],
            ["Last capacity", f"{last_ah:.6f} Ah", "Last valid discharge (global cycle 1500)"],
            ["Nominal SOH", f"{soh_last:.3f} %", "F2: Q / 1.25 Ah × 100"],
            ["Proxy retention", f"{retention_last:.3f} %", "F3: Q / proxy reference × 100"],
            ["Fade rate (published)", f"{stats_with['fade_per_100']:.6f} Ah/100 cycles", f"OLS on {stats_with['n']} VERIFIED-offset cycles"],
        ],
    ))
    report.append("")
    report.append("## 5. Missing cycles and uncertain offsets")
    report.append("")
    report.append(
        f"{len(missing)} cycles are absent: {compress_ranges(missing)}. "
        f"{len(underdetermined)} cycle rows in {', '.join(underdetermined_workbooks)} carry "
        "`UNDERDETERMINED_TAIL_ALIGNED`; no missing cycle was interpolated or fabricated, "
        "and no global ID was silently changed."
    )
    report.append("")
    report.append("## 6. Formula and reference verification")
    report.append("")
    report.append(md_table(
        ["Formula", "Check", "Result"],
        [
            ["F1", "Raw trapezoidal integration vs stored capacity", f"{q_raw:.9f} vs {q_summary:.6f} Ah — reproduced"],
            ["F2", "Q / 1.25 Ah × 100", f"{soh_target:.3f} % (stored {target['soh_nominal_pct']} %)"],
            ["F3", "Q / first observed valid discharge × 100", f"{retention_target:.3f} % (stored {target['retention_bol_pct']} %)"],
            ["F3 denominator", "Proxy reference row", f"Cycle_0050 cycle 1 = {reference_ah:.6f} Ah; observed valid discharge, partial charge, no validated BOL test"],
            ["F4", "Charge capacity / coulombic efficiency", "Reported for diagnostics only; UNSUPPORTED_FOR_MODELLING (charge segmentation not independently validated)"],
            ["F6", "abs(I) > 1.5 × 0.625 A = 0.9375 A", f"Cycle 264 flagged; {len(cleaning_flagged)} worksheet(s) flagged in total; raw values preserved"],
        ],
    ))
    report.append("")
    report.append("The first valid **discharge** is used as a proxy baseline; it is not ")
    report.append("a validated beginning-of-life capacity. F2 and F3 are kept separate. ")
    report.append("Charge capacity and CE remain unsupported for modelling.")
    report.append("")
    report.append("## 7. Current-unit status")
    report.append("")
    report.append(
        "The source header is `I(A/cm2)`. Total amperes is the plausible "
        "interpretation because `Surface Area = 0` and the protocol sets 0.625 A "
        "(0.5C of 1.25 Ah), but the exported unit is **not instrument-confirmed**. "
        "The unit identity is therefore **UNDERDETERMINED**; the source label and "
        "raw values are preserved, and all capacity/SOH results remain conditional "
        "on the total-ampere interpretation. No claim is made that the source "
        "label is wrong."
    )
    report.append("")
    report.append("## 8. Acceptance and recommendation")
    report.append("")
    report.append(f"**Acceptance: {ACCEPTANCE}.** All closure checks pass, but the following ")
    report.append("documented limitations remain:")
    report.append("")
    for item in unresolved:
        report.append(f"- {item}")
    report.append("")
    report.append("**Go/no-go:** **GO** for integration into the master dataset, with conditions:")
    report.append("")
    report.append("- carry `quality_flag`, `current_excursion_flag`, `cycle_offset_confidence`, and the proxy-reference label;")
    report.append("- keep cycle 264 in the dataset and treat its exclusion as sensitivity only;")
    report.append("- treat capacity/SOH as conditional on the unit interpretation;")
    report.append("- do not use charge capacity or coulombic efficiency for modelling;")
    report.append("- do not count workbooks/checkpoints as independent cells;")
    report.append("- reconcile missing cycles explicitly when pooling with other chemistries.")
    report.append("")
    report.append("This dataset is not perfect, fully clean, or scientific ground truth.")
    report.append("")
    report.append("## 9. Tests executed")
    report.append("")
    report.append(md_table(
        ["Check", "Result"],
        [[name, "PASS" if value else "FAIL"] for name, value in checks.items()],
    ))
    report.append("")
    report.append(
        f"**{sum(1 for value in checks.values() if value)}/{len(checks)} checks "
        f"passed.** No check is unresolved. The unresolved items listed in §8 are "
        "documented data limitations, not failed tests. The original full raw "
        "audit was not independently repeated in this closure pass: only "
        "`Cycle_0300.xlsx` was re-read for row-level evidence, while the complete "
        "19-workbook execution is recorded in `run_log.txt` and "
        "`validation_results.json`."
    )
    report.append("")
    report.append("## 10. Changed files and hashes")
    report.append("")
    changed_names = [
        "LFP_Audit_Report.md", "LFP_formula_register.csv", "LFP_column_mapping.csv",
        "README.md", "LFP_preprocessing.py", "B1_cycle264_evidence.csv",
        "B1_trend_sensitivity.csv", "B1_closure_analysis.py",
        "LFP_cycle_summary.csv", "LFP_cleaning_log.csv",
        "LFP_capacity_soh_feasibility.csv", "LFP_staging_cycle_level.csv",
    ]
    closure_validation["changed_files"] = {
        name: sha256_file(output_dir / name) for name in changed_names
    }
    (output_dir / "B1_closure_validation.json").write_text(
        json.dumps(closure_validation, indent=2), encoding="utf-8"
    )

    hash_targets = changed_names + ["B1_closure_validation.json"]
    report.append(md_table(
        ["File", "SHA-256"],
        [[name, sha256_file(output_dir / name)] for name in hash_targets],
    ))
    report.append("")
    report.append("`B1_closure_validation.json` records every check and the acceptance status.")
    report.append("")
    report.append("## 11. Reproduce")
    report.append("")
    report.append("```bash")
    report.append("python B1_LFP_Audit_Output/B1_closure_analysis.py \\")
    report.append("  --input-dir . --output-dir B1_LFP_Audit_Output")
    report.append("```")
    report.append("")
    (output_dir / "B1_Closure_Report.md").write_text("\n".join(report), encoding="utf-8")

    checksum_names = [
        "LFP_Audit_Report.md", "LFP_formula_register.csv", "README.md",
        "LFP_preprocessing.py", "B1_cycle264_evidence.csv",
        "B1_trend_sensitivity.csv", "B1_Closure_Report.md",
        "B1_closure_analysis.py", "B1_closure_validation.json",
        "validation_results.json", "LFP_cycle_summary.csv",
        "LFP_cleaning_log.csv", "LFP_file_manifest.csv",
        "LFP_column_mapping.csv", "LFP_capacity_soh_feasibility.csv",
        "LFP_staging_cycle_level.csv",
    ]
    checksum_lines = [f"{sha256_file(output_dir / name)}  {name}" for name in checksum_names]
    (output_dir / "B1_closure_checksums.txt").write_text(
        "\n".join(checksum_lines) + "\n", encoding="utf-8"
    )

    log(f"current-excursion threshold = {CURRENT_EXCURSION_THRESHOLD_A:.4f} A; "
        f"flagged cycles = {len(summary_flagged)}; flagged worksheets = {len(cleaning_flagged)}")
    log(f"cycle 264 Q = {q_raw:.9f} Ah; transient contribution = {transient_contribution:.9f} Ah")
    log(f"fade published = {published_fade:.8f}; without 264 = {stats_without['fade_per_100']:.8f} Ah/100 cycles")
    log(f"checks: {sum(checks.values())}/{len(checks)} true")
    log(f"acceptance: {ACCEPTANCE}")
    log("artifacts: B1_Closure_Report.md, B1_cycle264_evidence.csv, B1_trend_sensitivity.csv, "
        "B1_closure_validation.json, B1_closure_checksums.txt")
    (output_dir / "B1_closure_run_log.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")

    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
