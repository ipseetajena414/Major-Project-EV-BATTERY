# LFP B6 Dataset Audit Report

**Audit date:** 2026-10-26  
**Input archive:** `B6_Discharge0.5C_Charge2C.zip`  
**Condition folder present:** `B6_Discharge0.5C_Charge2C`  
**Overall status:** `VERIFIED_WITH_CONDITIONS` for the supplied B6 subset; not an audit of the full six-condition dataset.

## Executive findings

- All 19 Excel workbook entries were read and parsed (ZIP member CRCs are verified as each member is read); the archive contains **20 entries** including the root directory and **1760 worksheets** parsed from the workbooks. No non-Excel documentation files were present in the supplied archive: `[]`.
- All supplied workbook names/checkpoints observed: `50, 100, 150, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700`. These are filename-level checkpoint labels, not assigned as global cycle IDs for each worksheet.
- **1702 cycle-like worksheet tabs** were summarized (including 16 generic `SheetN` telemetry tabs in `Cycle_0700.xlsx`); **1697** pass the conservative complete-discharge screen and **5** remain partial/underdetermined. Separate OCV/rest tabs remain in the manifest and cleaning log but are not treated as cycles. These are worksheet tabs, not independent cells.
- Source workbook paths contain the internal label **`BATTERY 6`**. This is retained as a source-provided cell label, but this B6-only archive cannot independently establish the total number of physical cells or cross-condition cell independence.
- MSTAT `Cell Information` strings report `Surface Area: 0` and `Sample Capacity: 0`. No measured temperature column or direct numeric capacity column was found in the three-column telemetry schema.
- The workbook source header labels current as `I(A/cm2)`. Current values, however, align closely with the MSTAT experiment setpoints (**Charge CC 2.4; Discharge CC 0.625**). The raw column is **not renamed**. Capacity and nominal SOH below are explicitly **conditional on interpreting the recorded signal as total A**; they should not be treated as fully unit-verified until confirmed by authors/MSTAT documentation.
- Workbook `File List` tabs index only part of the actual workbook tabs in **4 workbook(s)**. Worksheet inventory is derived from `xl/workbook.xml`, which is the workbook's actual tab list.
- Nominal-capacity-based capacity/SOH calculations were computed **conditionally** from observed negative-current intervals, using trapezoidal integration and actual timestamp differences. A validated measured BOL reference was not identified. Retention/loss is included only against the **first observed valid cycle-tab capacity proxy**, never labelled as validated BOL retention.

## Scope and provenance

Official dataset record: https://research.birmingham.ac.uk/en/datasets/experimental-dataset-for-cycle-ageing-of-lfp-18650-lithium-ion-ba/  
DOI: https://doi.org/10.5281/zenodo.22286449  
The official record describes LFP 18650 cells, nominal capacity 1.25 Ah, test temperature 25 °C, operating-voltage range 2.50–3.65 V, and Solartron 1470E/MSTAT acquisition. It describes periodic age checkpoints. Those are source-level claims, not individual measured temperature records. The official page does not prescribe a capacity integration formula.

The supplied archive contains only `B6_Discharge0.5C_Charge2C`. The other protocol folders (B1–B5) are **not present and were not inspected**. It is therefore incorrect to describe this work as an audit of the entire LFP archive or of the complete six-condition set.

## Archive inventory and workbook coverage

There are 19 `.xlsx` files. `B6_Discharge0.5C_Charge2C.zip` is 368,836,614 bytes. Workbook-level details are in `LFP_workbook_summary.csv`; every actual worksheet tab and its declared dimensions are in `LFP_file_manifest.csv`.

|workbook|checkpoint|sheets|named_cycle_tabs|cycle_like_tabs|complete_discharge_tabs|generic_cycle_like_tabs|unindexed_tabs|status|
|---|---|---|---|---|---|---|---|---|
|Cycle_0050.xlsx|50|54|51|51|50|0|31|VERIFIED_WITH_CONDITIONS|
|Cycle_0100.xlsx|100|53|50|50|50|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0150.xlsx|150|53|50|50|50|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0200.xlsx|200|53|50|50|50|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0300.xlsx|300|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0400.xlsx|400|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0500.xlsx|500|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0600.xlsx|600|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0700.xlsx|700|106|85|101|100|16|18|VERIFIED_WITH_CONDITIONS|
|Cycle_0800.xlsx|800|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_0900.xlsx|900|103|100|100|99|0|30|VERIFIED_WITH_CONDITIONS|
|Cycle_1000.xlsx|1000|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_1100.xlsx|1100|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_1200.xlsx|1200|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_1300.xlsx|1300|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_1400.xlsx|1400|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_1500.xlsx|1500|103|100|100|99|0|8|VERIFIED_WITH_CONDITIONS|
|Cycle_1600.xlsx|1600|103|100|100|100|0|0|VERIFIED_WITH_CONDITIONS|
|Cycle_1700.xlsx|1700|102|100|100|99|0|0|VERIFIED_WITH_CONDITIONS|

The first workbook contains local sheet labels `Cycle01` through `Cycle51`; several later workbooks contain 50 or 100 local cycle tabs. One notable exception is `Cycle_0700.xlsx`, whose workbook contains fewer local cycle tabs than the neighboring 100-cycle batches. Consequently, the global-cycle mapping is **underdetermined** without original experiment logs or author confirmation. Do not create a global `cycle_id` by adding the filename checkpoint to a worksheet-local index.

## Raw schema and column mapping

The measured MSTAT telemetry sheets consistently expose the exact three-column header triple:

- `T(Seconds)` → `time_sec`, source/verified unit **seconds**; values have a predominantly 1-second sampling interval.
- `E(V)` → `voltage_v`, source/verified unit **V**.
- `I(A/cm2)` → `current_raw_value`, preserving the literal source field. Protocol-compatible measured magnitudes strongly indicate total current A, but the header and zero area metadata conflict. `current_a_assumed` is used only for conditional calculations.

No measured `temperature_c` field was found. Source-described ambient/test temperature 25 °C must not be represented as per-sample measured temperature. No numeric measured discharge capacity field was identified in the telemetry schema. `battery_id` is not invented; the source label `BATTERY 6` is captured with a caveat. `cycle_id` remains blank and the source-local tab number is preserved separately.

## Unit, formula and capacity/SOH decisions

### Current-unit assessment

The current unit is **`VERIFIED_WITH_CONDITIONS`**, not fully verified: the source header says A/cm², but measured positive maxima and negative discharge magnitudes match the workbook's setpoint metadata in amperes. MSTAT cell area is `0`, so conversion between A/cm² and A cannot be defended from the area field. The source settings also change in later checkpoints (roughly 2.4/0.625 A initially and 2.135/0.534 A from the 1300 checkpoint); using the official 1.25 Ah nominal rating, those are not all exactly 2C/0.5C, so the setpoint basis may be changing or refer to a different capacity basis. This is not reconciled by the supplied metadata. Recommended next step is author/instrument-documentation clarification. Until then keep `current_raw_value` plus `current_unit_assessment` and use calculated capacity only for clearly labelled exploratory/conditional analysis.

### Formula definitions

- **F01 — Conditional discharge capacity:** integrate the magnitude of negative current with the trapezoidal rule over adjacent samples where both current endpoints are negative, using actual `Δt` in seconds, then divide by 3600. This assumes the raw signal is total A. Intervals with non-positive `Δt` are not integrated. Gaps are flagged; no voltage/current values are clipped.
- **Conservative completed-discharge screen:** a cycle-like tab is treated as a full discharge-capacity record only if it has at least 1,000 negative-current samples, at least 3,000 s between first and last negative-current samples, and its last negative-current voltage is at or below 2.55 V (near the stated 2.50 V cutoff). These are audit heuristics, not a manufacturer-defined capacity-test criterion; raw observed discharge integrals remain available for tabs that fail.
- **F02 — Nominal-capacity-based SOH:** `conditional discharge capacity Ah / 1.25 Ah × 100`. This is not capacity retention against a measured BOL capacity. No values are clipped to 100%.
- **F03/F04 — First-observed proxy retention/loss:** `Q_checkpoint / Q_first_observed × 100` and `100 - retention`. The first observed capacity is a proxy and is **not** declared validated BOL.
- **F05 — Discharge duration:** last negative-current timestamp minus first negative-current timestamp in that tab.
- **F06 — Descriptive statistics:** actual-sample voltage/current min, max and mean, without outlier deletion.

`LFP_formula_register.csv` contains formula IDs, inputs, units, assumptions, sources, worked examples and statuses. The worked examples below use genuine source observations and the conditional total-current-in-amperes interpretation. No separate scientific paper prescribing a capacity formula was bundled in the archive or verified from the official dataset record; F01 is a standard physical/numerical calculation, not attributed to a paper.

### Worked examples from original observations

Source: `Cycle_0050.xlsx`, worksheet `Run01_Un1Ch1_Step2_Cycle01` (header row 122; raw sample rows 9885–9886).

- **F01, one discharge interval:** at `T=9791 s`, `I=-0.6249329` (source label `I(A/cm2)`); at `T=9792 s`, `I=-0.6249847`; therefore `Δt=1 s` and `Q_interval = ((0.6249329 + 0.6249847)/2) × 1 / 3600 = 0.0001735996667 Ah`, conditional on current being in A.
- **F02, nominal SOH:** the same Cycle01 worksheet has conditional integrated discharge capacity `1.2456613976 Ah`; `1.2456613976 / 1.25 × 100 = 99.65291181%` nominal-capacity-based SOH.
- **F03, first-observed proxy retention:** Cycle02 has conditional capacity `1.2453421964 Ah`; relative to Cycle01's first valid observed capacity, `1.2453421964 / 1.2456613976 × 100 = 99.97437497%`. This is a proxy baseline, not validated BOL retention.
- **F04, proxy capacity loss:** `100 − 99.97437497 = 0.02562503%` relative to that first-observed proxy.
- **F05, discharge duration:** for Cycle01, first negative-current timestamp `2620 s` and last negative-current timestamp `9795 s`; duration is `9795 − 2620 = 7175 s`.
- **F06, descriptive voltage example:** Cycle01 observed voltage minimum `2.498755 V`, maximum `3.650623 V`, and arithmetic mean `3.2867871132 V`. These are observations/statistics, not clipped to protocol bounds.

## Quality-control results

- Across the inspected telemetry: **15,564,387** raw samples.
- Samples outside the strict stated voltage window (below 2.50 V or above 3.65 V): **1,612,885**. Many strict flags are millivolt-scale boundary crossings around CV/cutoff; a separate >20 mV outside-window count within cycle-like tabs is **3**. These are flagged, not removed, and must be interpreted with the protocol and instrument tolerance in mind.
- Duplicate timestamps: **0**; duplicate full numeric rows: **0**; non-monotonic intervals: **0**; intervals longer than 1.5 seconds: **1,680**.
- Worksheet tabs with at least one >1.5-second timestamp gap: **377**; tabs with duplicate timestamps: **0**; tabs with non-monotonic time: **0**.
- No rows were dropped, clipped, or interpolated. All raw readings stay in the original XLSX archive; quality findings are logged in `LFP_cleaning_log.csv` and `LFP_cycle_summary.csv`.
- Sampling cadence is calculated from timestamps in each sheet. The modal/median intervals are recorded in `LFP_cycle_summary.csv`; intervals are not blindly resampled to one second.

## Conditional performance summaries

The `LFP_cycle_summary.csv` table gives one summary per named or generic cycle-like worksheet tab, not one row per verified global lifetime cycle or independent physical cell. It includes capacity under the A assumption, charge integration as a secondary conditional metric, voltage/current statistics, time bounds, sample counts, flags and formula references.

Conditional discharge-capacity summary (only cycle-like tabs passing the conservative completeness screen; do **not** treat as unit-verified until the header ambiguity is resolved):

- Count of screened conditional full-cycle capacity records: 1697
- Minimum: 1.0212367267638893 Ah
- Mean: 1.1077690102427047 Ah
- Maximum: 1.2456613975972095 Ah
- Nominal SOH conditional range: 81.69893814111114% to 99.65291180777676% (mean 88.62152081941639%).

These figures are reproducible calculations from the raw observations under the stated assumption. They are not official measured capacity values and not a validated SOH ground truth. Any apparent values above nominal capacity/100% are preserved and should be investigated rather than clipped.

## Model-readiness recommendation

1. Keep all original workbooks unchanged. Use the provided summary CSV and optionally generate a gzip staging file by running the script with `--write-staging`.
2. Preserve stable source keys: `dataset_id`, `condition_id`, `source_file`, `worksheet`, `cycle_checkpoint_from_filename`, and `source_cycle_tab_label`. Keep `global_cycle_id` null until sequential coverage is validated.
3. Preserve `current_raw_value`, literal source label, and `current_unit_assessment`. Do not merge current with datasets whose current basis is confirmed without a conversion decision.
4. Keep source-provided nominal capacity distinct from a measured BOL capacity. Do not treat source-described 25 °C as measured row-level temperature.
5. For train/test evaluation intended to generalize to unseen cells, split by verified physical cell identity; this B6 archive does not verify enough cross-condition cell identity to support a cell-wise split on its own. Avoid random row-level splits that leak adjacent samples.
6. Do not interpolate missing cycles or resample to a different cadence until the underlying sampling and model target are established. Record any future interpolation explicitly with `is_interpolated=true` and a separate origin label.

## Main handoff / blockers

- **Inspected:** every archive entry; all `19` `.xlsx` workbooks; all `1760` actual workbook tabs parsed from workbook metadata; every worksheet with the target telemetry header was summarized.
- **Not inspected:** all non-B6 folders, because they were not in the supplied ZIP; any unpublished source documents; any separate paper prescribing formulas.
- **Cell identity:** internal label `BATTERY 6` present; physical-cell independence across condition folders not verifiable here.
- **Verified units:** `T(Seconds)` = seconds; `E(V)` = volts. `I(A/cm2)` remains a source-label ambiguity. Source-described nominal capacity is 1.25 Ah; it is not a measured BOL value.
- **Computed:** conditional integrated discharge capacity and nominal-capacity-based SOH only for cycle-like tabs passing the conservative full-discharge screen; observed partial discharge integrals are kept separately. Voltage/current statistics and duration are traceable to source file and worksheet.
- **Blocked/conditional:** current unit reconciliation, validated BOL capacity, validated capacity-retention-to-BOL, measured temperature, global lifetime cycle IDs, and full physical-cell count.
- **CSV handoff:** `LFP_Audit_Report.md`, `LFP_file_manifest.csv`, `LFP_column_mapping.csv`, `LFP_cleaning_log.csv`, `LFP_capacity_soh_feasibility.csv`, `LFP_formula_register.csv`, `LFP_cycle_summary.csv`, and `LFP_workbook_summary.csv`. Script: `LFP_preprocess_audit.py`.

## Reproducibility

Requirements: Python 3.10+ standard library only. Example:

```bash
python LFP_preprocess_audit.py --input B6_Discharge0.5C_Charge2C.zip --output-dir LFP_B6_Audit_Output
```

To also write all raw telemetry rows to gzip CSV (large file):

```bash
python LFP_preprocess_audit.py --input B6_Discharge0.5C_Charge2C.zip --output-dir LFP_B6_Audit_Output --write-staging
```

The script does not modify source workbooks and does not create the final multi-chemistry master table.
