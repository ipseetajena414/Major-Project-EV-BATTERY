LFP B6 audit package
====================

Scope
-----
This package audits only the supplied B6_Discharge0.5C_Charge2C.zip archive (19 XLSX workbooks). It does not contain or claim to audit folders B1-B5. Original workbooks were not modified.

Files
-----
- LFP_Audit_Report.md: findings, limitations, examples, and handoff.
- LFP_file_manifest.csv: archive entries and worksheet inventory.
- LFP_workbook_summary.csv: workbook-level summary.
- LFP_column_mapping.csv: source-to-canonical field map.
- LFP_cleaning_log.csv: worksheet cleaning/quality counts. No observations were dropped or interpolated.
- LFP_capacity_soh_feasibility.csv: capacity/SOH feasibility and blockers per cycle-like worksheet.
- LFP_formula_register.csv: formulae and genuine worked examples.
- LFP_cycle_summary.csv: worksheet-level observed/derived metrics.
- LFP_preprocess_audit.py: reproducible parser and audit script (Python standard library only).
- LFP_audit_run_metadata.json: run counts and high-level results.

Important scientific qualification
----------------------------------
The source header says I(A/cm2), while the observed signal magnitudes match MSTAT current setpoints in amperes. The workbook also reports zero surface area, so the unit label cannot be reconciled from the available metadata. Capacity and nominal-SOH values are therefore conditional exploratory calculations, not verified measured capacity/SOH ground truth. The full-discharge completeness criteria are audit heuristics, not a manufacturer test standard. Do not merge these fields as fully verified without resolving current units and baseline capacity.

Reproduce
---------
Place the original B6_Discharge0.5C_Charge2C.zip beside LFP_preprocess_audit.py, then run:

    python LFP_preprocess_audit.py --input B6_Discharge0.5C_Charge2C.zip --output-dir LFP_B6_Audit_Output

The script reads the raw ZIP/XLSX files and writes separate derived outputs; it does not overwrite the inputs. Use --write-staging only if you intentionally need the optional staging file.
