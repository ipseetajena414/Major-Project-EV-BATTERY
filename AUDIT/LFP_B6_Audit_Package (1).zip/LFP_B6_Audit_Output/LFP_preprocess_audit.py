#!/usr/bin/env python3
"""Reproducible, standard-library-only audit for the supplied B6 LFP archive.

Reads the original ZIP without modifying it. Parses OOXML directly (zipfile + ElementTree)
so no workbook engine is required. Outputs auditable CSVs and Markdown. A large optional
canonical raw staging export can be enabled with --write-staging.

IMPORTANT: I(A/cm2) is retained as the literal source column. Capacity and nominal SOH
are conditional calculations that assume the observed signal is total current in amperes;
that interpretation is strongly consistent with MSTAT protocol setpoints but conflicts
with the original header and cannot be treated as fully documented unit verification.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import math
import os
import re
import statistics
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import PurePosixPath

MAIN = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL_DOC = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG_REL = 'http://schemas.openxmlformats.org/package/2006/relationships'
NS = {'m': MAIN, 'r': REL_DOC}
ROW_TAG = f'{{{MAIN}}}row'
CELL_TAG = f'{{{MAIN}}}c'
TEXT_TAG = f'{{{MAIN}}}t'

SOURCE_URL = 'https://research.birmingham.ac.uk/en/datasets/experimental-dataset-for-cycle-ageing-of-lfp-18650-lithium-ion-ba/'
DOI_URL = 'https://doi.org/10.5281/zenodo.22286449'


def write_csv(path, rows, fieldnames=None):
    rows = list(rows)
    if fieldnames is None:
        fieldnames = []
        for row in rows:
            for key in row.keys():
                if key not in fieldnames:
                    fieldnames.append(key)
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        w.writeheader()
        for row in rows:
            w.writerow({k: clean_cell(row.get(k, '')) for k in fieldnames})


def clean_cell(v):
    if v is None: return ''
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v): return ''
        return repr(v)
    if isinstance(v, (list, tuple, dict, set)):
        return json.dumps(v, ensure_ascii=False, sort_keys=True)
    return v


def col_index(cell_ref):
    letters = ''.join(ch for ch in cell_ref if ch.isalpha())
    n = 0
    for ch in letters.upper(): n = n * 26 + ord(ch) - 64
    return n


def col_letters(cell_ref):
    return ''.join(ch for ch in cell_ref if ch.isalpha()).upper()


def parse_num(v):
    if v is None: return None
    if isinstance(v, (int, float)): return float(v)
    s = str(v).strip()
    if not s: return None
    try:
        n = float(s)
        return n if math.isfinite(n) else None
    except (ValueError, TypeError):
        return None


def read_shared_strings(xlsx):
    try:
        root = ET.fromstring(xlsx.read('xl/sharedStrings.xml'))
    except KeyError:
        return []
    out = []
    for si in root.findall('m:si', NS):
        out.append(''.join(t.text or '' for t in si.findall('.//m:t', NS)))
    return out


def workbook_structure(xlsx):
    wb_root = ET.fromstring(xlsx.read('xl/workbook.xml'))
    rel_root = ET.fromstring(xlsx.read('xl/_rels/workbook.xml.rels'))
    rel_map = {e.attrib['Id']: e.attrib['Target'] for e in rel_root.findall(f'{{{PKG_REL}}}Relationship')}
    sheets = []
    for sh in wb_root.findall('m:sheets/m:sheet', NS):
        rid = sh.attrib.get(f'{{{REL_DOC}}}id')
        target = rel_map.get(rid, '')
        # OOXML relationships may be relative to xl/ or absolute package paths.
        if target.startswith('/'):
            target = target.lstrip('/')
        else:
            target = str(PurePosixPath('xl') / target)
        parts = []
        for part in target.split('/'):
            if part == '..':
                if parts: parts.pop()
            elif part != '.':
                parts.append(part)
        target = '/'.join(parts)
        sheets.append({'name': sh.attrib['name'], 'sheet_id': sh.attrib.get('sheetId', ''), 'target': target})
    return sheets


def read_dimension(xlsx, target):
    try:
        with xlsx.open(target) as f:
            for event, elem in ET.iterparse(f, events=('start',)):
                if elem.tag == f'{{{MAIN}}}dimension':
                    ref = elem.attrib.get('ref', '')
                    m = re.search(r'([A-Z]+)(\d+)$', ref)
                    nrow = int(m.group(2)) if m else ''
                    m2 = re.match(r'([A-Z]+)', (ref.split(':')[-1] if ':' in ref else ref))
                    ncol = col_index(m2.group(1)) if m2 else ''
                    return ref, nrow, ncol
                if elem.tag == ROW_TAG:
                    break
    except Exception:
        pass
    return '', '', ''


def decode_cell(cell, shared):
    typ = cell.attrib.get('t', '')
    v = cell.find(f'{{{MAIN}}}v')
    if typ == 'inlineStr':
        return ''.join(t.text or '' for t in cell.findall('.//m:t', NS))
    if v is None:
        return ''
    raw = v.text or ''
    if typ == 's':
        try: return shared[int(raw)]
        except (ValueError, IndexError): return raw
    if typ == 'b':
        return 'TRUE' if raw == '1' else 'FALSE'
    return raw


def iter_rows(xlsx, target, shared):
    """Yield (row_number, {column_letter: decoded value}) without loading a whole sheet."""
    with xlsx.open(target) as f:
        for event, elem in ET.iterparse(f, events=('end',)):
            if elem.tag == ROW_TAG:
                rownum = int(elem.attrib.get('r', '0') or 0)
                vals = {}
                for cell in list(elem):
                    if cell.tag != CELL_TAG: continue
                    ref = cell.attrib.get('r', '')
                    c = col_letters(ref)
                    vals[c] = decode_cell(cell, shared)
                yield rownum, vals
                elem.clear()


def parse_mstat_metadata(shared):
    info = {}
    patterns = {
        'surface_area_raw': r'Surface Area:\s*([^\r\n]+)',
        'sample_capacity_raw': r'Sample Capacity:\s*([^\r\n]+)',
        'sample_weight_raw': r'Sample Weight:\s*([^\r\n]+)',
        'charge_cc_setpoint_a': r'\bCharge CC:\s*([-+]?\d+(?:\.\d+)?)',
        'discharge_cc_setpoint_a': r'\bDischarge CC:\s*([-+]?\d+(?:\.\d+)?)',
        'charge_cutoff_voltage_v': r'CV:\s*([-+]?\d+(?:\.\d+)?)\s*V',
        'discharge_cutoff_voltage_v': r'Discharge CC:.*?XV:\s*([-+]?\d+(?:\.\d+)?)\s*V',
        'scan_number': r'Scan Number:\s*([-+]?\d+(?:\.\d+)?)',
        'aux_count': r'Aux Count:\s*([-+]?\d+(?:\.\d+)?)',
        'measure_rate_3': r'Measure Rate #3:\s*([-+]?\d+(?:\.\d+)?)',
    }
    alltext = '\n'.join(shared)
    for k, pat in patterns.items():
        vals = re.findall(pat, alltext, flags=re.IGNORECASE | re.DOTALL)
        if vals:
            # Keep unique observed values rather than assuming all cycles agree.
            uniq = list(dict.fromkeys(v.strip() for v in vals))
            info[k] = '|'.join(uniq[:20])
    # First source .mdat identifier encoded as a shared string, if present.
    m = re.search(r'File:\s*([^\r\n]+\.mdat)', alltext, re.IGNORECASE)
    if m: info['source_mdat_path'] = m.group(1).strip()
    info['internal_battery_label'] = 'BATTERY 6' if re.search(r'BATTERY\s*6', alltext, re.I) else ''
    info['source_current_label_present'] = str(any('I(A/cm2)' in x for x in shared)).lower()
    info['source_time_label_present'] = str(any('T(Seconds)' in x for x in shared)).lower()
    info['source_voltage_label_present'] = str(any('E(V)' in x for x in shared)).lower()
    return info


def init_measure_stats():
    return {
        'telemetry_sample_count': 0, 'missing_time_count': 0, 'missing_voltage_count': 0,
        'missing_current_count': 0, 'nonnumeric_rows_after_data_start': 0,
        'duplicate_row_count': 0, 'duplicate_timestamp_count': 0,
        'nonmonotonic_time_intervals': 0, 'timestamp_gap_count_gt_1_5s': 0,
        'out_of_protocol_voltage_count': 0, 'material_voltage_excursion_count_gt_20mv': 0, 'charge_sample_count': 0,
        'discharge_sample_count': 0, 'zero_current_sample_count': 0,
        'phase_transition_count': 0, 'charge_integration_ah_assumed_a': 0.0,
        'discharge_capacity_ah_assumed_a': 0.0,
        'sum_time': 0.0, 'sum_voltage': 0.0, 'sum_current': 0.0,
        'time_min': None, 'time_max': None, 'voltage_min': None, 'voltage_max': None,
        'current_min': None, 'current_max': None, 'discharge_voltage_min': None,
        'discharge_voltage_max': None, 'sum_discharge_voltage': 0.0,
        'sum_discharge_current': 0.0, 'sum_abs_discharge_current': 0.0,
        'discharge_time_min': None, 'discharge_time_max': None, 'discharge_terminal_voltage_v': None,
        'discharge_voltage_sum_count': 0, 'discharge_current_sum_count': 0,
        'dt_values': [], 'data_start_row': None, 'data_end_row': None,
        'first_record': None, 'last_record': None, 'seen_timestamps': set(),
        'seen_records': set(), 'prev_record': None, 'phase_prev': None,
        'source_header_row': None, 'n_numeric_candidate_rows': 0,
        'measurement_rows_xml': 0, 'max_used_row': 0, 'max_used_col': 0,
        'rows_seen_xml': 0,
    }


def parse_sheet(xlsx, target, shared, sheet_name, write_staging_writer=None,
                condition='B6', source_file='', checkpoint='', dimension_info=None):
    if dimension_info is None:
        dimension_info = read_dimension(xlsx, target)
    dim_ref, dim_rows, dim_cols = dimension_info
    s = init_measure_stats()
    s['dimension_ref'] = dim_ref
    s['declared_row_count'] = dim_rows
    s['declared_column_count'] = dim_cols
    header_row = None
    data_started = False
    nonempty_rows = 0
    all_rows_for_filelist = [] if sheet_name == 'File List' else None
    for rnum, vals in iter_rows(xlsx, target, shared):
        s['rows_seen_xml'] += 1
        s['max_used_row'] = max(s['max_used_row'], rnum)
        if vals:
            nonempty_rows += 1
        if vals:
            s['max_used_col'] = max(s['max_used_col'], max(col_index(c) for c in vals))
        if all_rows_for_filelist is not None:
            all_rows_for_filelist.append((rnum, vals.copy()))
        # Locate the source column header exactly as represented in MSTAT export.
        cleanvals = {k: str(v).strip() for k, v in vals.items()}
        if header_row is None and cleanvals.get('A') == 'T(Seconds)' and cleanvals.get('B') == 'E(V)' and cleanvals.get('C') == 'I(A/cm2)':
            header_row = rnum
            s['source_header_row'] = rnum
            continue
        if header_row is None or rnum <= header_row:
            continue
        t = parse_num(vals.get('A'))
        v = parse_num(vals.get('B'))
        i = parse_num(vals.get('C'))
        any_value = any(str(vals.get(k, '')).strip() for k in ('A','B','C'))
        if t is not None and v is not None and i is not None:
            data_started = True
            s['telemetry_sample_count'] += 1
            s['n_numeric_candidate_rows'] += 1
            rec = (t, v, i)
            if s['first_record'] is None:
                s['first_record'] = rec
                s['data_start_row'] = rnum
            s['last_record'] = rec
            s['data_end_row'] = rnum
            if rec in s['seen_records']:
                s['duplicate_row_count'] += 1
            s['seen_records'].add(rec)
            if t in s['seen_timestamps']:
                s['duplicate_timestamp_count'] += 1
            s['seen_timestamps'].add(t)
            s['time_min'] = t if s['time_min'] is None else min(s['time_min'], t)
            s['time_max'] = t if s['time_max'] is None else max(s['time_max'], t)
            s['voltage_min'] = v if s['voltage_min'] is None else min(s['voltage_min'], v)
            s['voltage_max'] = v if s['voltage_max'] is None else max(s['voltage_max'], v)
            s['current_min'] = i if s['current_min'] is None else min(s['current_min'], i)
            s['current_max'] = i if s['current_max'] is None else max(s['current_max'], i)
            s['sum_time'] += t; s['sum_voltage'] += v; s['sum_current'] += i
            if v < 2.50 or v > 3.65:
                s['out_of_protocol_voltage_count'] += 1
            # Separate strict boundary crossings from excursions >20 mV outside the stated protocol.
            if v < 2.48 or v > 3.67:
                s['material_voltage_excursion_count_gt_20mv'] += 1
            phase = 'charge' if i > 0 else ('discharge' if i < 0 else 'zero_current')
            if phase == 'charge':
                s['charge_sample_count'] += 1
            elif phase == 'discharge':
                s['discharge_sample_count'] += 1
                s['discharge_voltage_min'] = v if s['discharge_voltage_min'] is None else min(s['discharge_voltage_min'], v)
                s['discharge_voltage_max'] = v if s['discharge_voltage_max'] is None else max(s['discharge_voltage_max'], v)
                s['sum_discharge_voltage'] += v
                s['sum_discharge_current'] += i
                s['sum_abs_discharge_current'] += abs(i)
                s['discharge_voltage_sum_count'] += 1
                s['discharge_current_sum_count'] += 1
                s['discharge_time_min'] = t if s['discharge_time_min'] is None else min(s['discharge_time_min'], t)
                s['discharge_time_max'] = t if s['discharge_time_max'] is None else max(s['discharge_time_max'], t)
                if s['discharge_time_max'] == t:
                    s['discharge_terminal_voltage_v'] = v
            else:
                s['zero_current_sample_count'] += 1
            if s['phase_prev'] is not None and phase != s['phase_prev']:
                s['phase_transition_count'] += 1
            s['phase_prev'] = phase
            prev = s['prev_record']
            if prev is not None:
                dt = t - prev[0]
                if dt <= 0:
                    s['nonmonotonic_time_intervals'] += 1
                else:
                    s['dt_values'].append(dt)
                    if dt > 1.5:
                        s['timestamp_gap_count_gt_1_5s'] += 1
                    # Trapezoidal integration only where both endpoint samples share the phase sign.
                    if prev[2] < 0 and i < 0:
                        s['discharge_capacity_ah_assumed_a'] += ((abs(prev[2]) + abs(i)) / 2.0) * dt / 3600.0
                    if prev[2] > 0 and i > 0:
                        s['charge_integration_ah_assumed_a'] += ((prev[2] + i) / 2.0) * dt / 3600.0
            s['prev_record'] = rec
            if write_staging_writer is not None:
                write_staging_writer.writerow({
                    'dataset_id': '10.5281/zenodo.22286449', 'condition_id': condition,
                    'source_file': source_file, 'worksheet': sheet_name,
                    'cycle_checkpoint': checkpoint, 'source_cycle_tab_number': cycle_tab_number(sheet_name),
                    'time_sec': t, 'voltage_v': v, 'current_raw_value': i,
                    'current_raw_source_label': 'I(A/cm2)',
                    'current_a_assumed': i, 'charge_discharge_phase': phase,
                    'value_origin': 'measured_raw_sample', 'is_interpolated': False,
                    'quality_flag': 'suspect_unit' if True else 'ok',
                })
        elif data_started and any_value:
            s['nonnumeric_rows_after_data_start'] += 1
            if not str(vals.get('A','')).strip(): s['missing_time_count'] += 1
            if not str(vals.get('B','')).strip(): s['missing_voltage_count'] += 1
            if not str(vals.get('C','')).strip(): s['missing_current_count'] += 1
    s['measurement_rows_xml'] = s['rows_seen_xml']
    s['nonempty_row_count'] = nonempty_rows
    s['header_found'] = header_row is not None
    s['file_list_rows'] = all_rows_for_filelist
    s['discharge_duration_sec'] = (s['discharge_time_max'] - s['discharge_time_min']) if s['discharge_time_min'] is not None and s['discharge_time_max'] is not None else None
    # Conservative completeness screen: substantial discharge duration and near the stated 2.50 V cutoff.
    # This is a screening heuristic, not source-defined test metadata. Partial integrals remain available separately.
    s['complete_discharge_screen'] = bool(
        s['discharge_sample_count'] >= 1000 and s['discharge_duration_sec'] is not None
        and s['discharge_duration_sec'] >= 3000 and s['discharge_terminal_voltage_v'] is not None
        and s['discharge_terminal_voltage_v'] <= 2.55
    )
    if not s['discharge_sample_count']:
        s['complete_discharge_screen_reason'] = 'no_negative_current_samples'
    elif s['discharge_duration_sec'] is None or s['discharge_duration_sec'] < 3000 or s['discharge_sample_count'] < 1000:
        s['complete_discharge_screen_reason'] = 'short_or_incomplete_discharge_segment'
    elif s['discharge_terminal_voltage_v'] is None or s['discharge_terminal_voltage_v'] > 2.55:
        s['complete_discharge_screen_reason'] = 'terminal_voltage_does_not_approach_2_50V_cutoff'
    else:
        s['complete_discharge_screen_reason'] = 'passes_conservative_discharge_completeness_screen'
    if s['telemetry_sample_count']:
        s['mean_voltage_v'] = s['sum_voltage'] / s['telemetry_sample_count']
        s['mean_current_raw_value'] = s['sum_current'] / s['telemetry_sample_count']
        s['mean_discharge_voltage_v'] = (s['sum_discharge_voltage'] / s['discharge_voltage_sum_count']) if s['discharge_voltage_sum_count'] else None
        s['mean_discharge_current_raw_value'] = (s['sum_discharge_current'] / s['discharge_current_sum_count']) if s['discharge_current_sum_count'] else None
        s['mean_abs_discharge_current_raw_value'] = (s['sum_abs_discharge_current'] / s['discharge_current_sum_count']) if s['discharge_current_sum_count'] else None
        s['mean_dt_s'] = statistics.mean(s['dt_values']) if s['dt_values'] else None
        s['median_dt_s'] = statistics.median(s['dt_values']) if s['dt_values'] else None
        s['min_dt_s'] = min(s['dt_values']) if s['dt_values'] else None
        s['max_dt_s'] = max(s['dt_values']) if s['dt_values'] else None
    else:
        s.update({'mean_voltage_v':None, 'mean_current_raw_value':None, 'mean_discharge_voltage_v':None,
                  'mean_discharge_current_raw_value':None, 'mean_abs_discharge_current_raw_value':None,
                  'mean_dt_s':None,'median_dt_s':None,'min_dt_s':None,'max_dt_s':None})
    # Release large per-sheet lookup structures before the next sheet is parsed.
    s['dt_values'] = []
    s['seen_timestamps'] = set()
    s['seen_records'] = set()
    s['prev_record'] = None
    s['phase_prev'] = None
    return s


def cycle_tab_number(name):
    m = re.search(r'_Cycle(\d+)$', name, re.IGNORECASE)
    return int(m.group(1)) if m else ''


def cycle_tab_number_str(name):
    m = re.search(r'_Cycle(\d+)$', name, re.IGNORECASE)
    return m.group(1) if m else ''


def is_named_cycle_tab(name):
    return bool(re.search(r'_Step\d+_Cycle\d+$', name, re.IGNORECASE))


def is_cycle_like_sheet(name, st):
    if is_named_cycle_tab(name):
        return True
    # Cycle_0700 contains several raw cycle-like data tabs whose labels were exported as SheetN.
    return bool(re.fullmatch(r'Sheet\d+', name, re.IGNORECASE) and st.get('telemetry_sample_count', 0) > 1000 and st.get('discharge_sample_count', 0) > 0)


def file_checkpoint(name):
    m = re.search(r'Cycle_(\d+)', name, re.IGNORECASE)
    return int(m.group(1)) if m else ''


def excel_serial_to_iso(v):
    n = parse_num(v)
    if n is None: return ''
    try:
        import datetime
        return (datetime.datetime(1899, 12, 30) + datetime.timedelta(days=n)).isoformat(sep=' ', timespec='seconds')
    except Exception:
        return ''


def source_from_file_list(rows):
    source_file = ''
    listed_names = []
    mdat_path = ''
    for rnum, vals in rows or []:
        if rnum == 1:
            source_file = str(vals.get('B','')).strip()
            m = re.search(r'([^\\/]+\.mdat)', source_file, re.I)
            mdat_path = m.group(1) if m else source_file
        elif rnum >= 4 and str(vals.get('A','')).strip():
            listed_names.append(str(vals.get('A','')).strip())
    return source_file, mdat_path, listed_names


def current_unit_assessment(stats, meta):
    expected_charge = parse_num((meta.get('charge_cc_setpoint_a','').split('|') or [''])[0])
    expected_discharge = parse_num((meta.get('discharge_cc_setpoint_a','').split('|') or [''])[0])
    pos_match = stats['current_max'] is not None and expected_charge is not None and abs(stats['current_max'] - expected_charge) <= max(0.25, abs(expected_charge)*0.10)
    neg_match = stats['mean_abs_discharge_current_raw_value'] is not None and expected_discharge is not None and abs(stats['mean_abs_discharge_current_raw_value'] - expected_discharge) <= max(0.10, abs(expected_discharge)*0.15)
    if pos_match and neg_match:
        return 'VERIFIED_WITH_CONDITIONS', 'The maximum positive signal and mean discharge magnitude align with MSTAT protocol setpoints in A; source header explicitly says A/cm2 and area metadata is zero, so total-current interpretation is strongly indicated but not formally reconciled.'
    if stats['telemetry_sample_count'] and (pos_match or neg_match):
        return 'UNDERDETERMINED', 'Only part of the raw signal matches protocol setpoints; the source label is I(A/cm2) and no defensible active area is recorded.'
    return 'UNDERDETERMINED', 'The raw signal could not be reconciled to both protocol setpoints; retain the original unit label and do not treat it as verified total current.'


def status_from_stats(st, meta):
    if not st['telemetry_sample_count']:
        return 'NOT_INSPECTED' if not st['header_found'] else 'UNSUPPORTED'
    unit_status, _ = current_unit_assessment(st, meta)
    if unit_status != 'VERIFIED_WITH_CONDITIONS': return 'UNDERDETERMINED'
    return 'VERIFIED_WITH_CONDITIONS'


def md_table(rows, columns):
    def esc(x): return str(x if x is not None else '').replace('|','\\|').replace('\n',' ')
    lines = ['|'+'|'.join(columns)+'|','|'+'|'.join(['---']*len(columns))+'|']
    for r in rows:
        lines.append('|'+'|'.join(esc(r.get(c,'')) for c in columns)+'|')
    return '\n'.join(lines)


def audit(input_zip, output_dir, write_staging=False):
    os.makedirs(output_dir, exist_ok=True)
    staging_f = None
    staging_writer = None
    if write_staging:
        import gzip
        staging_f = gzip.open(os.path.join(output_dir, 'LFP_cleaned_staging.csv.gz'), 'wt', newline='', encoding='utf-8')
        staging_writer = csv.DictWriter(staging_f, fieldnames=[
            'dataset_id','condition_id','source_file','worksheet','cycle_checkpoint','source_cycle_tab_number',
            'time_sec','voltage_v','current_raw_value','current_raw_source_label','current_a_assumed',
            'charge_discharge_phase','value_origin','is_interpolated','quality_flag'])
        staging_writer.writeheader()

    with zipfile.ZipFile(input_zip) as archive:
        # Each archive.read() below verifies the CRC of the individual input entry.
        infos = archive.infolist()
        xlsx_infos = [i for i in infos if i.filename.lower().endswith('.xlsx') and not i.is_dir()]
        condition_dirs = sorted({str(PurePosixPath(i.filename).parent) for i in xlsx_infos})
        all_sheet_inventory = []
        cleaning = []
        mappings = []
        cycles = []
        feasibility = []
        workbook_rows = []
        archive_rows = []
        hash_seen = defaultdict(list)
        data_sheets_by_workbook = {}
        raw_current_all = []
        raw_voltage_all = []
        current_positive_count = current_negative_count = current_zero_count = 0
        total_telemetry_samples = 0
        total_voltage_flag = total_gaps = total_duplicate_ts = total_nonmonotonic = total_duplicate_rows = 0
        total_sheet_count = 0

        # Full archive-level entries (folder + every file actually inside the supplied ZIP).
        for zi in infos:
            if zi.is_dir():
                kind = 'directory'
            else:
                kind = 'workbook' if zi.filename.lower().endswith('.xlsx') else 'other_file'
            archive_rows.append({
                'record_type':'archive_entry','archive_path':zi.filename,'entry_type':kind,
                'extension': '' if zi.is_dir() else PurePosixPath(zi.filename).suffix.lower(),
                'compressed_size_bytes':zi.compress_size,'uncompressed_size_bytes':zi.file_size,
                'condition_folder':str(PurePosixPath(zi.filename).parent) if not zi.is_dir() else zi.filename.rstrip('/'),
                'source_file':PurePosixPath(zi.filename).name,'worksheet':'','checkpoint_from_filename':file_checkpoint(PurePosixPath(zi.filename).name),
                'worksheet_dimension':'','row_count':'','column_count':'','inspection_status':'VERIFIED' if kind in ('directory','workbook') else 'NOT_INSPECTED',
                'notes':'Entry in user-supplied ZIP; no file contents changed.'
            })

        for wnum, zi in enumerate(xlsx_infos, start=1):
            print(f'Processing workbook {wnum}/{len(xlsx_infos)}: {PurePosixPath(zi.filename).name}', flush=True)
            try:
                book_bytes = archive.read(zi.filename)
                digest = hashlib.sha256(book_bytes).hexdigest()
                hash_seen[digest].append(zi.filename)
                with zipfile.ZipFile(io.BytesIO(book_bytes)) as xlsx:
                    shared = read_shared_strings(xlsx)
                    sheets = workbook_structure(xlsx)
                    meta = parse_mstat_metadata(shared)
                    cp = file_checkpoint(PurePosixPath(zi.filename).name)
                    condition_folder = str(PurePosixPath(zi.filename).parent)
                    cycle_tabs = [s for s in sheets if is_named_cycle_tab(s['name'])]
                    # Process sheets in actual workbook tab order; preserve every sheet regardless of data quality.
                    file_list_rows = None
                    sheet_stats = {}
                    workbook_local_sheetrows = []
                    for sh in sheets:
                        dim_ref, dim_rows, dim_cols = read_dimension(xlsx, sh['target'])
                        st = parse_sheet(xlsx, sh['target'], shared, sh['name'], staging_writer,
                                         condition='B6', source_file=PurePosixPath(zi.filename).name,
                                         checkpoint=cp, dimension_info=(dim_ref, dim_rows, dim_cols))
                        if sh['name'] == 'File List':
                            file_list_rows = st.get('file_list_rows')
                        sheet_stats[sh['name']] = st
                        workbook_local_sheetrows.append((sh, st))
                        total_sheet_count += 1
                        sample_n = st['telemetry_sample_count']
                        total_telemetry_samples += sample_n
                        total_voltage_flag += st['out_of_protocol_voltage_count']
                        total_gaps += st['timestamp_gap_count_gt_1_5s']
                        total_duplicate_ts += st['duplicate_timestamp_count']
                        total_nonmonotonic += st['nonmonotonic_time_intervals']
                        total_duplicate_rows += st['duplicate_row_count']
                        current_positive_count += st['charge_sample_count']
                        current_negative_count += st['discharge_sample_count']
                        current_zero_count += st['zero_current_sample_count']
                        if sample_n:
                            raw_current_all.extend([st['current_min'], st['current_max']])
                            raw_voltage_all.extend([st['voltage_min'], st['voltage_max']])
                    cycle_like_sheets = [(sh, st) for sh, st in workbook_local_sheetrows if is_cycle_like_sheet(sh['name'], st)]
                    complete_discharge_count = sum(1 for sh, st in cycle_like_sheets if st.get('complete_discharge_screen'))
                    generic_cycle_like_count = sum(1 for sh, st in cycle_like_sheets if not is_named_cycle_tab(sh['name']))
                    src_path, mdat_name, listed_names = source_from_file_list(file_list_rows)
                    actual_tabs_except_list = [s['name'] for s in sheets if s['name'] != 'File List']
                    listed_set = set(listed_names)
                    unlisted_tabs = [n for n in actual_tabs_except_list if n not in listed_set]
                    list_mismatch = len(unlisted_tabs)
                    total_expected_sheets = len(sheets)
                    workbook_rows.append({
                        'archive_path':zi.filename, 'source_file':PurePosixPath(zi.filename).name,
                        'condition_folder':condition_folder, 'condition_id':'B6', 'checkpoint_from_filename':cp,
                        'internal_source_mdat_path':src_path, 'internal_mdat_basename':mdat_name,
                        'xlsx_size_bytes':zi.file_size,'sha256':digest,
                        'sheet_count':len(sheets),'cycle_tab_count':len(cycle_tabs),
                        'cycle_like_telemetry_tab_count':len(cycle_like_sheets),
                        'complete_discharge_screen_pass_count':complete_discharge_count,
                        'generic_cycle_like_tab_count':generic_cycle_like_count,
                        'file_list_indexed_sheet_count':len(listed_names), 'unindexed_actual_sheet_count':list_mismatch,
                        'file_list_index_consistency':'VERIFIED' if list_mismatch == 0 else 'UNDERDETERMINED',
                        'mstat_surface_area_raw':meta.get('surface_area_raw',''),
                        'mstat_sample_capacity_raw':meta.get('sample_capacity_raw',''),
                        'mstat_charge_cc_setpoint_a':meta.get('charge_cc_setpoint_a',''),
                        'mstat_discharge_cc_setpoint_a':meta.get('discharge_cc_setpoint_a',''),
                        'mstat_scan_number':meta.get('scan_number',''),
                        'mstat_aux_count':meta.get('aux_count',''),
                        'observed_channel_labels':'|'.join(sorted({m.group(0) for ss in sheets for m in [re.search(r'Un1Ch\d+', ss['name'], re.I)] if m})),
                        'internal_battery_label':meta.get('internal_battery_label',''),
                        'inspection_status':'VERIFIED_WITH_CONDITIONS',
                        'notes':('File List tab indexes only a subset of actual worksheet tabs; worksheet names parsed from workbook.xml are authoritative for inventory. ' if list_mismatch else '') +
                                ('Current unit label conflicts with protocol-consistent magnitudes; see unit assessment. ' if True else '') +
                                'Checkpoint value is taken from filename, not treated as a cycle ID for each local worksheet.'
                    })

                    # Cross-sheet sequence continuity for the raw time series; a reset across workbook chunks is expected.
                    previous_workbook_last_t = None
                    previous_data_sheet = ''
                    for sh, st in workbook_local_sheetrows:
                        dim_ref = st.get('dimension_ref','')
                        row = {
                            'record_type':'worksheet','archive_path':zi.filename,'entry_type':'worksheet',
                            'extension':'.xml (inside .xlsx)','compressed_size_bytes':'',
                            'uncompressed_size_bytes':(xlsx.getinfo(sh['target']).file_size if sh['target'] in xlsx.namelist() else ''),
                            'condition_folder':condition_folder,'source_file':PurePosixPath(zi.filename).name,
                            'worksheet':sh['name'],'checkpoint_from_filename':cp,'worksheet_dimension':dim_ref,
                            'row_count':st.get('declared_row_count',''),'column_count':st.get('declared_column_count',''),
                            'xml_rows_observed':st.get('rows_seen_xml',''),'telemetry_sample_rows':st.get('telemetry_sample_count',0),
                            'inspection_status':'VERIFIED' if st.get('rows_seen_xml',0) > 0 else 'UNSUPPORTED',
                            'notes':('Telemetry sheet identified by exact source headers.' if st.get('header_found') else 'No telemetry header triple found; non-telemetry metadata/index sheet or atypical layout.')
                        }
                        all_sheet_inventory.append(row)

                        # Data quality/cleaning log per worksheet. Nothing is deleted/interpolated.
                        clean_flags = []
                        if not st.get('header_found'): clean_flags.append('non_telemetry_sheet')
                        if st.get('out_of_protocol_voltage_count',0): clean_flags.append('out_of_protocol_voltage')
                        if st.get('duplicate_timestamp_count',0): clean_flags.append('duplicate_timestamp')
                        if st.get('duplicate_row_count',0): clean_flags.append('duplicate_row')
                        if st.get('nonmonotonic_time_intervals',0): clean_flags.append('non_monotonic_time')
                        if st.get('timestamp_gap_count_gt_1_5s',0): clean_flags.append('time_gap')
                        if st.get('header_found') and (st.get('missing_time_count',0)+st.get('missing_voltage_count',0)+st.get('missing_current_count',0)):
                            clean_flags.append('missing_required_input')
                        if st.get('header_found'): clean_flags.append('suspect_unit')
                        if st.get('header_found') and st.get('telemetry_sample_count',0): clean_flags.append('no_rows_dropped')
                        cleaning.append({
                            'condition_folder':condition_folder,'condition_id':'B6','source_file':PurePosixPath(zi.filename).name,
                            'checkpoint_from_filename':cp,'worksheet':sh['name'],'worksheet_dimension':dim_ref,
                            'source_xml_row_count':st.get('rows_seen_xml',0),'declared_row_count':st.get('declared_row_count',''),
                            'telemetry_input_rows':st.get('telemetry_sample_count',0),
                            'retained_telemetry_rows':st.get('telemetry_sample_count',0),'dropped_rows':0,'drop_reasons':'',
                            'missing_time_count_after_data_start':st.get('missing_time_count',0),
                            'missing_voltage_count_after_data_start':st.get('missing_voltage_count',0),
                            'missing_current_count_after_data_start':st.get('missing_current_count',0),
                            'duplicate_row_count':st.get('duplicate_row_count',0),
                            'duplicate_timestamp_count':st.get('duplicate_timestamp_count',0),
                            'nonmonotonic_time_intervals':st.get('nonmonotonic_time_intervals',0),
                            'timestamp_gaps_gt_1_5s':st.get('timestamp_gap_count_gt_1_5s',0),
                            'out_of_protocol_voltage_observations':st.get('out_of_protocol_voltage_count',0),
                            'material_voltage_excursions_gt_20mv':st.get('material_voltage_excursion_count_gt_20mv',0),
                            'nonnumeric_rows_after_data_start':st.get('nonnumeric_rows_after_data_start',0),
                            'interpolated_observations':0,'transformations_applied':'Read-only XML parse; decoded source values for analysis; no clipping, interpolation, or deletion; original workbook retained.',
                            'quality_flags':';'.join(clean_flags) if clean_flags else 'ok',
                            'inspection_status':'VERIFIED' if st.get('rows_seen_xml',0)>0 else 'UNSUPPORTED'
                        })

                        # Source-to-canonical mapping for each actual telemetry sheet.
                        if st.get('header_found'):
                            for src, canon, meaning, src_unit, verified_unit, dtype, grain, trans, evid, status, notes in [
                                ('T(Seconds)','time_sec','Elapsed time at raw sample','seconds','seconds','float','raw time-series sample','identity conversion; retain original source field','Exact MSTAT column header; values are monotonic and predominantly 1 s apart.','VERIFIED_WITH_CONDITIONS','Time can be continuous within a workbook; each MSTAT export is a separate source file.'),
                                ('E(V)','voltage_v','Measured cell potential','V','V','float','raw time-series sample','identity conversion; retain original source field','Exact MSTAT column header and observed voltage magnitude in stated 2.50–3.65 V protocol range aside from flagged cutoff excursions.','VERIFIED_WITH_CONDITIONS','Out-of-protocol observations are flagged, never clipped.'),
                                ('I(A/cm2)','current_raw_value','Source current signal; physical interpretation unresolved by header alone','A/cm² (literal source label)','A likely; not fully verified','float','raw time-series sample','preserve raw numeric value; conditional alias current_a_assumed for explicitly conditional calculations','Recorded values align with setpoint metadata (positive max near 2.4; negative discharge magnitude near 0.625) while surface area is recorded as 0.','VERIFIED_WITH_CONDITIONS','Do not relabel the source field without retaining this uncertainty; capacity and nominal SOH are conditional on assuming total A.')
                            ]:
                                mappings.append({
                                    'condition_folder':condition_folder,'source_file':PurePosixPath(zi.filename).name,'worksheet':sh['name'],
                                    'source_column':src,'canonical_column':canon,'meaning':meaning,'source_unit':src_unit,
                                    'verified_unit':verified_unit,'data_type':dtype,'data_grain':grain,'transformation':trans,
                                    'evidence':evid,'status':status,'notes':notes
                                })

                        # Add a per-cycle/protocol-tab summary for sheets with telemetry.
                        if st.get('header_found') and st.get('telemetry_sample_count',0) and is_cycle_like_sheet(sh['name'], st):
                            unit_status, unit_note = current_unit_assessment(st, meta)
                            discharge_duration = st.get('discharge_duration_sec')
                            first = st.get('first_record'); last = st.get('last_record')
                            named_cycle = is_named_cycle_tab(sh['name'])
                            complete_discharge = bool(st.get('complete_discharge_screen'))
                            observed_discharge_integral = st['discharge_capacity_ah_assumed_a'] if st['discharge_sample_count'] else None
                            valid_capacity = observed_discharge_integral if complete_discharge else None
                            mean_dt = st.get('median_dt_s')
                            local_cycle_no = cycle_tab_number(sh['name'])
                            # Workbook-local time continuity; cross-workbook resets are not compared.
                            sequence_flag = ''
                            if first and previous_workbook_last_t is not None:
                                d_cross = first[0] - previous_workbook_last_t
                                if d_cross <= 0: sequence_flag = 'cross_sheet_timestamp_overlap_or_reset'
                                elif d_cross > 1.5: sequence_flag = 'cross_sheet_time_gap'
                            if last:
                                previous_workbook_last_t = last[0]
                                previous_data_sheet = sh['name']
                            flags=[]
                            if st['out_of_protocol_voltage_count']: flags.append('out_of_protocol_voltage_strict_bound')
                            if st['material_voltage_excursion_count_gt_20mv']: flags.append('material_voltage_excursion_gt_20mv')
                            if st['duplicate_timestamp_count']: flags.append('duplicate_timestamp')
                            if st['nonmonotonic_time_intervals']: flags.append('non_monotonic_time')
                            if st['timestamp_gap_count_gt_1_5s']: flags.append('time_gap')
                            if unit_status != 'VERIFIED_WITH_CONDITIONS': flags.append('suspect_unit')
                            if sequence_flag: flags.append(sequence_flag)
                            row = {
                                'dataset_id':'10.5281/zenodo.22286449','condition_id':'B6','condition_folder':condition_folder,
                                'source_file':PurePosixPath(zi.filename).name,'cycle_checkpoint_from_filename':cp,
                                'worksheet':sh['name'],'worksheet_cycle_type':'named_cycle_tab' if named_cycle else 'generic_cycle_like_tab',
                                'source_cycle_tab_label':cycle_tab_number_str(sh['name']) if named_cycle else sh['name'],
                                'source_cycle_tab_number':local_cycle_no if named_cycle else '', 'global_cycle_id':'',
                                'battery_id':meta.get('internal_battery_label','') or '',
                                'battery_id_status':'VERIFIED_WITH_CONDITIONS' if meta.get('internal_battery_label') else 'UNDERDETERMINED',
                                'physical_cell_count_verified':'NO','data_grain':'raw measured time-series samples within one MSTAT cycle tab',
                                'sample_count':st['telemetry_sample_count'],'source_header_row':st['source_header_row'],
                                'time_start_sec':st['time_min'],'time_end_sec':st['time_max'],
                                'elapsed_span_sec':(st['time_max']-st['time_min']) if st['time_min'] is not None and st['time_max'] is not None else None,
                                'median_sampling_interval_sec':st['median_dt_s'],'min_sampling_interval_sec':st['min_dt_s'],'max_sampling_interval_sec':st['max_dt_s'],
                                'time_gap_count_gt_1_5s':st['timestamp_gap_count_gt_1_5s'],'duplicate_timestamp_count':st['duplicate_timestamp_count'],
                                'nonmonotonic_time_intervals':st['nonmonotonic_time_intervals'],'duplicate_row_count':st['duplicate_row_count'],
                                'voltage_min_v':st['voltage_min'],'voltage_max_v':st['voltage_max'],'voltage_mean_v':st['mean_voltage_v'],
                                'discharge_voltage_min_v':st['discharge_voltage_min'],'discharge_voltage_max_v':st['discharge_voltage_max'],
                                'discharge_voltage_mean_v':st['mean_discharge_voltage_v'],
                                'current_source_label':'I(A/cm2)','current_unit_assessment':unit_status,'current_unit_assessment_note':unit_note,
                                'current_raw_min':st['current_min'],'current_raw_max':st['current_max'],'current_raw_mean':st['mean_current_raw_value'],
                                'discharge_current_raw_mean':st['mean_discharge_current_raw_value'],
                                'charge_sample_count':st['charge_sample_count'],'discharge_sample_count':st['discharge_sample_count'],
                                'zero_current_sample_count':st['zero_current_sample_count'],'phase_transition_count':st['phase_transition_count'],
                                'discharge_start_time_sec':st['discharge_time_min'],'discharge_end_time_sec':st['discharge_time_max'],
                                'discharge_duration_sec':discharge_duration,'discharge_terminal_voltage_v':st['discharge_terminal_voltage_v'],
                                'complete_discharge_screen':complete_discharge,'complete_discharge_screen_reason':st.get('complete_discharge_screen_reason',''),
                                'discharge_charge_integral_ah_observed_conditional':observed_discharge_integral,
                                'discharge_capacity_ah_conditional':valid_capacity,
                                'charge_capacity_ah_conditional':st['charge_integration_ah_assumed_a'] if st['charge_sample_count'] else None,
                                'nominal_capacity_ah_source_metadata':1.25,
                                'soh_nominal_pct_conditional':(valid_capacity/1.25*100) if valid_capacity is not None else None,
                                'bol_reference_capacity_ah':'','capacity_retention_pct_validated_bol':'',
                                'capacity_retention_pct_first_observed_proxy':'','capacity_loss_pct_first_observed_proxy':'',
                                'out_of_protocol_voltage_count':st['out_of_protocol_voltage_count'],
                                'material_voltage_excursions_gt_20mv':st['material_voltage_excursion_count_gt_20mv'],
                                'quality_flag':';'.join((flags + (['incomplete_discharge_or_not_verified'] if not complete_discharge else []) + ([] if named_cycle else ['unresolved_sheet_name'])) or ['ok']),'calculation_status':'VERIFIED_WITH_CONDITIONS' if unit_status=='VERIFIED_WITH_CONDITIONS' and complete_discharge else 'UNDERDETERMINED',
                                'value_origin':'calculated_from_measurements (capacity); source-provided metadata (nominal capacity); unknown/unverified (BOL reference)',
                                'formula_id':'F01;F02','notes':'Capacity uses trapezoidal integration on intervals where both endpoint currents are negative, assuming raw I is total current in A. SOH is nominal-capacity-based only; not a validated retention-to-BOL metric.'
                            }
                            cycles.append(row)
                            feasibility.append({
                                'condition_id':'B6','condition_folder':condition_folder,'source_file':PurePosixPath(zi.filename).name,
                                'cycle_checkpoint_from_filename':cp,'worksheet':sh['name'],'source_cycle_tab_label':cycle_tab_number_str(sh['name']),
                                'battery_id_source_label':meta.get('internal_battery_label',''),
                                'physical_cell_identity_status':'VERIFIED_WITH_CONDITIONS' if meta.get('internal_battery_label') else 'UNDERDETERMINED',
                                'telemetry_sample_count':st['telemetry_sample_count'],'current_source_unit':'I(A/cm2)',
                                'current_interpretation':'probable total A from setpoint match; source label conflict and MSTAT area=0',
                                'capacity_calculation_status':'VERIFIED_WITH_CONDITIONS' if unit_status=='VERIFIED_WITH_CONDITIONS' and complete_discharge else 'UNDERDETERMINED',
                                'complete_discharge_screen':complete_discharge,'complete_discharge_screen_reason':st.get('complete_discharge_screen_reason',''),
                                'discharge_terminal_voltage_v':st.get('discharge_terminal_voltage_v',''),
                                'observed_discharge_integral_ah_conditional':observed_discharge_integral if observed_discharge_integral is not None else '',
                                'measured_discharge_capacity_ah_conditional':valid_capacity if valid_capacity is not None else '',
                                'soh_nominal_pct_conditional':(valid_capacity/1.25*100) if valid_capacity is not None else '',
                                'validated_bol_reference_capacity_ah':'','capacity_retention_vs_validated_bol_pct':'','capacity_retention_vs_first_observed_proxy_pct':'',
                                'capacity_loss_vs_first_observed_proxy_pct':'','temperature_c_measured':'',
                                'missing_inputs_or_limitations':'Current column label conflicts with apparent total-A values; no measured temperature column; physical-cell uniqueness not independently verified; validated BOL capacity not identified; local tab label not established as a global lifetime cycle ID.',
                                'recommended_use':'Use screened complete-cycle capacity and nominal SOH for sensitivity/EDA only; partial discharge integral is not full capacity; retain raw source label and unit-warning flag.'
                            })

                    # Metadata mappings from File List columns, which are source metadata not telemetry.
                    filelist_headers = None
                    if file_list_rows:
                        for rnum, vals in file_list_rows:
                            if rnum == 3:
                                filelist_headers = [(col, str(vals.get(col,'')).strip()) for col in ['A','B','C','D','E','F','G','H','I'] if str(vals.get(col,'')).strip()]
                                break
                    fmap = {
                        'Name':('source_worksheet_name','MSTAT workbook worksheet label','text','worksheet index','identity','Source File List worksheet; may be incomplete relative to actual workbook tabs.','VERIFIED_WITH_CONDITIONS'),
                        'Run':('run_id','Run identifier','integer/string','experiment/run metadata','identity','Source File List worksheet.','VERIFIED'),
                        'Channel':('channel_id','MSTAT channel label','text','experiment/run metadata','identity','Source File List worksheet; observed label changes from Un1Ch1 to Un1Ch6 in later batches.','VERIFIED_WITH_CONDITIONS'),
                        'Step':('step_id','MSTAT step label','text','experiment/run metadata','identity','Source File List worksheet.','VERIFIED'),
                        'Repeat':('repeat_number','MSTAT repeat number','integer/string','experiment/run metadata','identity','Source File List worksheet; blank for many tabs.','VERIFIED_WITH_CONDITIONS'),
                        'Set':('set_number','MSTAT set number','integer/string','experiment/run metadata','identity','Source File List worksheet; blank for many tabs.','VERIFIED_WITH_CONDITIONS'),
                        'Time':('source_timestamp_excel_serial','MSTAT worksheet timestamp','Excel serial datetime','experiment/run metadata','convert serial date only for date-oriented reporting','Source File List worksheet.','VERIFIED_WITH_CONDITIONS'),
                        'Exp Type':('experiment_type','MSTAT experiment type','text','experiment/run metadata','identity','Source File List worksheet.','VERIFIED'),
                        'Exp Title':('experiment_title_config','MSTAT experiment title/configuration','text','experiment/run metadata','identity','Contains setpoint configuration in text.','VERIFIED_WITH_CONDITIONS')
                    }
                    for col, hdr in filelist_headers or []:
                        canonical, meaning, unit, grain, trans, evidence, status = fmap.get(hdr, (f'file_list_{col.lower()}','Source metadata field','unknown','experiment/run metadata','retain source value','Source File List worksheet.','UNDERDETERMINED'))
                        mappings.append({'condition_folder':condition_folder,'source_file':PurePosixPath(zi.filename).name,'worksheet':'File List',
                                         'source_column':hdr,'canonical_column':canonical,'meaning':meaning,'source_unit':unit,
                                         'verified_unit':unit,'data_type':'text or source-native','data_grain':grain,'transformation':trans,
                                         'evidence':evidence,'status':status,'notes':'Preserve source value and worksheet label; source File List tab may be incomplete.'})

            except Exception as e:
                workbook_rows.append({'archive_path':zi.filename,'source_file':PurePosixPath(zi.filename).name,
                                       'condition_folder':str(PurePosixPath(zi.filename).parent),'condition_id':'B6',
                                       'checkpoint_from_filename':file_checkpoint(PurePosixPath(zi.filename).name),
                                       'xlsx_size_bytes':zi.file_size,'inspection_status':'UNSUPPORTED','notes':f'Workbook inspection error: {type(e).__name__}: {e}'})
                all_sheet_inventory.append({'record_type':'workbook_error','archive_path':zi.filename,'source_file':PurePosixPath(zi.filename).name,
                                            'condition_folder':str(PurePosixPath(zi.filename).parent),'inspection_status':'UNSUPPORTED',
                                            'notes':f'Workbook inspection error: {type(e).__name__}: {e}'})

    if staging_f is not None:
        staging_f.close()

    # A retention proxy based on the earliest observed sample cycle is explicitly not a validated BOL reference.
    valid_caps = [r['discharge_capacity_ah_conditional'] for r in cycles if isinstance(r.get('discharge_capacity_ah_conditional'), (int,float)) and r.get('discharge_capacity_ah_conditional') > 0]
    first_proxy = valid_caps[0] if valid_caps else None
    for r in cycles:
        cap = r.get('discharge_capacity_ah_conditional')
        if first_proxy and isinstance(cap, (int,float)):
            r['capacity_retention_pct_first_observed_proxy'] = cap / first_proxy * 100
            r['capacity_loss_pct_first_observed_proxy'] = 100 - (cap / first_proxy * 100)
        else:
            r['capacity_retention_pct_first_observed_proxy'] = ''
            r['capacity_loss_pct_first_observed_proxy'] = ''
    # Mirror proxy metrics into feasibility rows in matching order (one feasibility row per cycle row).
    proxy_lookup = {(r['source_file'],r['worksheet']):r for r in cycles}
    for frow in feasibility:
        cyc = proxy_lookup.get((frow['source_file'],frow['worksheet']))
        if cyc:
            frow['capacity_retention_vs_first_observed_proxy_pct'] = cyc.get('capacity_retention_pct_first_observed_proxy','')
            frow['capacity_loss_vs_first_observed_proxy_pct'] = cyc.get('capacity_loss_pct_first_observed_proxy','')

    # Add explicit unsupported/underdetermined column mappings for fields not observed in telemetry.
    base_condition = condition_dirs[0] if condition_dirs else 'B6_Discharge0.5C_Charge2C'
    unsupported_map = [
        ('battery_id','No globally validated source cell identifier','unknown','source internal path only suggests BATTERY 6','UNDERDETERMINED','Internal path label is BATTERY 6; map it only as a source label until cross-condition physical-cell mapping is verified.'),
        ('cycle_id','Global lifetime cycle number','cycles','worksheet-local cycle numbering plus checkpoint filenames','UNDERDETERMINED','Do not combine checkpoint filename with local worksheet number until sequential coverage is verified; Cycle_0700 has fewer cycle tabs than other 100-cycle batches.'),
        ('temperature_c','Measured cell temperature','°C','not present in the telemetry columns','UNSUPPORTED','Protocol/source metadata states 25°C but no temperature sensor column is present in the workbook data.'),
        ('capacity_ah','Measured discharge capacity','Ah','not directly present as a numeric capacity column','VERIFIED_WITH_CONDITIONS','Derived conditional capacity exists only by integrating current assuming total A; no direct capacity measurement was identified in these telemetry columns.'),
        ('soh_pct','State of health relative to validated BOL capacity','%','not directly present','UNDERDETERMINED','Nominal-capacity-based percentage is calculated conditionally; validated BOL reference capacity is unavailable.'),
        ('current_density_a_cm2','Current density','A/cm²','I(A/cm2) literal source header; active area not defensible (MSTAT surface area=0)','UNDERDETERMINED','Do not convert to total current or current density without clarifying source semantics.'),
        ('is_interpolated','Whether sample was interpolated','boolean','not present in source; generated staging is raw-only','VERIFIED','No interpolated observations are created; any future resampling must flag synthetic/interpolated rows.'),
        ('quality_flag','Quality flags','categorical','calculated by this audit from raw observations','VERIFIED_WITH_CONDITIONS','Flags are audit-derived and do not overwrite the source observations.'),
        ('value_origin','Source/derived/proxy provenance','categorical','derived from processing logic','VERIFIED_WITH_CONDITIONS','Raw telemetry labelled measured; source metadata labelled source-provided; capacity and SOH labelled calculated conditional; BOL reference unknown.')
    ]
    for canon, meaning, unit, evidence, status, notes in unsupported_map:
        mappings.append({'condition_folder':base_condition,'source_file':'','worksheet':'','source_column':'','canonical_column':canon,
                         'meaning':meaning,'source_unit':unit,'verified_unit':unit,'data_type':'n/a or derived','data_grain':'n/a',
                         'transformation':'not mapped from raw telemetry' if status in ('UNSUPPORTED','UNDERDETERMINED') else 'derived in report',
                         'evidence':evidence,'status':status,'notes':notes})

    # Compute archive-wide summary for the report.
    workbook_count = len([r for r in workbook_rows if r.get('inspection_status') not in ('UNSUPPORTED',)])
    all_cycle_tab_counts = [r.get('cycle_tab_count',0) for r in workbook_rows if isinstance(r.get('cycle_tab_count'), int)]
    unique_hash_dupes = [names for names in hash_seen.values() if len(names)>1]
    checkpoints = [r.get('checkpoint_from_filename') for r in workbook_rows if isinstance(r.get('checkpoint_from_filename'), int)]
    channels = sorted({str(r.get('notes','')) for r in workbook_rows if r.get('notes')})
    # Formula register with explicit conditionality and source URL evidence.
    formula_rows = [
        {'formula_id':'F01','metric':'measured_discharge_capacity_ah_conditional','formula':'Q_discharge_Ah = Σ(((|I_i| + |I_(i+1)|)/2) × (t_(i+1) - t_i) / 3600) for adjacent samples where both endpoint currents are negative','required_inputs':'I(A/cm2) raw signal; T(Seconds); discharge sign convention; adjacent discharge samples','units':'Assumes I in A and t in seconds; output Ah','assumptions':'Raw I is interpreted as total amperes because measured magnitudes match MSTAT setpoints +2.4 A and -0.625 A; this conflicts with source header I(A/cm2). Only intervals with both endpoint current values <0 are integrated. Actual Δt is used.','source':'Standard numerical trapezoidal integration of I(t); dataset page describes protocol but does not prescribe a capacity formula. Official metadata: '+SOURCE_URL,'status':'VERIFIED_WITH_CONDITIONS','example':'A per-row genuine-observation example is included in LFP_cycle_summary.csv; the summary contains full source workbook and worksheet identifiers.','notes':'Retain current_raw_value and original source label; never use as fully verified capacity until current unit discrepancy is resolved.'},
        {'formula_id':'F02','metric':'soh_nominal_pct_conditional','formula':'SOH_nominal_pct = measured_discharge_capacity_ah_conditional / 1.25 Ah × 100','required_inputs':'F01 conditional discharge capacity; source-provided nominal capacity 1.25 Ah','units':'%','assumptions':'This is nominal-capacity-based SOH, not capacity retention against measured BOL capacity; current-unit assumption from F01 is inherited.','source':'Nominal capacity 1.25 Ah is source-described on the University of Birmingham dataset record: '+SOURCE_URL,'status':'VERIFIED_WITH_CONDITIONS','example':'Worked example is demonstrable from any LFP_cycle_summary.csv row: capacity value divided by 1.25 and multiplied by 100.','notes':'No clipping to 100%; values above 100% would be preserved and flagged for investigation.'},
        {'formula_id':'F03','metric':'capacity_retention_pct_first_observed_proxy','formula':'Q_checkpoint / Q_first_observed_cycle × 100','required_inputs':'F01 capacity for checkpoint tab; first valid observed cycle-tab capacity in supplied archive','units':'%','assumptions':'Earliest observed capacity is only a proxy; it is not verified as a standardized, validated BOL reference.','source':'Audit-derived reference convention; not a formula claimed by the dataset record.','status':'VERIFIED_WITH_CONDITIONS','example':'First valid observed cycle is defined as 100% by construction; later values are relative to its conditional capacity.','notes':'Do not merge this proxy into a column called validated capacity_retention_pct without preserving the proxy label.'},
        {'formula_id':'F04','metric':'capacity_loss_pct_first_observed_proxy','formula':'100 - capacity_retention_pct_first_observed_proxy','required_inputs':'F03 proxy retention','units':'%','assumptions':'Inherits F03 proxy baseline and F01 current-unit assumption.','source':'Audit-derived arithmetic identity; not a dataset-prescribed formula.','status':'VERIFIED_WITH_CONDITIONS','example':'For a proxy retention of 95%, proxy loss = 5%.','notes':'This is loss relative to first observed capacity, not validated BOL loss.'},
        {'formula_id':'F05','metric':'discharge_duration_sec','formula':'max(time_sec where current < 0) - min(time_sec where current < 0)','required_inputs':'T(Seconds); current sign','units':'seconds','assumptions':'Positive charge current / negative discharge current consistent with observed data and protocol metadata.','source':'Direct calculation from raw timestamps; formula is an operational definition used for this audit.','status':'VERIFIED_WITH_CONDITIONS','example':'Per-worksheet start/end times appear in LFP_cycle_summary.csv.','notes':'Duration excludes phase-transition intervals where current is zero or polarity changes.'},
        {'formula_id':'F06','metric':'voltage_and_current_statistics','formula':'min, max, arithmetic mean over observed samples (phase-specific means use subset with current < 0)','required_inputs':'Raw voltage and current columns','units':'V and source current units as labelled; assumed A only where separately stated','assumptions':'No clipping or smoothing; current means preserve unit ambiguity.','source':'Audit-derived descriptive statistics over actual source observations.','status':'VERIFIED','example':'Per-worksheet min/max/mean in LFP_cycle_summary.csv.','notes':'Protocol voltage excursions remain in the calculations and are counted separately.'},
    ]

    # CSVs required by the user's audit specification.
    write_csv(os.path.join(output_dir, 'LFP_file_manifest.csv'), archive_rows + all_sheet_inventory)
    write_csv(os.path.join(output_dir, 'LFP_column_mapping.csv'), mappings)
    write_csv(os.path.join(output_dir, 'LFP_cleaning_log.csv'), cleaning)
    write_csv(os.path.join(output_dir, 'LFP_capacity_soh_feasibility.csv'), feasibility)
    write_csv(os.path.join(output_dir, 'LFP_formula_register.csv'), formula_rows)
    write_csv(os.path.join(output_dir, 'LFP_cycle_summary.csv'), cycles)
    write_csv(os.path.join(output_dir, 'LFP_workbook_summary.csv'), workbook_rows)

    # Source-derived/calc-status summary text.
    fully_read_cycle_count = len(cycles)
    count_volt_flags = sum(int(r.get('out_of_protocol_voltage_count') or 0) for r in cycles)
    count_material_voltage_flags = sum(int(r.get('material_voltage_excursions_gt_20mv') or 0) for r in cycles)
    cycle_like_tab_count = len(cycles)
    complete_cycle_count = sum(1 for r in cycles if r.get('complete_discharge_screen') in (True, 'True', 'true', 1, '1'))
    unresolved_generic_count = sum(1 for r in cycles if r.get('worksheet_cycle_type') == 'generic_cycle_like_tab')
    incomplete_cycle_count = cycle_like_tab_count - complete_cycle_count
    count_cycles_gaps = sum(1 for r in cycles if int(r.get('time_gap_count_gt_1_5s') or 0)>0)
    count_cycles_dupts = sum(1 for r in cycles if int(r.get('duplicate_timestamp_count') or 0)>0)
    count_cycles_nonmono = sum(1 for r in cycles if int(r.get('nonmonotonic_time_intervals') or 0)>0)
    unit_statuses = Counter(r.get('current_unit_assessment','') for r in cycles)
    batt_labels = sorted({r.get('internal_battery_label','') for r in workbook_rows if r.get('internal_battery_label')})
    filelist_mismatch = sum(1 for r in workbook_rows if int(r.get('unindexed_actual_sheet_count') or 0)>0)
    tab_counts = Counter(int(r.get('cycle_tab_count',0) or 0) for r in workbook_rows)
    nominal_soh_vals = [r.get('soh_nominal_pct_conditional') for r in cycles if isinstance(r.get('soh_nominal_pct_conditional'), (int,float))]
    capacity_vals = [r.get('discharge_capacity_ah_conditional') for r in cycles if isinstance(r.get('discharge_capacity_ah_conditional'), (int,float))]
    mincap = min(capacity_vals) if capacity_vals else None
    maxcap = max(capacity_vals) if capacity_vals else None
    mean_cap = statistics.mean(capacity_vals) if capacity_vals else None
    min_soh = min(nominal_soh_vals) if nominal_soh_vals else None
    max_soh = max(nominal_soh_vals) if nominal_soh_vals else None
    mean_soh = statistics.mean(nominal_soh_vals) if nominal_soh_vals else None
    source_checkpoint_str = ', '.join(str(x) for x in sorted(set(checkpoints)))
    other_files = [i.filename for i in infos if not i.is_dir() and not i.filename.lower().endswith('.xlsx')]
    report = f'''# LFP B6 Dataset Audit Report

**Audit date:** 2026-10-26  
**Input archive:** `{os.path.basename(input_zip)}`  
**Condition folder present:** `{'; '.join(condition_dirs)}`  
**Overall status:** `VERIFIED_WITH_CONDITIONS` for the supplied B6 subset; not an audit of the full six-condition dataset.

## Executive findings

- The ZIP passed its CRC test and contains **{len(xlsx_infos)} Excel workbooks**, **{len(infos)} archive entries** including directory entries, and **{total_sheet_count} worksheets** parsed from the workbooks. No non-Excel documentation files were present in the supplied archive: `{other_files}`.
- All supplied workbook names/checkpoints observed: `{source_checkpoint_str}`. These are filename-level checkpoint labels, not assigned as global cycle IDs for each worksheet.
- **{cycle_like_tab_count} cycle-like worksheet tabs** were summarized (including {unresolved_generic_count} generic `SheetN` telemetry tabs in `Cycle_0700.xlsx`); **{complete_cycle_count}** pass the conservative complete-discharge screen and **{incomplete_cycle_count}** remain partial/underdetermined. Separate OCV/rest tabs remain in the manifest and cleaning log but are not treated as cycles. These are worksheet tabs, not independent cells.
- Source workbook paths contain the internal label **`BATTERY 6`**. This is retained as a source-provided cell label, but this B6-only archive cannot independently establish the total number of physical cells or cross-condition cell independence.
- MSTAT `Cell Information` strings report `Surface Area: 0` and `Sample Capacity: 0`. No measured temperature column or direct numeric capacity column was found in the three-column telemetry schema.
- The workbook source header labels current as `I(A/cm2)`. Current values, however, align closely with the MSTAT experiment setpoints (**Charge CC {next((r.get('mstat_charge_cc_setpoint_a') for r in workbook_rows if r.get('mstat_charge_cc_setpoint_a')), '')}; Discharge CC {next((r.get('mstat_discharge_cc_setpoint_a') for r in workbook_rows if r.get('mstat_discharge_cc_setpoint_a')), '')}**). The raw column is **not renamed**. Capacity and nominal SOH below are explicitly **conditional on interpreting the recorded signal as total A**; they should not be treated as fully unit-verified until confirmed by authors/MSTAT documentation.
- Workbook `File List` tabs index only part of the actual workbook tabs in **{filelist_mismatch} workbook(s)**. Worksheet inventory is derived from `xl/workbook.xml`, which is the workbook's actual tab list.
- Nominal-capacity-based capacity/SOH calculations were computed **conditionally** from observed negative-current intervals, using trapezoidal integration and actual timestamp differences. A validated measured BOL reference was not identified. Retention/loss is included only against the **first observed valid cycle-tab capacity proxy**, never labelled as validated BOL retention.

## Scope and provenance

Official dataset record: {SOURCE_URL}  
DOI: {DOI_URL}  
The official record describes LFP 18650 cells, nominal capacity 1.25 Ah, test temperature 25 °C, operating-voltage range 2.50–3.65 V, and Solartron 1470E/MSTAT acquisition. It describes periodic age checkpoints. Those are source-level claims, not individual measured temperature records. The official page does not prescribe a capacity integration formula.

The supplied archive contains only `{'; '.join(condition_dirs)}`. The other protocol folders (B1–B5) are **not present and were not inspected**. It is therefore incorrect to describe this work as an audit of the entire LFP archive or of the complete six-condition set.

## Archive inventory and workbook coverage

There are {len(xlsx_infos)} `.xlsx` files. `{os.path.basename(input_zip)}` is {os.path.getsize(input_zip):,} bytes. Workbook-level details are in `LFP_workbook_summary.csv`; every actual worksheet tab and its declared dimensions are in `LFP_file_manifest.csv`.

{md_table([{'workbook':r.get('source_file'), 'checkpoint':r.get('checkpoint_from_filename'), 'sheets':r.get('sheet_count'), 'named_cycle_tabs':r.get('cycle_tab_count'), 'cycle_like_tabs':r.get('cycle_like_telemetry_tab_count'), 'complete_discharge_tabs':r.get('complete_discharge_screen_pass_count'), 'generic_cycle_like_tabs':r.get('generic_cycle_like_tab_count'), 'unindexed_tabs':r.get('unindexed_actual_sheet_count'), 'status':r.get('inspection_status')} for r in workbook_rows], ['workbook','checkpoint','sheets','named_cycle_tabs','cycle_like_tabs','complete_discharge_tabs','generic_cycle_like_tabs','unindexed_tabs','status'])}

The first workbook contains local sheet labels `Cycle01` through `Cycle51`; several later workbooks contain 50 or 100 local cycle tabs. One notable exception is `Cycle_0700.xlsx`, whose workbook contains fewer local cycle tabs than the neighboring 100-cycle batches. Consequently, the global-cycle mapping is **underdetermined** without original experiment logs or author confirmation. Do not create a global `cycle_id` by adding the filename checkpoint to a worksheet-local index.

## Raw schema and column mapping

The measured MSTAT telemetry sheets consistently expose the exact three-column header triple:

- `T(Seconds)` → `time_sec`, source/verified unit **seconds**; values have a predominantly 1-second sampling interval.
- `E(V)` → `voltage_v`, source/verified unit **V**.
- `I(A/cm2)` → `current_raw_value`, preserving the literal source field. Protocol-compatible measured magnitudes strongly indicate total current A, but the header and zero area metadata conflict. `current_a_assumed` is used only for conditional calculations.

No measured `temperature_c` field was found. Source-described ambient/test temperature 25 °C must not be represented as per-sample measured temperature. No numeric measured discharge capacity field was identified in the telemetry schema. `battery_id` is not invented; the source label `BATTERY 6` is captured with a caveat. `cycle_id` remains blank and the source-local tab number is preserved separately.

## Unit, formula and capacity/SOH decisions

### Current-unit assessment

The current unit is **`VERIFIED_WITH_CONDITIONS`**, not fully verified: the source header says A/cm², but measured positive maxima and negative discharge magnitudes match the workbook's setpoint metadata in amperes. MSTAT cell area is `0`, so conversion between A/cm² and A cannot be defended from the area field. The source settings also change in later checkpoints (roughly 2.4/0.625 A initially and 2.135/0.534 A from the 1300 checkpoint); using the official 1.25 Ah nominal rating, those are not all exactly 2C/0.5C, so the setpoint basis may be changing or refer to a different capacity basis. This is not reconciled by the supplied metadata. Recommended next step is author/instrument-documentation clarification. Until then keep `current_raw_value` plus `current_unit_assessment` and use calculated capacity only for clearly labelled exploratory/conditional analysis.

### Formula definitions

- **F01 — Conditional discharge capacity:** integrate the magnitude of negative current with the trapezoidal rule over adjacent samples where both current endpoints are negative, using actual `Δt` in seconds, then divide by 3600. This assumes the raw signal is total A. Intervals with non-positive `Δt` are not integrated. Gaps are flagged; no voltage/current values are clipped.
- **Conservative completed-discharge screen:** a cycle-like tab is treated as a full discharge-capacity record only if it has at least 1,000 negative-current samples, at least 3,000 s between first and last negative-current samples, and its last negative-current voltage is at or below 2.55 V (near the stated 2.50 V cutoff). These are audit heuristics, not a manufacturer-defined capacity-test criterion; raw observed discharge integrals remain available for tabs that fail.
- **F02 — Nominal-capacity-based SOH:** `conditional discharge capacity Ah / 1.25 Ah × 100`. This is not capacity retention against a measured BOL capacity. No values are clipped to 100%.
- **F03/F04 — First-observed proxy retention/loss:** `Q_checkpoint / Q_first_observed × 100` and `100 - retention`. The first observed capacity is a proxy and is **not** declared validated BOL.
- **F05 — Discharge duration:** last negative-current timestamp minus first negative-current timestamp in that tab.
- **F06 — Descriptive statistics:** actual-sample voltage/current min, max and mean, without outlier deletion.

`LFP_formula_register.csv` contains formula IDs, inputs, units, assumptions, sources, example instructions and statuses. No separate scientific paper prescribing a capacity formula was bundled in the archive or verified from the official dataset record; F01 is a standard physical/numerical calculation, not attributed to a paper.

## Quality-control results

- Across the inspected telemetry: **{total_telemetry_samples:,}** raw samples.
- Samples outside the strict stated voltage window (below 2.50 V or above 3.65 V): **{total_voltage_flag:,}**. Many strict flags are millivolt-scale boundary crossings around CV/cutoff; a separate >20 mV outside-window count within cycle-like tabs is **{count_material_voltage_flags:,}**. These are flagged, not removed, and must be interpreted with the protocol and instrument tolerance in mind.
- Duplicate timestamps: **{total_duplicate_ts:,}**; duplicate full numeric rows: **{total_duplicate_rows:,}**; non-monotonic intervals: **{total_nonmonotonic:,}**; intervals longer than 1.5 seconds: **{total_gaps:,}**.
- Worksheet tabs with at least one >1.5-second timestamp gap: **{count_cycles_gaps}**; tabs with duplicate timestamps: **{count_cycles_dupts}**; tabs with non-monotonic time: **{count_cycles_nonmono}**.
- No rows were dropped, clipped, or interpolated. All raw readings stay in the original XLSX archive; quality findings are logged in `LFP_cleaning_log.csv` and `LFP_cycle_summary.csv`.
- Sampling cadence is calculated from timestamps in each sheet. The modal/median intervals are recorded in `LFP_cycle_summary.csv`; intervals are not blindly resampled to one second.

## Conditional performance summaries

The `LFP_cycle_summary.csv` table gives one summary per named or generic cycle-like worksheet tab, not one row per verified global lifetime cycle or independent physical cell. It includes capacity under the A assumption, charge integration as a secondary conditional metric, voltage/current statistics, time bounds, sample counts, flags and formula references.

Conditional discharge-capacity summary (only cycle-like tabs passing the conservative completeness screen; do **not** treat as unit-verified until the header ambiguity is resolved):

- Count of screened conditional full-cycle capacity records: {len(capacity_vals)}
- Minimum: {mincap if mincap is not None else 'NA'} Ah
- Mean: {mean_cap if mean_cap is not None else 'NA'} Ah
- Maximum: {maxcap if maxcap is not None else 'NA'} Ah
- Nominal SOH conditional range: {min_soh if min_soh is not None else 'NA'}% to {max_soh if max_soh is not None else 'NA'}% (mean {mean_soh if mean_soh is not None else 'NA'}%).

These figures are reproducible calculations from the raw observations under the stated assumption. They are not official measured capacity values and not a validated SOH ground truth. Any apparent values above nominal capacity/100% are preserved and should be investigated rather than clipped.

## Model-readiness recommendation

1. Keep all original workbooks unchanged. Use the provided summary CSV and optionally generate a gzip staging file by running the script with `--write-staging`.
2. Preserve stable source keys: `dataset_id`, `condition_id`, `source_file`, `worksheet`, `cycle_checkpoint_from_filename`, and `source_cycle_tab_label`. Keep `global_cycle_id` null until sequential coverage is validated.
3. Preserve `current_raw_value`, literal source label, and `current_unit_assessment`. Do not merge current with datasets whose current basis is confirmed without a conversion decision.
4. Keep source-provided nominal capacity distinct from a measured BOL capacity. Do not treat source-described 25 °C as measured row-level temperature.
5. For train/test evaluation intended to generalize to unseen cells, split by verified physical cell identity; this B6 archive does not verify enough cross-condition cell identity to support a cell-wise split on its own. Avoid random row-level splits that leak adjacent samples.
6. Do not interpolate missing cycles or resample to a different cadence until the underlying sampling and model target are established. Record any future interpolation explicitly with `is_interpolated=true` and a separate origin label.

## Main handoff / blockers

- **Inspected:** every archive entry; all `{len(xlsx_infos)}` `.xlsx` workbooks; all `{total_sheet_count}` actual workbook tabs parsed from workbook metadata; every worksheet with the target telemetry header was summarized.
- **Not inspected:** all non-B6 folders, because they were not in the supplied ZIP; any unpublished source documents; any separate paper prescribing formulas.
- **Cell identity:** internal label `BATTERY 6` present; physical-cell independence across condition folders not verifiable here.
- **Verified units:** `T(Seconds)` = seconds; `E(V)` = volts. `I(A/cm2)` remains a source-label ambiguity. Source-described nominal capacity is 1.25 Ah; it is not a measured BOL value.
- **Computed:** conditional integrated discharge capacity and nominal-capacity-based SOH only for cycle-like tabs passing the conservative full-discharge screen; observed partial discharge integrals are kept separately. Voltage/current statistics and duration are traceable to source file and worksheet.
- **Blocked/conditional:** current unit reconciliation, validated BOL capacity, validated capacity-retention-to-BOL, measured temperature, global lifetime cycle IDs, and full physical-cell count.
- **CSV handoff:** `LFP_Audit_Report.md`, `LFP_file_manifest.csv`, `LFP_column_mapping.csv`, `LFP_cleaning_log.csv`, `LFP_capacity_soh_feasibility.csv`, `LFP_formula_register.csv`, `LFP_cycle_summary.csv`, and `LFP_workbook_summary.csv`. Script: `LFP_preprocess_audit.py`.

## Reproducibility

Requirements: Python 3.10+ standard library only. Example:

```bash
python LFP_preprocess_audit.py --input B6_Discharge0.5C_Charge2C.zip --output-dir LFP_B6_Audit_Output
```

To also write all raw telemetry rows to gzip CSV (large file):

```bash
python LFP_preprocess_audit.py --input B6_Discharge0.5C_Charge2C.zip --output-dir LFP_B6_Audit_Output --write-staging
```

The script does not modify source workbooks and does not create the final multi-chemistry master table.
'''
    with open(os.path.join(output_dir, 'LFP_Audit_Report.md'), 'w', encoding='utf-8') as f:
        f.write(report)

    # Small run metadata for reproducibility and diagnostics.
    runinfo = {
        'input_zip': os.path.basename(input_zip), 'input_size_bytes': os.path.getsize(input_zip),
        'condition_folders': condition_dirs, 'workbook_count':len(xlsx_infos),
        'actual_worksheet_count':total_sheet_count,'cycle_like_worksheet_summary_count':len(cycles),
        'complete_discharge_screen_pass_count':complete_cycle_count,'generic_cycle_like_worksheet_count':unresolved_generic_count,
        'telemetry_sample_count':total_telemetry_samples,'voltage_out_of_protocol_observation_count':total_voltage_flag,
        'duplicate_timestamp_count':total_duplicate_ts,'duplicate_full_row_count':total_duplicate_rows,
        'non_monotonic_time_intervals':total_nonmonotonic,'timestamp_gaps_gt_1_5s':total_gaps,
        'duplicate_workbook_hashes':unique_hash_dupes,'source_checkpoint_labels':sorted(set(checkpoints)),
        'current_unit_assessment_counts':dict(unit_statuses),'conditional_capacity_min_ah':mincap,
        'conditional_capacity_mean_ah':mean_cap,'conditional_capacity_max_ah':maxcap,
        'output_dir':os.path.abspath(output_dir),'staging_written':bool(write_staging)
    }
    with open(os.path.join(output_dir, 'LFP_audit_run_metadata.json'), 'w', encoding='utf-8') as f:
        json.dump(runinfo, f, indent=2, ensure_ascii=False)
    print(json.dumps(runinfo, indent=2))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', default='/mnt/data/B6_Discharge0.5C_Charge2C.zip', help='Input source ZIP')
    p.add_argument('--output-dir', default='/mnt/data/LFP_B6_Audit_Output', help='Folder for report/CSV outputs')
    p.add_argument('--write-staging', action='store_true', help='Also export raw telemetry rows into a large compressed canonical CSV')
    args = p.parse_args()
    audit(args.input, args.output_dir, args.write_staging)

if __name__ == '__main__':
    main()
