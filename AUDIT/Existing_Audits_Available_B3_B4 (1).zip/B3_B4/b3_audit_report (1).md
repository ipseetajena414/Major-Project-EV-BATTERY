# B3 LFP 18650 Dataset: Raw-Data Audit, Validation and Preprocessing

**Status: a fresh raw-data audit was completed.** All 25 original MSTAT Excel workbooks were supplied, read independently, and every value below was recomputed from them.
Scope note: the request text ended mid-sentence ("Do not fabricate missing…"). I applied the obvious intent: nothing here is imputed or invented, and every gap or assumption is stated.

---

## 1. Inventory

| Item | Result |
|---|---|
| ZIP | `B3_Discharge2C_Charge0_5C.zip`, 392,547,570 B (374 MiB); 401,523,349 B uncompressed |
| Entries | 26 (1 folder `B3_Discharge2C_Charge0.5C/` + 25 files) |
| Original experimental workbooks (.xlsx) | **25** (`Cycle_0050` … `Cycle_2000`) |
| .mdat / other raw | 0 |
| Existing audit reports (.md), derived CSV, JSON scans, .py, documentation | **0**. Nothing pre-derived was supplied, so there was nothing to trust or review |
| Independent inspection of raw measurements possible? | **Yes** (time, voltage, current for every sample) |

Contents: 2,026 sheets = 1,979 cycle sheets + 25 `OCV` sheets (30 s each) + 22 `Rest 1` sheets (3,600 s each, after the last cycle of a block) + 25 `File List` index sheets. SHA-256 per workbook is in `b3_file_inventory.csv`.

## 2. Is this really B3 / 2C-discharge / 0.5C-charge?

The ZIP filename was not used as evidence. Verified from inside the files:

| Check | Evidence | Result |
|---|---|---|
| Condition folder | `B3_Discharge2C_Charge0.5C/` | ✔ |
| Cell identity | Source path in all 25 workbooks: `LFP 18650 (1250mAh)\BATTERY 3\EXPERIMENT n\…` | ✔ |
| Protocol string (all 1,979 cycle sheets, no exceptions) | `Charge CC 0.625 A, CV 3.65 V, XI 0.025 A … Discharge CC 2.5 A, XV 2.5 V` | ✔ = 0.5C / 3.65 V / C/50 taper / 2C / 2.5 V on 1.25 Ah |
| Measured CC charge current | 0.6253–0.6266 A | ✔ 0.500–0.501 C |
| Measured CC discharge current | mean 2.4984–2.5000 A per cycle | ✔ 2.00 C |
| CV termination | final CV current 0.0248–0.0250 A in every complete cycle | ✔ |
| Voltage window | min 2.4887 V; max 3.665 V (one cycle) | ✔ (≤ 15 mV overshoot) |
| Instrument | `MultiStat 1.7f`, Pstat `1470` | ✔ Solartron 1470E / MSTAT |
| Source page (fetched) | 1.25 Ah, 25 °C, 2.50–3.65 V, Solartron 1470E/MSTAT, DOI 10.5281/zenodo.22286449; data "at 50-cycle intervals … subsequently 100-cycle" | ✔ matches |

**Not verifiable from the data:**
- **Temperature (25 °C):** no temperature channel (`Aux Count 0`). 25 °C is source-described only.
- **Nominal capacity 1.25 Ah:** no low-rate reference test is in these files, since all cycling is at 2C. The 1.25 Ah figure is a label.
- **Cell identity across channels:** the instrument channel changes (Ch2 → Ch8 at Cycle_1000 → Ch1 at 1500 → Ch6 at 2000). The path says Battery 3 throughout, but the data cannot prove the same physical cell was moved.
- The source page says "dataset made available 3 Sept 2026", while the files were recorded Dec 2024 – Feb 2026. This is a metadata curiosity, not a data problem.

## 3. Data structure and unit issues

- Each cycle sheet = ~100-line header + 3 columns `T(Seconds) | E(V) | I(A/cm2)`, 1 Hz.
- **Unit label error:** the current column is labelled `A/cm²`, but `Surface Area = 0` and magnitudes equal the commanded 0.625 / 2.5 A, so values are **amperes**. Charge is positive, discharge negative.
- No capacity, temperature or step-state column exists. Capacity must be Coulomb-counted from I and T. Nothing was taken from instrument summaries.
- Sheet naming is inconsistent (`Cycle01`, `Cycle002`, `Cycle0100`); numbers were parsed, not string-matched. No non-numeric cells, NaNs, duplicates or non-monotonic time anywhere.
- **Sampling:** nominal 1 s. 396 sheets contain at least one single skipped sample (Δt = 2 s; 2,225 total, max Δt = 2 s). These are handled by integrating over the true T.
- Charge → discharge occurs with **zero rest samples**. Consecutive cycles within a run are 1 s apart.

## 4. Block structure, restarts and cycle numbering

Blocks: 0050–0500 hold 50 cycles; 0600–2000 hold 100. Cycle index = (block label − block length) + sheet number (**1–2000**, unique).

**Six run restarts** (time axis resets to T = 31 s) and **two truncated final sheets** were found. The restart signature is that `Scan Number` = planned cycles remaining.

| Where | What happened |
|---|---|
| 0500 sheet 18 → 19 | discharge interrupted at 3.14 V (0.25 Ah); resumed (18 + 32 = 50) |
| 1300 sheet 17 → 18 | charge interrupted at 3.33 V; resumed with a **discharge-only** sheet (17 + 83 = 100) |
| 1300 sheet 92 → 93 | charge interrupted; discharge-only restart (92 + 8 = 100) |
| 1600 sheet 84 → 85 | charge interrupted; discharge-only restart (84 + 16 = 100) |
| 1900 sheet 67 → 68 | discharge interrupted at 2.97 V; resumed (67 + 33 = 100) |
| 2000 sheet 28 → 29 | charge interrupted; resumed (28 + 73 = 101; only 72 sheets follow, so block 2000 has 99 complete + 1 partial cycle) |
| 0050 sheet 50, 0200 sheet 50 | truncated final sheets (38 and 536 rows), no discharge |

**Cycle_0250 contains only 29 cycles.** `Scan Number = 29` and the filename `(250th Cycle)(2).mdat` imply a first file with 21 cycles that was **not supplied**. I anchored this block to its label (cycles 222–250; **201–221 absent**) and marked the index *medium confidence*. The capacity trend cannot discriminate (block-to-block steps are ±3 mAh, and 21 cycles ≈ 2.7 mAh). Treat absolute indices in 201–250 as ±21.

Minor: the `Cycle_0150` file is labelled "EXP 3" in its own path (it is Experiment 4; "EXP 3" appears twice). Source-file labelling error only.

## 5. Capacity method

Q_dis = ∫|I|dt/3600 over the contiguous discharge run (I < −0.05 A), trapezoid over the actual timestamps. No smoothing, fitting or interpolation.
Sensitivity (threshold 0.01–1.0 A, rectangle rule, mean-I × t): all agree to **< 0.5 mAh** (≈0.04 %). The gaps and threshold choice are not material.
Also reported: Q_chg, CC/CV split, discharge energy (Wh), mean voltage, end voltages.

## 6. Quality tiers (1,979 cycle sheets)

| Tier | n | Definition |
|---|---|---|
| **A** | **1,968** | CC-CV charge completed in-sheet (3.65 V, I ≤ 0.0265 A) → single CC discharge, mean 2.50 ± 0.01 A, ended ≤ 2.52 V |
| **B** | 3 | Full 2C discharge to cutoff, but **no recorded charge** (cycles 1218, 1293, 1585; charge happened outside supplied data) |
| **X** | 8 | Unusable for capacity: 6 with no discharge, 2 interrupted discharges (cycles 468, 1867) |

Flags worth knowing: 103 cycles have skipped samples inside the discharge (handled); one cycle (150, first sheet) overshoots 3.665 V; the first sheet of each run starts from a rested state, so its Q_chg is partial (full-charge termination is still verified).
**Coulombic efficiency** is reported only where the charge starts from the discharged state (n = 1,942): median 0.983, range 0.942–1.025. It is not a clean CE: charge is 0.5C, discharge is 2C, and there is no rest between them.

## 7. SOH feasibility: **feasible, with stated caveats**

- Complete 2C capacity at **1,968 cycles across 1–2000**, smooth and monotonic apart from recovery steps (figure: `b3_capacity_soh.png`).
- Capacity 1.164 Ah (cycle 1) → ~0.985 Ah (median of last 50). Min Tier-A value 0.977 Ah (cycle 1866).
- **Two SOH columns**, because they answer different questions:
  - `SOH_vs_nominal_1.25Ah_pct`: 93.1 % at cycle 1 (it is *not* 100 % because 2C capacity < nominal); 78.8 % at the end; first <80 % at cycle **1701**.
  - `SOH_vs_initial_2C_pct` (reference = median Tier-A Q_dis, cycles 2–11 = 1.1610 Ah): 84.9 % at the end; never <80 %.
  - **Recommendation:** use the 2C-reference SOH for within-cell fade; use the nominal-based one only with an explicit note that it is rate-confounded. Do not call 78.8 % "EOL" without agreeing the definition.
- **Recovery artefact:** capacity rises 10–30 mAh after rests/restarts (visible at block starts and +30 mAh at cycle 1219). `run_id` and `cycles_since_run_start` are provided. Suggested default for modelling: drop `cycles_since_run_start ≤ 2` or model it explicitly.
- Within-run fade ≈ 0.086 mAh/cycle overall (cycles with ≥3 since run start).
- Single cell, single condition: this supports within-cell trend modelling, not cross-cell generalisation.

## 8. Recommendations for the master dataset

1. Ingest `b3_cycle_summary.csv`, filter `quality_tier == "A"` (add B only if charge history is not required).
2. Carry `source_workbook`, `source_sheet`, `header_datetime`, `cycle_index_confidence`, `flags` for traceability.
3. Record temperature as *"25 °C, source-described, not measured"*; record the current-unit correction (A/cm² label → A).
4. Do not impute cycles 201–221 or the partial sheets.
5. Time-series (16 M rows) are not exported; `scripts/01` + `02` regenerate everything from the raw workbooks. Paths are hard-coded to `/home/claude/{raw,work,out}`; edit them for your environment.

## Files

`b3_cycle_summary.csv` (1 row per cycle sheet, 48 columns), `b3_file_inventory.csv`, `b3_sheet_inventory.csv` (2,026 sheets), `b3_capacity_soh.png`, `scripts/01_extract_workbooks.py`, `scripts/02_build_cycle_table.py`.
